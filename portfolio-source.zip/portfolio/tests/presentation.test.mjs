import test from 'node:test';
import assert from 'node:assert/strict';
import { advanceTerminal, terminalPhrases, installPresentationMotion } from '../app/utils/presentationMotion.mjs';

function fixture() {
  function element() {
    const listeners = new Map(), classes = new Set(), attributes = new Map(), children = new Map();
    return {
      listeners, classes, attributes, children, textContent: '', style: {},
      addEventListener(type, fn) { if (!listeners.has(type)) listeners.set(type, new Set()); listeners.get(type).add(fn); },
      removeEventListener(type, fn) { listeners.get(type)?.delete(fn); },
      emit(type, event = {}) { [...(listeners.get(type) ?? [])].forEach(fn => fn(event)); },
      classList: { toggle: (c, on) => on ? classes.add(c) : classes.delete(c), remove: c => classes.delete(c) },
      setAttribute: (k, v) => attributes.set(k, v),
      querySelector: k => children.get(k), contains(other) { return this === other || [...children.values()].includes(other); }
    };
  }
  const root = element(), terminal = element(), output = element(), terminalToggle = element(), marquee = element(), marqueeToggle = element(), doc = element(), media = element();
  root.children.set('.terminal-line', terminal); root.children.set('.technology-marquee', marquee);
  terminal.children.set('[data-terminal-text]', output); terminal.children.set('button', terminalToggle); marquee.children.set('button', marqueeToggle);
  doc.hidden = false; media.matches = false;
  const timers = new Map(), observers = [];
  let sequence = 0;
  const win = { document: doc, matchMedia: () => media,
    setTimeout(fn, delay) { timers.set(++sequence, { fn, delay }); return sequence; }, clearTimeout: id => timers.delete(id),
    IntersectionObserver: class { constructor(fn) { this.fn = fn; this.disconnected = false; observers.push(this); } observe() {} disconnect() { this.disconnected = true; } }
  };
  const stop = installPresentationMotion(root, win);
  const visibility = (target, visible) => observers[0].fn([{ target, isIntersecting: visible }]);
  const tick = () => { const [id, timer] = timers.entries().next().value; timers.delete(id); timer.fn(); };
  return { root, terminal, output, terminalToggle, marquee, marqueeToggle, doc, media, timers, observers, stop, visibility, tick };
}

test('short terminal cycles through every exact phrase with a readable pause', () => {
  let state = { phrase: 0, length: 0, erasing: false, delay: 0 };
  const read = [];
  for (let i = 0; i < 250; i++) {
    state = advanceTerminal(state);
    assert.ok(state.length >= 0 && state.length <= terminalPhrases[state.phrase].length);
    if (state.delay >= 2000) { read.push(terminalPhrases[state.phrase]); assert.ok(state.delay <= 3000); }
  }
  assert.deepEqual(read.slice(0, 3), terminalPhrases);
});

test('terminal and marquee stop offscreen and on hidden tabs; all timers and listeners are disposed', () => {
  const f = fixture();
  assert.equal(f.timers.size, 0);
  f.visibility(f.terminal, true); f.visibility(f.marquee, true);
  assert.equal(f.timers.size, 1); assert.ok(f.marquee.classes.has('marquee-running'));
  f.tick(); assert.equal(f.output.textContent, 'Building website'); assert.equal(f.timers.size, 1);
  f.doc.hidden = true; f.doc.emit('visibilitychange');
  assert.equal(f.timers.size, 0); assert.ok(!f.marquee.classes.has('marquee-running'));
  f.doc.hidden = false; f.doc.emit('visibilitychange'); assert.equal(f.timers.size, 1);
  f.visibility(f.terminal, false); f.visibility(f.marquee, false); assert.equal(f.timers.size, 0);
  f.stop(); assert.ok(f.observers[0].disconnected);
  for (const target of [f.root, f.terminalToggle, f.marquee, f.marqueeToggle, f.doc, f.media]) assert.ok([...target.listeners.values()].every(set => set.size === 0));
});

test('the single marquee keeps moving during hover and keyboard focus, with no pause controls', () => {
  const f = fixture(); f.visibility(f.marquee, true);
  for (const event of ['mouseenter', 'focusin', 'mouseleave', 'focusout']) {
    f.marquee.emit(event, { relatedTarget: null });
    assert.ok(f.marquee.classes.has('marquee-running'));
    assert.equal(f.marquee.listeners.get(event)?.size ?? 0, 0);
  }
  assert.equal(f.marqueeToggle.listeners.get('click')?.size ?? 0, 0);
  assert.equal(f.terminalToggle.listeners.get('click')?.size ?? 0, 0);
  f.stop();
});

test('reduced motion presents a full static phrase and cancels all repeated work', () => {
  const f = fixture(); f.visibility(f.terminal, true); f.visibility(f.marquee, true); f.tick();
  f.media.matches = true; f.media.emit('change');
  assert.equal(f.output.textContent, terminalPhrases[0]); assert.equal(f.timers.size, 0);
  assert.ok(!f.terminal.classes.has('terminal-running')); assert.ok(!f.marquee.classes.has('marquee-running'));
  f.media.matches = false; f.media.emit('change'); assert.equal(f.timers.size, 1);
  f.stop();
});
