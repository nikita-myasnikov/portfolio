import test from 'node:test';
import assert from 'node:assert/strict';
import { copyEmailAddress } from '../app/utils/clipboard.mjs';
import { installSectionNavigation } from '../app/utils/sectionNavigation.mjs';

test('copy reports success only after the clipboard accepts the verified address', async () => {
  let copied;
  assert.equal(await copyEmailAddress('nikitamyasnikov127@gmail.com', { clipboard: { async writeText(value) { copied = value; } } }), true);
  assert.equal(copied, 'nikitamyasnikov127@gmail.com');
  assert.equal(await copyEmailAddress(copied, { clipboard: { async writeText() { throw new Error('denied'); } } }), false);
  assert.equal(await copyEmailAddress(copied, {}), false);
});

test('navigation accounts for sticky height, tracks sections, and batches scrolling', () => {
  const properties = new Map();
  const style = { setProperty: (k, v) => properties.set(k, v), removeProperty: k => properties.delete(k) };
  const listeners = new Map(), frames = new Map();
  const positions = { projects: 320, about: 1700, now: 2400, contact: 2900 };
  const ids = Object.keys(positions);
  let sequence = 0, active;
  const win = {
    scrollY: 0, innerHeight: 800, document: { documentElement: { style, scrollHeight: 3600 } },
    addEventListener: (name, callback) => listeners.set(name, callback), removeEventListener: name => listeners.delete(name),
    requestAnimationFrame(callback) { frames.set(++sequence, callback); return sequence; },
    cancelAnimationFrame: id => frames.delete(id)
  };
  const root = { querySelector(selector) { const id = selector.slice(1); return { id, getBoundingClientRect: () => ({ top: positions[id] - win.scrollY }) }; } };
  const nav = {
    style, classList: { add() {}, remove() {} }, getBoundingClientRect: () => ({ left: 100 }),
    querySelector(selector) { const id = selector.match(/"(.*?)"/)[1]; return { getBoundingClientRect: () => ({ left: 100 + ids.indexOf(id) * 90, width: 90 }) }; }
  };
  const header = { getBoundingClientRect: () => ({ bottom: 100, height: 100 }) };
  const stop = installSectionNavigation(root, nav, header, id => { active = id; }, win);
  assert.equal(active, 'projects');
  assert.equal(properties.get('--header-height'), '120px');
  win.scrollY = 1570;
  listeners.get('scroll')(); listeners.get('scroll')();
  assert.equal(frames.size, 1);
  const flush = () => { const [id, callback] = [...frames.entries()][0]; frames.delete(id); callback(); };
  flush();
  assert.equal(active, 'about');
  assert.equal(properties.get('--indicator-x'), '90px');
  win.scrollY = 2800;
  listeners.get('scroll')(); flush();
  assert.equal(active, 'contact', 'the final section stays reachable near page end');
  listeners.get('resize')(); stop();
  assert.equal(frames.size, 0);
  assert.equal(listeners.size, 0);
  assert.equal(properties.has('--header-height'), false);
});
