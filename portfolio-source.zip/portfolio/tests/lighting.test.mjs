import test from 'node:test';
import assert from 'node:assert/strict';
import { installInteractionLighting } from '../app/utils/interactionLighting.mjs';

function fixture() {
  const target = () => {
    const listeners = new Map();
    return { listeners, addEventListener(type, fn) { if (!listeners.has(type)) listeners.set(type, new Set()); listeners.get(type).add(fn); }, removeEventListener(type, fn) { listeners.get(type)?.delete(fn); }, emit(type, event = {}) { [...(listeners.get(type) || [])].forEach(fn => fn(event)); } };
  };
  const nodes = [], animations = [];
  function element() {
    const classes = new Set();
    return Object.assign(target(), {
      style: {}, children: [], classList: { add: c => classes.add(c), remove: c => classes.delete(c), contains: c => classes.has(c) },
      getAttribute: () => null, setAttribute() {}, getBoundingClientRect: () => ({ left: 20, top: 30, width: 200, height: 80 }),
      closest: () => null,
      appendChild(item) { this.children.push(item); item.parent = this; },
      remove() { this.parent.children.splice(this.parent.children.indexOf(this), 1); },
      animate(frames, options) { const animation = { frames, options, cancel() { this.oncancel?.(); }, finish() { this.onfinish?.(); } }; animations.push(animation); return animation; }
    });
  }
  const root = element(), background = element(), button = element(), prose = element();
  root.contains = node => [button, prose].includes(node);
  root.querySelector = () => background;
  button.closest = selector => selector === 'a, button, summary' ? button : null;
  const doc = Object.assign(target(), { hidden: false, createElement() { const node = element(); nodes.push(node); return node; } });
  let selection = '';
  const win = Object.assign(target(), { document: doc, getSelection: () => ({ toString: () => selection }) });
  const stop = installInteractionLighting(root, win);
  function tap({ target = button, type = 'mouse', cancel = false, moved = false, scroll = false } = {}) {
    const event = { target, button: 0, pointerId: 1, pointerType: type, isPrimary: true, clientX: 40, clientY: 50 };
    root.emit('pointerdown', event);
    if (moved) root.emit('pointermove', { ...event, clientX: 70 });
    if (cancel) root.emit('pointercancel', event);
    if (scroll) win.emit('scroll');
    root.emit('pointerup', event);
    root.emit('click', { ...event, detail: 1 });
  }
  return { root, background, button, prose, nodes, animations, doc, win, stop, tap, select: value => selection = value };
}

test('a click creates one soft pulse, action is never prevented, and completed nodes disappear', () => {
  const f = fixture(); f.tap();
  assert.equal(f.nodes.length, 1); assert.equal(f.button.children.length, 1);
  assert.equal(f.animations[0].options.duration, 560);
  assert.equal(f.nodes[0].style.left, '20px');
  f.animations[0].finish(); assert.equal(f.button.children.length, 0); f.stop();
});
test('background activation stays in the fixed decorative layer, never mutating its positioning class', () => {
  const f = fixture(); f.tap({ target: f.prose });
  assert.equal(f.background.children.length, 1);
  assert.equal(f.background.classList.contains('light-host'), false);
  assert.equal(f.nodes[0].style.left, '40px'); f.stop();
});
test('touch scrolling, cancelled pointers, drags and text selection do not create light pulses', () => {
  const f = fixture();
  f.tap({ type: 'touch', cancel: true }); f.tap({ type: 'touch', moved: true }); f.tap({ type: 'touch', scroll: true }); f.tap({ moved: true });
  f.select('selected text'); f.tap(); assert.equal(f.nodes.length, 0);
  f.select(''); f.tap({ type: 'touch' }); assert.equal(f.nodes.length, 1); f.stop();
});
test('keyboard activation uses the control center and does not require a pointer gesture', () => {
  const f = fixture(); f.root.emit('click', { target: f.button, detail: 0 });
  assert.equal(f.nodes[0].style.left, '100px'); assert.equal(f.nodes[0].style.top, '40px');
  f.root.emit('click', { target: f.prose, detail: 0 }); assert.equal(f.nodes.length, 1); f.stop();
});
test('rapid activation is bounded, hidden tabs remove pulses, and disposal cleans every listener', () => {
  const f = fixture(); for (let i = 0; i < 20; i++) f.tap();
  assert.equal(f.button.children.length, 4);
  f.doc.hidden = true; f.doc.emit('visibilitychange'); assert.equal(f.button.children.length, 0);
  f.tap(); assert.equal(f.nodes.length, 20);
  f.stop(); assert.equal(f.button.classList.contains('light-host'), false);
  for (const target of [f.root, f.win, f.doc]) for (const listeners of target.listeners.values()) assert.equal(listeners.size, 0);
});
