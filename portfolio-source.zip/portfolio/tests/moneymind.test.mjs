import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
const script=readFileSync(new URL('../public/moneymind/demo.js',import.meta.url),'utf8');
function node(data={}) {
 const attributes=new Map(),classes=new Set(),listeners=new Map();
 return { dataset:data,attributes,classes,listeners,textContent:'',hidden:false,focused:false,
  classList:{toggle:(c,on)=>on?classes.add(c):classes.delete(c),remove:c=>classes.delete(c),contains:c=>classes.has(c)},
  setAttribute:(k,v)=>attributes.set(k,v),removeAttribute:k=>attributes.delete(k),querySelector:()=>null,
  addEventListener:(type,fn)=>listeners.set(type,fn),focus(){this.focused=true;},scrollIntoView(){},click(){listeners.get('click')?.({preventDefault(){}});}
 };
}
function fixture() {
 const answers=['100','200','300'].map(answer=>node({answer}));const fields=new Map();
 for(const key of ['.feedback','[data-feedback-title]','[data-feedback-body]','[data-reset]','[data-budget-visual]',...['eyebrow','title','body','subtitle','explanation','takeaway'].map(x=>`[data-lesson-${x}]`)])fields.set(key,node());
 const topics=['budget','saving','interest'].map(topic=>node({topic}));topics.forEach(x=>x.classes.add('lesson-card'));
 const document={querySelector:s=>fields.get(s),querySelectorAll:s=>s==='[data-answer]'?answers:s==='[data-topic]'?topics:[],getElementById:()=>node()};
 runInNewContext(script,{document,location:{hash:''},history:{replaceState(){}}});
 return {answers,fields,topics};
}
test('MoneyMind demo provides correct and incorrect explanations, then resets with focus',()=>{
 const f=fixture();f.answers[0].click();assert.match(f.fields.get('[data-feedback-body]').textContent,/100 units is 10%/);assert.ok(f.fields.get('.feedback').classes.has('wrong'));
 f.answers[1].click();assert.match(f.fields.get('[data-feedback-body]').textContent,/1,000 by 0.20 to get 200/);assert.equal(f.answers[1].attributes.get('aria-pressed'),'true');assert.equal(f.answers[0].attributes.get('aria-pressed'),'false');
 f.fields.get('[data-reset]').click();assert.ok(f.answers.every(x=>x.attributes.get('aria-pressed')==='false'));assert.ok(f.answers[0].focused);
});
test('MoneyMind topics change the actual lesson and restore the budget visual',()=>{
 const f=fixture();f.topics[1].click();assert.match(f.fields.get('[data-lesson-title]').textContent,/Small amounts/);assert.equal(f.fields.get('[data-budget-visual]').hidden,true);
 f.topics[2].click();assert.match(f.fields.get('[data-lesson-explanation]').textContent,/100 × 0.05 × 1/);
 f.topics[0].click();assert.match(f.fields.get('[data-lesson-title]').textContent,/Give every part/);assert.equal(f.fields.get('[data-budget-visual]').hidden,false);
});
