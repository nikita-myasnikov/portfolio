import test from 'node:test';
import assert from 'node:assert/strict';
import { installPortfolioMotion } from '../app/utils/portfolioMotion.mjs';

function fixture({ reduced = false, fine = true, hero = false, width = 1280, late = false, noAnimate = false, failAnimate = false, cardCount = 1, hash = '' } = {}) {
  const target = () => {
    const listeners = new Map();
    return { listeners, addEventListener(type, fn) { if (!listeners.has(type)) listeners.set(type, new Set()); listeners.get(type).add(fn); }, removeEventListener(type, fn) { listeners.get(type)?.delete(fn); }, emit(type, event = {}) { [...(listeners.get(type) ?? [])].forEach(fn => fn(event)); } };
  };
  const allElements = [];
  const element = (top = 800) => {
    const classes = new Set(), properties = new Map(), children = [], animations = [];
    const item = Object.assign(target(), {
      classList: { add: (...names) => names.forEach(name => classes.add(name)), remove: (...names) => names.forEach(name => classes.delete(name)), contains: name => classes.has(name), toggle(name, value) { value ? classes.add(name) : classes.delete(name); } },
      style: { setProperty: (key, value) => properties.set(key, value), removeProperty(key) { properties.delete(key); delete this[key]; } },
      properties, children, animations,
      contains(other) { return other === item || children.some(child => child.contains(other)); },
      getBoundingClientRect: () => ({ top, left: 100, width: 200, height: 200 }),
      animate: noAnimate ? undefined : (keyframes, options) => {
        if (failAnimate) throw new Error('animation unavailable');
        const animation = { keyframes, options, playState: 'running', pauses: 0, plays: 0,
          cancel() { this.playState = 'idle'; this.oncancel?.(); },
          pause() { this.playState = 'paused'; this.pauses++; },
          play() { this.playState = 'running'; this.plays++; },
          finish() { this.playState = 'finished'; this.onfinish?.(); }
        };
        animations.push(animation); return animation;
      }
    });
    allElements.push(item); return item;
  };
  const media = [Object.assign(target(), { matches: reduced }), Object.assign(target(), { matches: fine })];
  const frames = new Map(), observed = [], observers = [];
  let sequence = 0, clock = 0, observerDisconnected = false;
  const document = Object.assign(target(), { hidden: false });
  const win = Object.assign(target(), {
    innerHeight: 700, innerWidth: width, document, location: { hash },
    performance: { now: () => late ? 201 : clock, getEntriesByType: () => late ? [{ name: 'first-contentful-paint', startTime: 1 }] : [] },
    matchMedia: query => query.includes('reduced-motion') ? media[0] : media[1],
    requestAnimationFrame(fn) { frames.set(++sequence, fn); return sequence; },
    cancelAnimationFrame(id) { frames.delete(id); },
    IntersectionObserver: class {
      constructor(callback) { this.callback = callback; this.targets = new Set(); this.disconnected = false; observers.push(this); }
      observe(block) { observed.push(block); this.targets.add(block); }
      unobserve(block) { this.targets.delete(block); }
      disconnect() { observerDisconnected = true; this.disconnected = true; this.targets.clear(); }
      enter(block, isIntersecting = true) { this.callback([{ target: block, isIntersecting }]); }
    }
  });
  const cards = Array.from({ length: cardCount }, () => element());
  cards.forEach(card => { card.classList.add('project-card'); card.closest = selector => selector.includes('.project-card') ? card : null; });
  const card = cards[0], section = element(); section.children.push(...cards);
  const root = element(); root.children.push(section);
  const contains = root.contains.bind(root);
  root.contains = candidate => contains(candidate) || cards.includes(candidate?.closest?.('.project-card'));
  root.querySelectorAll = () => cards;
  const heroElement = hero ? element(100) : null;
  const heroParts = {};
  if (heroElement) {
    for (const selector of ['.folder-path', '.headline-first', '.headline-second', '.headline-middle', '.headline-last', '.intro-copy > p', '.intro-actions']) {
      heroParts[selector] = element(100); heroElement.children.push(heroParts[selector]);
    }
    heroElement.querySelector = selector => heroParts[selector]; root.children.push(heroElement);
  }
  root.querySelector = selector => selector === '.intro' ? heroElement : null;
  document.getElementById = id => id === 'projects' ? section : id === 'main' ? root : null;
  const link = element(); link.closest = selector => selector.startsWith('a[') ? link : null; link.getAttribute = () => '#projects'; root.children.push(link);
  const glow = element();
  const flushFrame = () => { const [id, callback] = [...frames.entries()][0]; frames.delete(id); clock += 1000 / 60; callback(clock); };
  return { root, glow, win, card, cards, section, link, heroElement, heroParts, frames, media, observed, observers, allElements, flushFrame, disconnected: () => observerDisconnected };
}

test('reduced motion preserves visible content and disables pointer effects', () => {
  const f = fixture({ reduced: true });
  const stop = installPortfolioMotion(f.root, f.glow, f.win);
  assert.equal(f.root.classList.contains('motion-enabled'), false);
  assert.equal(f.card.classList.contains('motion-reveal'), false);
  assert.equal(f.win.listeners.has('pointermove'), false);
  stop();
});

test('coarse devices receive scroll reveals without mouse listeners', () => {
  const f = fixture({ fine: false });
  const stop = installPortfolioMotion(f.root, f.glow, f.win);
  assert.equal(f.observed.length, 1);
  assert.equal(f.root.classList.contains('pointer-enabled'), false);
  assert.equal(f.win.listeners.has('pointermove'), false);
  stop();
  assert.equal(f.card.classList.contains('motion-reveal'), false);
  assert.equal(f.disconnected(), true);
});

test('pointer motion uses one queued frame and local surface coordinates', () => {
  const f = fixture();
  const stop = installPortfolioMotion(f.root, f.glow, f.win);
  const move = (x, y) => f.win.emit('pointermove', { pointerType: 'mouse', clientX: x, clientY: y, target: { closest: () => f.card } });
  move(120, 850); move(150, 860);
  assert.equal(f.frames.size, 1);
  assert.equal(f.glow.classList.contains('is-active'), false);
  assert.equal(f.card.properties.size, 0);
  f.flushFrame();
  assert.equal(f.glow.classList.contains('is-active'), true);
  assert.equal(f.card.properties.get('--spot-x'), '50px');
  assert.equal(f.card.properties.get('--spot-y'), '60px');
  assert.equal(f.frames.size, 0, 'the effect sleeps when the pointer is stationary');
  move(180, 870);
  f.flushFrame();
  assert.equal(f.frames.size, 1, 'a changing position is interpolated');
  f.win.emit('blur');
  assert.equal(f.frames.size, 0);
  assert.equal(f.glow.classList.contains('is-active'), false);
  assert.equal(f.card.classList.contains('pointer-active'), false);
  stop();
  assert.equal([...f.win.listeners.values()].some(set => set.size), false);
});

test('changing motion preference cancels frames and removes effects', () => {
  const f = fixture();
  const stop = installPortfolioMotion(f.root, f.glow, f.win);
  f.win.emit('pointermove', { pointerType: 'mouse', clientX: 130, clientY: 820, target: { closest: () => f.card } });
  f.flushFrame();
  f.win.emit('pointermove', { pointerType: 'mouse', clientX: 200, clientY: 850, target: { closest: () => f.card } });
  f.media[0].matches = true; f.media[0].emit('change');
  assert.equal(f.frames.size, 0);
  assert.equal(f.glow.classList.contains('is-active'), false);
  assert.equal(f.card.properties.size, 0);
  assert.equal(f.root.classList.contains('pointer-enabled'), false);
  assert.equal(f.card.classList.contains('motion-reveal'), false);
  assert.equal(f.win.listeners.get('pointermove').size, 0);
  stop();
  assert.equal(f.media.every(m => m.listeners.get('change').size === 0), true);
});

test('touch input never starts pointer effects on a hybrid device', () => {
  const f = fixture();
  const stop = installPortfolioMotion(f.root, f.glow, f.win);
  f.win.emit('pointermove', { pointerType: 'touch', clientX: 130, clientY: 820, target: { closest: () => f.card } });
  assert.equal(f.frames.size, 0);
  assert.equal(f.glow.classList.contains('is-active'), false);
  stop();
});

test('hero uses responsive line groups, finishes within 1.2s, and never replays on preference changes', () => {
  for (const width of [375, 768, 1280, 1440]) {
    const f = fixture({ hero: true, width });
    const stop = installPortfolioMotion(f.root, f.glow, f.win);
    const active = Object.values(f.heroParts).flatMap(element => element.animations);
    assert.equal(active.length, width <= 800 ? 6 : 5);
    assert.equal(f.heroParts['.folder-path'].animations[0].options.delay, 0);
    assert.equal(active.every(animation => animation.options.duration + animation.options.delay <= 1200), true);
    assert.equal(f.heroParts['.headline-first'].animations[0].options.duration, 760);
    f.media[1].matches = false; f.media[1].emit('change');
    assert.equal(Object.values(f.heroParts).flatMap(element => element.animations).length, active.length);
    assert.equal(active.every(animation => animation.playState === 'idle'), true);
    stop();
  }
});

test('late initialization, deep links, missing APIs and animation failure leave content usable', () => {
  for (const options of [{ late: true }, { hash: '#projects' }, { noAnimate: true }, { failAnimate: true }, { reduced: true }]) {
    const f = fixture({ hero: true, ...options });
    const stop = installPortfolioMotion(f.root, f.glow, f.win);
    assert.equal(Object.values(f.heroParts).flatMap(element => element.animations).length, 0);
    assert.equal(f.allElements.some(element => element.classList.contains('motion-running')), false);
    assert.equal(f.frames.size, 0);
    stop();
  }
});

test('card reveals stagger by row and play once; focus cancels a delayed reveal immediately', () => {
  const f = fixture({ cardCount: 4 });
  const stop = installPortfolioMotion(f.root, f.glow, f.win);
  f.cards.forEach(card => f.observers[0].enter(card));
  assert.deepEqual(f.cards.map(card => card.animations[0].options.delay), [0, 75, 0, 75]);
  f.root.emit('focusin', { target: f.cards[1] });
  assert.equal(f.cards[1].animations[0].playState, 'idle');
  assert.equal(f.cards[1].classList.contains('motion-running'), false);
  f.media[1].matches = false; f.media[1].emit('change');
  assert.equal(f.observers.at(-1).targets.size, 0, 'seen cards are not observed again');
  assert.equal(f.cards.every(card => card.animations.length === 1), true);
  stop();
});

test('native anchor click reveals its whole destination without intercepting scrolling', () => {
  const f = fixture({ cardCount: 2 });
  const stop = installPortfolioMotion(f.root, f.glow, f.win);
  f.observers[0].enter(f.cards[0]);
  let prevented = false;
  f.root.emit('click', { target: f.link, preventDefault() { prevented = true; } });
  assert.equal(prevented, false);
  assert.equal(f.observers[0].targets.size, 0);
  assert.equal(f.cards[0].animations[0].playState, 'idle');
  f.observers[0].enter(f.cards[1]);
  assert.equal(f.cards[1].animations.length, 0);
  stop();
});

test('ambient motion pauses off-screen and in hidden tabs; native animations also pause', () => {
  const f = fixture({ hero: true });
  const stop = installPortfolioMotion(f.root, f.glow, f.win);
  f.observers[1].enter(f.heroElement);
  assert.equal(f.root.classList.contains('ambient-running'), true);
  f.win.document.hidden = true; f.win.document.emit('visibilitychange');
  assert.equal(f.root.classList.contains('ambient-running'), false);
  assert.equal(f.heroParts['.headline-first'].animations[0].playState, 'paused');
  f.win.document.hidden = false; f.win.document.emit('visibilitychange');
  assert.equal(f.root.classList.contains('ambient-running'), true);
  assert.equal(f.heroParts['.headline-first'].animations[0].playState, 'running');
  f.observers[1].enter(f.heroElement, false);
  assert.equal(f.root.classList.contains('ambient-running'), false);
  f.media[0].matches = true; f.media[0].emit('change');
  assert.equal(f.allElements.some(element => element.classList.contains('motion-running')), false);
  assert.equal(f.root.classList.contains('ambient-ready'), false);
  stop();
  assert.equal(f.observers.every(observer => observer.disconnected), true);
  assert.equal(f.allElements.some(element => [...element.listeners.values()].some(set => set.size)), false);
  assert.equal([...f.win.document.listeners.values()].some(set => set.size), false);
});

test('pointer interpolation settles without idle frames and touch or hidden tabs cancel it', () => {
  const f = fixture();
  const stop = installPortfolioMotion(f.root, f.glow, f.win);
  const move = (x, pointerType = 'mouse') => f.win.emit('pointermove', { pointerType, clientX: x, clientY: 820, target: f.card });
  move(120); f.flushFrame(); move(220);
  let count = 0;
  while (f.frames.size && count++ < 60) f.flushFrame();
  assert.equal(f.frames.size, 0);
  assert.equal(f.glow.classList.contains('is-tracking'), false);
  assert.equal(f.glow.classList.contains('is-active'), true);
  move(250); move(260, 'touch');
  assert.equal(f.frames.size, 0);
  assert.equal(f.glow.classList.contains('is-active'), false);
  move(250); f.flushFrame();
  f.win.document.hidden = true; f.win.document.emit('visibilitychange');
  assert.equal(f.glow.classList.contains('is-active'), false);
  move(260);
  assert.equal(f.frames.size, 0);
  stop();
  assert.equal(f.card.properties.size, 0);
});
