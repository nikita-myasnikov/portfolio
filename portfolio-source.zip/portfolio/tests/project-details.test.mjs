import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createContext, runInContext } from 'node:vm';
import { parse, compileScript } from '@vue/compiler-sfc';
import { transformSync } from 'esbuild';
import { motion } from '../app/utils/motionTokens.mjs';

const visualSource = readFileSync(new URL('../app/data/projectVisuals.ts', import.meta.url), 'utf8');
const projectVisuals = JSON.parse(visualSource.slice(visualSource.indexOf('= {', visualSource.indexOf('export const')) + 2));
const portfolioModule = transformSync(readFileSync(new URL('../app/data/portfolio.ts', import.meta.url),'utf8'),{loader:'ts',format:'cjs'}).code;
const dataContext=createContext({module:{exports:{}},exports:{}}); runInContext(portfolioModule,dataContext);
const { projects } = dataContext.module.exports;
const { descriptor } = parse(readFileSync(new URL('../app/components/ProjectDetails.vue',import.meta.url),'utf8'));
const script = transformSync(compileScript(descriptor, { id:'project-details-test' }).content, {loader:'ts',format:'cjs'}).code;
function fixture() {
 const mounted=[], unmount=[], ticks=[];let exposed;
 const document={ body:{style:{overflow:'auto'}}, addEventListener(){},removeEventListener(){} };
 const media={matches:false, addEventListener(){},removeEventListener(){}};
 const ctx=createContext({ module:{exports:{}},exports:{},document,window:{matchMedia:()=>media},
  require(name) { if(name==='vue')return{defineComponent:x=>x};if(name.includes('motionTokens'))return{motion};if(name.includes('projectVisuals'))return{projectVisuals};throw new Error(name); },
  ref:value=>({value}),computed:fn=>({get value(){return fn();}}),nextTick:fn=>ticks.push(fn),onMounted:fn=>mounted.push(fn),onBeforeUnmount:fn=>unmount.push(fn)
 });
 runInContext(script,ctx);
 const state=ctx.module.exports.default.setup({}, {expose:x=>{exposed=x;}});
 const dialog={open:false,showModal(){this.open=true;},close(){this.open=false;state.restored();}};
 state.dialog.value=dialog;
 mounted.forEach(fn=>fn());
 return {state,dialog,document,exposed,ticks,unmount};
}
test('all four cards have a real cover and open their matching project details',()=>{
 assert.deepEqual(Array.from(projects,p=>p.name),['EDUCore','AutoHub M','Electric Design','MoneyMind']);
 for(const project of projects) {
  const f=fixture(); let focused=false;
  f.exposed.open(project,{currentTarget:{focus(){focused=true;}}});f.ticks.forEach(fn=>fn());
  assert.equal(f.state.project.value.id,project.id);assert.equal(f.state.current.value.src,projectVisuals[project.id].images[0].src);
  assert.equal(f.dialog.open,true);assert.equal(f.document.body.style.overflow,'hidden');
  f.state.close();assert.equal(f.document.body.style.overflow,'auto');assert.equal(focused,true);
  f.unmount.forEach(fn=>fn());
 }
});
test('detail galleries wrap keyboard navigation and reset when another project opens',()=>{
 const f=fixture(); const event={currentTarget:{focus(){}}}; const edu=projects.find(p=>p.id==='educore');
 f.exposed.open(edu,event);f.ticks.shift()();
 let prevented=false;f.state.key({key:'ArrowLeft',preventDefault(){prevented=true;}});
 assert.equal(prevented,true);assert.equal(f.state.index.value,3);
 f.state.key({key:'ArrowRight',preventDefault(){}});assert.equal(f.state.index.value,0);
 f.state.select(2);f.state.close();
 f.exposed.open(projects.find(p=>p.id==='moneymind'),event);f.ticks.shift()();
 assert.equal(f.state.index.value,0);assert.equal(f.state.selected.value.images.length,3);
 f.unmount.forEach(fn=>fn());assert.equal(f.document.body.style.overflow,'auto');
});
