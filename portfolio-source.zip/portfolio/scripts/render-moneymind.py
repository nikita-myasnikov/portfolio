"""Render the actual HTML/CSS prototype to portfolio images, without a browser.
Development-only dependencies: WeasyPrint, PyMuPDF and Pillow.
"""
from pathlib import Path
from io import BytesIO
from weasyprint import HTML
from PIL import Image
import fitz
import json

root = Path(__file__).resolve().parents[1]
assets = root / 'public/assets/projects'
results = []
for page, slug in [('index', 'overview'), ('learning', 'learning'), ('practice', 'practice')]:
    document = HTML(filename=str(root / f'public/moneymind/{page}.html')).render()
    if len(document.pages) != 1:
        raise RuntimeError(f'{page}: expected one complete screen, got {len(document.pages)} pages')
    pdf = fitz.open(stream=document.write_pdf(), filetype='pdf')
    pixels = pdf[0].get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
    image = Image.open(BytesIO(pixels.tobytes('png')))
    path = assets / f'moneymind-{slug}.webp'
    image.save(path, quality=94, method=6)
    dimensions = image.size
    image.thumbnail((1200, 900))
    image.save(assets / f'moneymind-{slug}-preview.webp', quality=90, method=6)
    results.append(dict(screen=slug, width=dimensions[0], height=dimensions[1], bytes=path.stat().st_size))
print(json.dumps(results))
