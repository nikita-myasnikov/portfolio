<script setup lang="ts">
import { motion } from '../utils/motionTokens.mjs'
import { projectVisuals, type ProjectVisuals } from '../data/projectVisuals'
import type { PortfolioProject } from '../data/portfolio'
const dialog = ref<HTMLDialogElement | null>(null)
const selected = ref<ProjectVisuals | null>(null)
const project = ref<PortfolioProject | null>(null)
const index = ref(0)
const failed = ref(false)
const current = computed(() => selected.value?.images[index.value])
let opener: HTMLElement | null = null
let previousOverflow = ''
let imageAnimation: Animation | undefined
let stopMotionPreference = () => {}
function open(item: PortfolioProject, event: Event) {
  const visuals = projectVisuals[item.id]!
  opener = event.currentTarget as HTMLElement
  selected.value = visuals
  project.value = item
  index.value = 0
  failed.value = false
  previousOverflow = document.body.style.overflow
  nextTick(() => { dialog.value?.showModal(); document.body.style.overflow = 'hidden' })
}
function close() { dialog.value?.close() }
function restored() { document.body.style.overflow = previousOverflow; imageAnimation?.cancel(); opener?.focus({ preventScroll: true }) }
function select(next: number) {
  imageAnimation?.cancel()
  index.value = (next + selected.value!.images.length) % selected.value!.images.length
  failed.value = false
}
function key(event: KeyboardEvent) {
  if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') { event.preventDefault(); select(index.value + (event.key === 'ArrowLeft' ? -1 : 1)) }
}
function loaded(event: Event) {
  if (!dialog.value?.open || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
  const element = event.target as HTMLElement
  imageAnimation?.cancel()
  imageAnimation = element.animate?.([{ opacity: .5 }, { opacity: 1 }], { duration: motion.gallery, easing: motion.ease })
}
onMounted(() => {
  const media = window.matchMedia('(prefers-reduced-motion: reduce)')
  const cancel = () => { if (media.matches || document.hidden) imageAnimation?.cancel() }
  media.addEventListener('change', cancel)
  document.addEventListener('visibilitychange', cancel)
  stopMotionPreference = () => { media.removeEventListener('change', cancel); document.removeEventListener('visibilitychange', cancel) }
})
onBeforeUnmount(() => { stopMotionPreference(); imageAnimation?.cancel(); if (dialog.value?.open) document.body.style.overflow = previousOverflow })
defineExpose({ open })
</script>

<template>
  <dialog ref="dialog" class="screenshot-dialog project-gallery project-detail-modal" aria-labelledby="project-detail-title" aria-describedby="gallery-instructions" @close="restored" @keydown="key">
    <template v-if="current && selected && project">
      <div class="dialog-toolbar"><div><TerminalPath :segments="['Projects', project.id]" /><h2 id="project-detail-title">{{ project.name }}</h2></div><button autofocus class="icon-button" aria-label="Close project details" @click="close">×</button></div>
      <div class="detail-introduction"><span class="detail-status">{{ project.status }}</span><p>{{ project.description }}</p><ul class="tags" aria-label="Project technologies"><li v-for="tech in project.technologies" :key="tech">{{ tech }}</li></ul></div>
      <div class="detail-image-heading"><h3>{{ current.title }}</h3><span>{{ current.provenance }}</span></div>
      <p id="gallery-instructions" class="sr-only">Use the left and right arrow keys to browse. Press Escape to close.</p>
      <div class="gallery-stage"><img v-if="!failed" :key="current.src" :src="current.src" :alt="current.alt" :width="current.width" :height="current.height" decoding="async" @load="loaded" @error="failed = true"><p v-else role="status">The image could not load. Try opening the full-size image.</p></div>
      <p class="gallery-caption">{{ current.caption }}</p>
      <div class="gallery-thumbnails" aria-label="Select a screenshot"><button v-for="(item, i) in selected.images" :key="item.src" class="gallery-thumb" :aria-label="`Show ${item.title}`" :aria-pressed="i === index" @click="select(i)"><img :src="item.thumb" alt="" :width="item.width" :height="item.height" loading="lazy"></button></div>
      <div class="dialog-bottom"><button class="button secondary" aria-label="Previous screenshot" @click="select(index - 1)"><span aria-hidden="true">←</span> Previous</button><span role="status" aria-live="polite" aria-atomic="true">{{ index + 1 }} / {{ selected.images.length }}</span><button class="button secondary" aria-label="Next screenshot" @click="select(index + 1)">Next <span aria-hidden="true">→</span></button></div>
      <a class="text-action full-image" :href="current.src" target="_blank" rel="noopener noreferrer">Open full-size image <span aria-hidden="true">↗</span><span class="sr-only"> in a new tab</span></a>
      <div class="detail-story"><div><h3>The idea</h3><p>{{ project.task }}</p><h3>What I built</h3><p>{{ project.contribution }}</p></div><div><h3>{{ project.id === 'moneymind' ? 'Implemented and planned' : 'Project status' }}</h3><p>{{ project.result }}</p><h3>About these visuals</h3><p>{{ selected.note }}</p><div v-if="project.links.length" class="detail-links"><a v-for="link in project.links" :key="link.href" :href="link.href" target="_blank" rel="noopener noreferrer" class="button secondary">{{ link.label }} <span aria-hidden="true">↗</span><span class="sr-only"> — opens in a new tab</span></a></div></div></div>
    </template>
  </dialog>
</template>
