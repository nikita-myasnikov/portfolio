<script setup lang="ts">
const props = defineProps<{ segments?: readonly string[] }>()
const pathSegments = computed(() => ['C:', 'Users', 'Nikita', 'Portfolio', ...(props.segments ?? [])])
const separator = '\\'
</script>

<template>
  <span class="folder-path"><span class="path-drive">{{ pathSegments[0] }}</span><template v-for="(segment, index) in pathSegments.slice(1)" :key="`${index}-${segment}`"><wbr><span class="path-segment">{{ separator }}{{ segment }}</span></template></span>
</template>
