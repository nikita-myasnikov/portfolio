<script setup lang="ts">
defineProps<{ id: string }>()
</script>
<template>
  <div class="concept-preview" aria-hidden="true">
<div v-if="id === 'autohub'"><div class="mini-window"><div class="mini-toolbar"><i></i><i></i><i></i><span>AutoHub-M</span></div><div class="booking"><aside><b>a.</b><span>Bookings</span><span>Schedule</span><span>History</span></aside><div><div class="mock-heading">Service bookings <small>Overview</small></div><div class="mock-row"><span>Diagnostics</span><em>New</em></div><div class="mock-row"><span>Maintenance</span><em>Confirmed</em></div><div class="mock-row"><span>Tyre service</span><em>Scheduled</em></div></div></div></div></div>
<div v-else-if="id === 'electric'"><div class="mini-window electric-window"><div class="electric-nav">electric / design <span>Services &nbsp; Contact</span></div><div class="electric-hero"><div><small>ENGINEERING</small><b>Designed<br>with care.</b><span class="mock-cta">Our services ↗</span></div><div class="electric-grid"><i></i><i></i><i></i></div></div><div class="electric-bottom"><span>Design</span><span>Installation</span><span>Maintenance</span></div></div></div>
<div v-else-if="id === 'moneymind'"><div class="finance-preview"><div class="finance-copy"><span>MoneyMind</span><b>Finances<br>in focus.</b><div class="finance-bars"><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div></div><div class="mini-phone"><div class="phone-notch"></div><span>Overview</span><small>Balance</small><b>—</b><div class="phone-row">Income <span>—</span></div><div class="phone-row">Expenses <span>—</span></div><small>Transactions</small><div class="phone-line"></div><div class="phone-line short"></div></div></div></div>
  </div>
</template>
