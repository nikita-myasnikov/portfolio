<script setup lang="ts">
import { contacts, sections, projects, projectTechnologies, skills, now } from './data/portfolio'
import { projectVisuals } from './data/projectVisuals'
import { copyEmailAddress } from './utils/clipboard.mjs'
import { motionStyles } from './utils/motionTokens.mjs'

const pageRoot = ref<HTMLElement | null>(null)
const glowElement = ref<HTMLElement | null>(null)
const headerElement = ref<HTMLElement | null>(null)
const navElement = ref<HTMLElement | null>(null)
const projectDetails = ref<{ open: (project: typeof projects[number], event: Event) => void } | null>(null)
const notice = ref('')
let noticeTimer: ReturnType<typeof setTimeout> | undefined
const activeSection = useSectionNavigation(pageRoot, navElement, headerElement)
usePortfolioMotion(pageRoot, glowElement)

async function copyEmail() {
  const copied = await copyEmailAddress(contacts.email)
  notice.value = copied ? 'Email copied' : 'Could not copy the email. Select the address and copy it manually.'
  if (noticeTimer) clearTimeout(noticeTimer)
  noticeTimer = setTimeout(() => { notice.value = '' }, copied ? 2600 : 6000)
}
onBeforeUnmount(() => { if (noticeTimer) clearTimeout(noticeTimer) })
</script>

<template>
  <div ref="pageRoot" class="portfolio-shell" :style="motionStyles">
    <div class="pointer-effects" aria-hidden="true"><div ref="glowElement" class="cursor-glow" /></div>
    <a class="skip" href="#main">Skip to content</a>
    <header ref="headerElement" class="site-header">
      <div class="nav-frame wrap">
        <a class="brand" href="#main" aria-label="Nikita Myasnikov — back to top">
          <span class="logo-crop"><img src="/assets/nm-logo.png" alt="Personal NM monogram" width="1254" height="1254"></span>
          <span class="brand-label">Nikita Myasnikov<span>Developer</span></span>
        </a>
        <nav ref="navElement" class="navigation" aria-label="Portfolio sections">
          <span class="nav-indicator" aria-hidden="true" />
          <a v-for="section in sections" :key="section.id" :href="`#${section.id}`" :data-section="section.id" :class="{ active: activeSection === section.id }" :aria-current="activeSection === section.id ? 'location' : undefined">{{ section.label }}</a>
        </nav>
      </div>
    </header>

    <main id="main" class="wrap">
      <div class="intro" aria-labelledby="hero-title">
        <div class="hero-ambient" aria-hidden="true" />
        <div class="intro-copy">
          <TerminalPath />
          <h1 id="hero-title"><span class="headline-first">Turning ideas</span> <span class="headline-second"><span class="headline-middle">into working</span> <span class="headline-last">software.</span></span></h1>
          <p>I’m Nikita Myasnikov, a developer building websites and applications with a focus on practical functionality and thoughtful design.</p>
          <div class="terminal-line"><span class="sr-only">Building websites. Developing applications. Turning ideas into software.</span><span aria-hidden="true" class="terminal-output"><span data-terminal-text>Building websites</span><span class="terminal-caret">_</span></span></div>
          <div class="intro-actions"><a class="button primary" href="#projects">Explore projects <span aria-hidden="true">↘</span></a><a class="button secondary" href="#contact">Get in touch <span aria-hidden="true">↗</span></a></div>
        </div>
      </div>

      <div class="technology-marquee" aria-label="Technologies used in these projects">
        <div class="marquee-window"><div class="marquee-track"><ul v-for="copy in 2" :key="copy" :aria-hidden="copy === 2 ? true : undefined" :class="{ 'marquee-duplicate': copy === 2 }"><li v-for="tech in projectTechnologies" :key="tech">{{ tech }}<span aria-hidden="true">/</span></li></ul></div></div>
      </div>

      <section id="projects" class="section projects-section" aria-labelledby="projects-title">
        <span id="work" class="anchor-alias" aria-hidden="true" />
        <div class="section-heading"><div><TerminalPath :segments="['Projects']" /><h2 id="projects-title">Projects</h2></div><p>The problem, the solution and the tools.<br>Four projects across different platforms.</p></div>
        <div class="projects-grid">
          <article v-for="project in projects" :id="project.id" :key="project.id" class="project-card">
            <div class="project-cover">
              <img class="real-preview" :src="projectVisuals[project.id]!.images[0]!.thumb" :alt="projectVisuals[project.id]!.images[0]!.alt" :width="projectVisuals[project.id]!.images[0]!.width" :height="projectVisuals[project.id]!.images[0]!.height" loading="lazy" decoding="async">
            </div>
            <div class="project-body">
              <h3><button class="project-open" :aria-label="`Open ${project.name} project details`" aria-haspopup="dialog" @click="projectDetails?.open(project, $event)">{{ project.name }}</button></h3>
              <p class="project-description">{{ project.description }}</p>
              <ul class="tags" aria-label="Project technologies"><li v-for="tech in project.technologies" :key="tech">{{ tech }}</li></ul>
              <span class="project-open-hint" aria-hidden="true">Explore project <span>↗</span></span>
            </div>
          </article>
        </div>

      </section>

      <section id="about" class="section about-section" aria-labelledby="about-title">
        <div class="section-heading"><div><TerminalPath :segments="['About']" /><h2 id="about-title">About me</h2></div></div>
        <div class="personal-layout">
          <div class="personal-story">
            <p class="personal-intro">I’m Nikita Myasnikov, a developer based in <span>Minsk, Belarus.</span> I build websites and desktop applications, focusing on clear interfaces and practical functionality.</p>
            <p class="personal-support">My projects include educational software, a car-service booking application, and websites for businesses. I enjoy developing an idea into a usable interface and refining the details that make it feel complete.</p>
          </div>
          <div class="personal-skills" aria-label="Technical skills">
            <span id="skills" class="anchor-alias" aria-hidden="true" />
            <div v-for="group in skills" :key="group.title" class="skill-cluster">
              <h3><span aria-hidden="true">{{ group.icon }}</span>{{ group.title }}</h3>
              <ul><li v-for="skill in group.items" :key="skill">{{ skill }}</li></ul>
            </div>
          </div>
        </div>
      </section>

      <section id="now" class="section now-section" aria-labelledby="now-title">
        <div class="section-heading"><div><TerminalPath :segments="['Now']" /><h2 id="now-title">Now</h2></div><p class="update-date">Updated {{ now.updatedAt }}</p></div>
        <ol class="activity-list">
          <li v-for="(entry, index) in now.entries" :key="entry.title" class="activity-entry">
            <span class="activity-index" aria-hidden="true">0{{ index + 1 }}</span>
            <h3>{{ entry.title }}</h3><p>{{ entry.text }}</p>
          </li>
        </ol>
      </section>

      <section id="contact" class="section contact-section" aria-labelledby="contact-title">
        <div class="contact-finale">
          <div class="contact-introduction">
            <TerminalPath :segments="['Contact']" />
            <h2 id="contact-title">Let’s build<br> something useful.</h2>
            <p>Have a website or application in mind, or an opportunity to discuss? I’d be happy to hear from you.</p>
          </div>
          <div class="contact-destinations">
            <a class="contact-link contact-email" :href="`mailto:${contacts.email}`">
              <svg class="contact-symbol" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="m4 7 8 6 8-6"/></svg>
              <span class="contact-link-copy"><span class="contact-label">Start a conversation</span><strong>{{ contacts.email }}</strong></span>
              <span class="contact-arrow" aria-hidden="true">↗</span>
            </a>
            <div class="contact-secondary">
              <a class="contact-link contact-profile" :href="contacts.github" target="_blank" rel="noopener noreferrer">
                <svg class="contact-symbol github-symbol" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 0 0-3.16 19.49c.5.09.68-.22.68-.48v-1.86c-2.78.6-3.37-1.18-3.37-1.18-.45-1.15-1.11-1.46-1.11-1.46-.91-.62.07-.61.07-.61 1 .07 1.53 1.03 1.53 1.03.89 1.53 2.34 1.09 2.91.83.09-.65.35-1.09.64-1.34-2.22-.25-4.55-1.11-4.55-4.94 0-1.09.39-1.98 1.03-2.68-.1-.25-.45-1.27.1-2.65 0 0 .84-.27 2.75 1.03A9.6 9.6 0 0 1 12 6.84c.85 0 1.71.11 2.51.34 1.91-1.3 2.75-1.03 2.75-1.03.55 1.38.2 2.4.1 2.65.64.7 1.03 1.59 1.03 2.68 0 3.84-2.34 4.69-4.57 4.94.36.31.68.92.68 1.85v2.74c0 .27.18.58.69.48A10 10 0 0 0 12 2Z"/></svg>
                <span class="contact-link-copy"><span class="contact-label">Code &amp; projects</span><strong>GitHub</strong></span>
                <span class="contact-arrow" aria-hidden="true">↗</span><span class="sr-only"> — profile opens in a new tab</span>
              </a>
              <button class="contact-link contact-copy-action" @click="copyEmail">
                <svg class="contact-symbol" viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="12" height="13" rx="2"/><path d="M15 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h3"/></svg>
                <span class="contact-link-copy"><span class="contact-label">Keep in touch</span><strong>Copy email</strong></span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </main>
    <footer class="footer wrap"><span>© 2026 Nikita Myasnikov</span><a href="#main">Back to top <span aria-hidden="true">↑</span></a></footer>
    <div class="toast" :class="{ visible: notice }" role="status" aria-live="polite" aria-atomic="true">{{ notice }}</div>
    <ProjectDetails ref="projectDetails" />
  </div>
</template>
