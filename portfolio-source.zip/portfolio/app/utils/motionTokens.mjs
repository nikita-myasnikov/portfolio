/** One source for the CSS and native animation timeline. All times are milliseconds. */
export const motion = Object.freeze({
  ease: 'cubic-bezier(.16,1,.3,1)',
  interaction: 300,
  pressed: 125,
  navigation: 420,
  reveal: 480,
  revealShift: 20,
  cardStagger: 75,
  label: 440,
  headline: 760,
  heroStart: 120,
  lineStagger: 90,
  support: 500,
  supportStart: 400,
  actionsStart: 460,
  ambient: 28000,
  typing: 90,
  erasing: 45,
  readPause: 2600,
  phraseGap: 350,
  highlight: 560,
  gallery: 300,
  marquee: 45000,
  pointerTimeConstant: 32,
  pointerTolerance: .15
});

export const motionStyles = Object.freeze({
  '--duration': `${motion.interaction}ms`,
  '--pressed-duration': `${motion.pressed}ms`,
  '--nav-duration': `${motion.navigation}ms`,
  '--reveal-duration': `${motion.reveal}ms`,
  '--marquee-duration': `${motion.marquee}ms`,
  '--ambient-duration': `${motion.ambient}ms`,
  '--ease': motion.ease
});
