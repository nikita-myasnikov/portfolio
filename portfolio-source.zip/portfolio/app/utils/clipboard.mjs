export async function copyEmailAddress(email, navigatorObject = navigator) {
  if (!navigatorObject.clipboard?.writeText) return false;
  try {
    await navigatorObject.clipboard.writeText(email);
    return true;
  } catch {
    return false;
  }
}
