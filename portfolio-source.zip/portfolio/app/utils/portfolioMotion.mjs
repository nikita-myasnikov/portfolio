import { motion } from './motionTokens.mjs';
import { installInteractionLighting } from './interactionLighting.mjs';

/** Native progressive enhancement: no styles hide content before successful animation setup. */
export function installPortfolioMotion(root, glow, win = window) {
  const reduced = win.matchMedia('(prefers-reduced-motion: reduce)');
  const finePointer = win.matchMedia('(hover: hover) and (pointer: fine)');
  const revealed = new WeakSet();
  let heroPlayed = false;
  let stopFeatures = () => {};

  function configure() {
    stopFeatures();
    const cleanup = [];
    const animations = new Map();
    const pending = new Set();
    let revealObserver;
    root.classList.toggle('motion-enabled', !reduced.matches);
    root.classList.toggle('pointer-enabled', !reduced.matches && finePointer.matches);
    const listen = (target, type, callback, options) => {
      target.addEventListener(type, callback, options);
      cleanup.push(() => target.removeEventListener(type, callback, options));
    };
    stopFeatures = () => cleanup.splice(0).reverse().forEach(stop => stop());

    function finish(element) {
      animations.get(element)?.cancel();
      animations.delete(element);
      element.classList.remove('motion-running');
      pending.delete(element);
      revealObserver?.unobserve(element);
      revealed.add(element);
    }
    function finishWithin(destination) {
      if (!destination) return;
      new Set([...pending, ...animations.keys()]).forEach(element => {
        if (element === destination || destination.contains?.(element) || element.contains?.(destination)) finish(element);
      });
    }
    function destinationFor(hash) {
      try { return win.document.getElementById?.(decodeURIComponent(hash.slice(1))); }
      catch { return null; }
    }
    function animate(element, duration, delay = 0, shift = motion.revealShift) {
      if (!element?.animate) return;
      try {
        const animation = element.animate([
          { opacity: 0, translate: `0 ${shift}px` },
          { opacity: 1, translate: '0 0' }
        ], { duration, delay, easing: motion.ease, fill: 'backwards' });
        animations.set(element, animation);
        element.classList.add('motion-running');
        const release = () => {
          if (animations.get(element) !== animation) return;
          animations.delete(element);
          element.classList.remove('motion-running');
        };
        animation.onfinish = release;
        animation.oncancel = release;
        if (win.document.hidden) animation.pause();
      } catch {
        // Unsupported or interrupted initialization leaves ordinary visible HTML.
        finish(element);
      }
    }
    cleanup.push(() => {
      [...animations.keys()].forEach(finish);
      root.classList.remove('ambient-running', 'ambient-ready');
    });

    if (!heroPlayed) {
      heroPlayed = true;
      const hero = root.querySelector?.('.intro');
      const paint = win.performance?.getEntriesByType?.('paint').find(entry => entry.name === 'first-contentful-paint');
      const late = paint && win.performance.now() - paint.startTime > 100;
      // A slow client or a deep link must never hide content that has already been read.
      if (!reduced.matches && !late && !win.document.hidden && hero && hero.getBoundingClientRect().top >= 0 && !win.location?.hash) {
        animate(hero.querySelector('.folder-path'), motion.label, 0, 10);
        const lines = win.innerWidth <= 800
          ? ['.headline-first', '.headline-middle', '.headline-last']
          : ['.headline-first', '.headline-second'];
        lines.forEach((selector, index) => animate(hero.querySelector(selector), motion.headline, motion.heroStart + index * motion.lineStagger));
        animate(hero.querySelector('.intro-copy > p'), motion.support, motion.supportStart, 14);
        animate(hero.querySelector('.intro-actions'), motion.support, motion.actionsStart, 12);
      }
    }
    if (reduced.matches) return;
    cleanup.push(installInteractionLighting(root, win));

    if (win.IntersectionObserver) {
      const blocks = [...root.querySelectorAll('.section-heading, .project-card, .personal-story, .personal-skills, .activity-entry, .contact-finale')];
      const cards = blocks.filter(block => block.classList.contains('project-card'));
      revealObserver = new win.IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (!entry.isIntersecting || !pending.has(entry.target)) return;
          pending.delete(entry.target);
          revealed.add(entry.target);
          revealObserver.unobserve(entry.target);
          const index = cards.indexOf(entry.target);
          const delay = index < 0 ? 0 : index % 2 * motion.cardStagger;
          animate(entry.target, motion.reveal, delay);
        });
      }, { threshold: .01, rootMargin: '0px 0px 56px 0px' });
      blocks.forEach(block => {
        if (revealed.has(block)) return;
        if (block.getBoundingClientRect().top < win.innerHeight) { revealed.add(block); return; }
        pending.add(block);
        revealObserver.observe(block);
      });
      cleanup.push(() => { revealObserver.disconnect(); pending.clear(); });

      const hero = root.querySelector?.('.intro');
      if (hero) {
        let inView = false;
        const updateAmbient = () => root.classList.toggle('ambient-running', inView && !win.document.hidden);
        const ambientObserver = new win.IntersectionObserver(entries => {
          inView = entries.some(entry => entry.isIntersecting);
          updateAmbient();
        });
        root.classList.add('ambient-ready');
        ambientObserver.observe(hero);
        listen(win.document, 'visibilitychange', updateAmbient);
        cleanup.push(() => ambientObserver.disconnect());
      }
    }

    listen(root, 'focusin', event => finishWithin(event.target));
    listen(root, 'click', event => {
      const link = event.target?.closest?.('a[href^="#"]');
      if (link && root.contains(link)) finishWithin(destinationFor(link.getAttribute('href')));
    });
    listen(win, 'hashchange', () => finishWithin(destinationFor(win.location?.hash ?? '')));
    finishWithin(destinationFor(win.location?.hash ?? ''));
    listen(win.document, 'visibilitychange', () => {
      animations.forEach(animation => win.document.hidden ? animation.pause() : animation.play());
    });
    // Switching between responsive headline arrangements must never retain nested effects.
    listen(win, 'resize', () => finishWithin(root.querySelector?.('.intro')), { passive: true });

    if (!finePointer.matches || !glow) return;
    let frame = 0, x = 0, y = 0, targetX = 0, targetY = 0, lastTime = 0;
    let visible = false, dirty = false;
    let candidate = null, surface = null;
    const touched = new Set();
    function resetSurface() {
      surface?.classList.remove('pointer-active');
      surface = null;
    }
    function tick(time) {
      frame = 0;
      const dt = lastTime ? Math.min(32, Math.max(1, time - lastTime)) : 1000 / 60;
      lastTime = time || 0;
      if (!visible) {
        x = targetX; y = targetY; visible = true;
        glow.classList.add('is-active');
      } else {
        const amount = 1 - Math.exp(-dt / motion.pointerTimeConstant);
        x += (targetX - x) * amount;
        y += (targetY - y) * amount;
      }
      // Read the small active surface before any style writes, once per input frame.
      const rect = dirty ? candidate?.getBoundingClientRect() : null;
      glow.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      if (dirty) {
        if (candidate !== surface) { resetSurface(); surface = candidate; }
        if (surface && rect) {
          surface.style.setProperty('--spot-x', `${Math.max(0, Math.min(rect.width, targetX - rect.left))}px`);
          surface.style.setProperty('--spot-y', `${Math.max(0, Math.min(rect.height, targetY - rect.top))}px`);
          surface.classList.add('pointer-active');
          touched.add(surface);
        }
        dirty = false;
      }
      if (Math.abs(targetX - x) + Math.abs(targetY - y) > motion.pointerTolerance) frame = win.requestAnimationFrame(tick);
      else { lastTime = 0; glow.classList.remove('is-tracking'); }
    }
    function move(event) {
      if (event.pointerType === 'touch') { hide(); return; }
      if (win.document.hidden || (event.pointerType !== 'mouse' && event.pointerType !== 'pen')) return;
      if (!root.contains(event.target)) { hide(); return; }
      targetX = event.clientX; targetY = event.clientY;
      const next = event.target?.closest?.('.project-card, .button, .contact-link, .copy-button, .icon-button, .gallery-thumb, .text-action');
      candidate = next && root.contains(next) ? next : null;
      dirty = true;
      glow.classList.add('is-tracking');
      if (!frame) frame = win.requestAnimationFrame(tick);
    }
    function hide() {
      visible = false; dirty = false; candidate = null; lastTime = 0;
      glow.classList.remove('is-active', 'is-tracking');
      if (frame) win.cancelAnimationFrame(frame);
      frame = 0;
      // Keep the last local coordinates while opacity fades out.
      resetSurface();
    }
    listen(win, 'pointermove', move, { passive: true });
    listen(win, 'pointerout', event => { if (!event.relatedTarget) hide(); });
    listen(win, 'blur', hide);
    listen(win, 'keydown', event => { if (event.key === 'Tab') hide(); });
    listen(win, 'scroll', hide, { passive: true });
    listen(win, 'resize', hide, { passive: true });
    listen(win.document, 'visibilitychange', () => { if (win.document.hidden) hide(); });
    cleanup.push(() => {
      hide();
      touched.forEach(element => {
        element.style.removeProperty('--spot-x');
        element.style.removeProperty('--spot-y');
      });
      glow.style.removeProperty('transform');
    });
  }
  const reconfigure = () => {
    try { configure(); }
    catch { stopFeatures(); root.classList.remove('motion-enabled', 'pointer-enabled'); }
  };
  reduced.addEventListener('change', reconfigure);
  finePointer.addEventListener('change', reconfigure);
  reconfigure();
  return () => {
    stopFeatures();
    reduced.removeEventListener('change', reconfigure);
    finePointer.removeEventListener('change', reconfigure);
    root.classList.remove('motion-enabled', 'pointer-enabled');
  };
}
