import { motion } from './motionTokens.mjs';

const controls = 'a, button, summary';
/** A single activation light, shared by pointer and keyboard. Never delays the action. */
export function installInteractionLighting(root, win = window) {
  const doc = win.document;
  const background = root.querySelector('.pointer-effects');
  const cleanups = [], pulses = new Set(), hosts = new Set();
  let gesture = null;
  const listen = (target, type, fn, options) => {
    target.addEventListener(type, fn, options);
    cleanups.push(() => target.removeEventListener(type, fn, options));
  };
  const reset = () => { gesture = null; [...pulses].forEach(pulse => pulse.cancel()); };
  listen(root, 'pointerdown', event => {
    gesture = event.button === 0 && event.isPrimary !== false ? {
      id: event.pointerId, x: event.clientX, y: event.clientY, target: event.target,
      cancelled: false, released: false
    } : null;
  }, { passive: true });
  listen(root, 'pointermove', event => {
    if (gesture?.id === event.pointerId && Math.hypot(event.clientX - gesture.x, event.clientY - gesture.y) > 8) gesture.cancelled = true;
  }, { passive: true });
  listen(root, 'pointercancel', event => { if (gesture?.id === event.pointerId) gesture.cancelled = true; });
  listen(root, 'pointerup', event => {
    if (gesture?.id !== event.pointerId) return;
    gesture.released = true;
    if (Math.hypot(event.clientX - gesture.x, event.clientY - gesture.y) > 8) gesture.cancelled = true;
  }, { passive: true });
  // Scroll can start without another pointermove; suppress its subsequent synthetic click.
  listen(win, 'scroll', () => { if (gesture) gesture.cancelled = true; }, { passive: true, capture: true });
  listen(root, 'click', event => {
    if (doc.hidden || !root.contains(event.target)) return;
    const control = event.target.closest?.(controls);
    const keyboard = event.detail === 0;
    const accepted = keyboard ? !!control : gesture?.released && !gesture.cancelled;
    gesture = null;
    if (!accepted || control?.disabled || control?.getAttribute('aria-disabled') === 'true') return;
    // Text selection and drag gestures retain their normal behavior, without a pulse.
    if (!keyboard && win.getSelection?.()?.toString()) return;
    const project = control?.closest?.('.project-card');
    const host = project || control || background;
    if (!host || !doc.createElement) return;
    const rect = host.getBoundingClientRect();
    const local = host !== background;
    const x = keyboard ? rect.width / 2 : event.clientX - (local ? rect.left : 0);
    const y = keyboard ? rect.height / 2 : event.clientY - (local ? rect.top : 0);
    // For full-card hit areas the click may land on the image: keep its colors untouched.
    const cx = local ? Math.max(0, Math.min(rect.width, x)) : x;
    const bodyTop = project?.querySelector('.project-body')?.getBoundingClientRect().top;
    const lowerEdge = bodyTop == null ? 0 : bodyTop - rect.top;
    const cy = local ? Math.max(lowerEdge, Math.min(rect.height, y)) : y;
    const light = doc.createElement('span');
    light.className = 'click-light';
    light.setAttribute('aria-hidden', 'true');
    const size = local ? Math.min(420, Math.max(140, rect.width * 1.1)) : 340;
    Object.assign(light.style, { left: `${cx}px`, top: `${cy}px`, width: `${size}px`, height: `${size}px` });
    if (local) { host.classList.add('light-host'); hosts.add(host); }
    host.appendChild(light);
    try {
      const animation = light.animate([
        { opacity: 0, transform: 'translate(-50%, -50%) scale(.12)' },
        { opacity: .75, transform: 'translate(-50%, -50%) scale(.36)', offset: .16 },
        { opacity: 0, transform: 'translate(-50%, -50%) scale(1)' }
      ], { duration: motion.highlight, easing: motion.ease });
      const done = () => { pulses.delete(animation); light.remove(); };
      animation.onfinish = done;
      animation.oncancel = done;
      pulses.add(animation);
      // Hard bound for repeated activations; completed effects remove themselves.
      if (pulses.size > 4) pulses.values().next().value.cancel();
    } catch { light.remove(); }
  });
  listen(doc, 'visibilitychange', () => { if (doc.hidden) reset(); });
  listen(win, 'blur', reset);
  return () => { reset(); cleanups.reverse().forEach(stop => stop()); hosts.forEach(host => host.classList.remove('light-host')); };
}
