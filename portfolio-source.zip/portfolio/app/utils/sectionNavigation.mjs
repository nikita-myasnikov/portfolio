export function installSectionNavigation(root, nav, header, onActive, win = window) {
  const sectionIds = ['projects', 'about', 'now', 'contact'];
  const sections = sectionIds.map(id => root.querySelector(`#${id}`)).filter(Boolean);
  let frame = 0;
  let current = '';
  let lastHeaderHeight, lastIndicatorX, lastIndicatorWidth;
  const update = () => {
    frame = 0;
    const headerBox = header.getBoundingClientRect();
    const headerBottom = headerBox.bottom;
    const headerHeight = headerBox.height + 20;
    let active = sections[0]?.id ?? 'projects';
    for (const section of sections) {
      if (section.getBoundingClientRect().top <= headerBottom + 64) active = section.id;
    }
    if (win.scrollY + win.innerHeight >= win.document.documentElement.scrollHeight - 3) active = 'contact';
    const link = nav.querySelector(`[data-section="${active}"]`);
    const box = link?.getBoundingClientRect();
    const navBox = box ? nav.getBoundingClientRect() : null;
    // Batch all geometry reads before writes and skip unchanged values while scrolling.
    if (headerHeight !== lastHeaderHeight) {
      lastHeaderHeight = headerHeight;
      win.document.documentElement.style.setProperty('--header-height', `${headerHeight}px`);
    }
    if (active !== current) { current = active; onActive(active); }
    if (link) {
      const x = box.left - navBox.left;
      if (x !== lastIndicatorX) { lastIndicatorX = x; nav.style.setProperty('--indicator-x', `${x}px`); }
      if (box.width !== lastIndicatorWidth) { lastIndicatorWidth = box.width; nav.style.setProperty('--indicator-width', `${box.width}px`); }
      nav.classList.add('navigation-ready');
    }
  };
  const schedule = () => { if (!frame) frame = win.requestAnimationFrame(update); };
  win.addEventListener('scroll', schedule, { passive: true });
  win.addEventListener('resize', schedule, { passive: true });
  win.addEventListener('hashchange', schedule);
  const resizeObserver = win.ResizeObserver ? new win.ResizeObserver(schedule) : null;
  resizeObserver?.observe(header);
  resizeObserver?.observe(nav);
  update();
  return () => {
    win.removeEventListener('scroll', schedule);
    win.removeEventListener('resize', schedule);
    win.removeEventListener('hashchange', schedule);
    resizeObserver?.disconnect();
    if (frame) win.cancelAnimationFrame(frame);
    nav.classList.remove('navigation-ready');
    win.document.documentElement.style.removeProperty('--header-height');
  };
}
