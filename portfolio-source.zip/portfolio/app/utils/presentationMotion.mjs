import { motion } from './motionTokens.mjs';

export const terminalPhrases = ['Building websites', 'Developing applications', 'Turning ideas into software'];
export function advanceTerminal(state) {
  const phrase = terminalPhrases[state.phrase];
  if (!state.erasing && state.length < phrase.length) return { ...state, length: state.length + 1, delay: motion.typing };
  if (!state.erasing) return { ...state, erasing: true, delay: motion.readPause };
  if (state.length > 0) return { ...state, length: state.length - 1, delay: motion.erasing };
  return { phrase: (state.phrase + 1) % terminalPhrases.length, length: 0, erasing: false, delay: motion.phraseGap };
}

/** Local DOM effects; no application render on each typed letter or pointer event. */
export function installPresentationMotion(root, win = window) {
  const doc = win.document;
  const reduced = win.matchMedia('(prefers-reduced-motion: reduce)');
  const terminal = root.querySelector('.terminal-line');
  const output = terminal?.querySelector('[data-terminal-text]');
  const marquee = root.querySelector('.technology-marquee');
  const cleanups = [];
  let visibleHero = false, visibleMarquee = false;
  let timer = null;
  let state = { phrase: 0, length: terminalPhrases[0].length, erasing: true, delay: motion.readPause };
  const listen = (target, type, fn) => {
    if (!target) return;
    target.addEventListener(type, fn);
    cleanups.push(() => target.removeEventListener(type, fn));
  };
  const stopTyping = () => { if (timer !== null) win.clearTimeout(timer); timer = null; };
  const paintText = () => { if (output) output.textContent = terminalPhrases[state.phrase].slice(0, state.length); };
  function tick() {
    timer = null;
    state = advanceTerminal(state);
    paintText();
    timer = win.setTimeout(tick, state.delay);
  }
  function update() {
    stopTyping();
    const typing = !reduced.matches && !doc.hidden && visibleHero;
    terminal?.classList.toggle('terminal-running', typing);
    if (reduced.matches) {
      if (output) output.textContent = terminalPhrases[0];
    } else {
      paintText();
      if (typing) timer = win.setTimeout(tick, state.delay);
    }
    marquee?.classList.toggle('marquee-running', !reduced.matches && !doc.hidden && visibleMarquee);
  }
  listen(doc, 'visibilitychange', update);
  listen(reduced, 'change', update);
  if (win.IntersectionObserver) {
    const observer = new win.IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.target === terminal) visibleHero = entry.isIntersecting;
        if (entry.target === marquee) visibleMarquee = entry.isIntersecting;
      });
      update();
    });
    if (terminal) observer.observe(terminal);
    if (marquee) observer.observe(marquee);
    cleanups.push(() => observer.disconnect());
  }
  update();
  return () => { stopTyping(); cleanups.reverse().forEach(fn => fn()); terminal?.classList.remove('terminal-running'); marquee?.classList.remove('marquee-running'); };
}
