export type ProjectImage = { src: string; thumb: string; width: number; height: number; title: string; alt: string; provenance: string; caption: string }
export type ProjectVisuals = { images: ProjectImage[]; note: string }

export const projectVisuals: Record<string, ProjectVisuals> = {
  "educore": {
    "images": [
      {
        "src": "/assets/projects/educore-dashboard.webp",
        "thumb": "/assets/projects/educore-dashboard-preview.webp",
        "width": 2940,
        "height": 1844,
        "title": "Administrator overview",
        "alt": "EDUCore desktop administrator dashboard with course and attendance statistics",
        "provenance": "Application screenshot",
        "caption": "Original desktop interface from the academic project report."
      },
      {
        "src": "/assets/projects/educore-course-library.webp",
        "thumb": "/assets/projects/educore-course-library-preview.webp",
        "width": 2940,
        "height": 1850,
        "title": "Course management",
        "alt": "EDUCore course library with course cards and management actions",
        "provenance": "Application screenshot",
        "caption": "Course management in the administrator workspace."
      },
      {
        "src": "/assets/projects/educore-registration.webp",
        "thumb": "/assets/projects/educore-registration-preview.webp",
        "width": 2940,
        "height": 1912,
        "title": "Role-based registration",
        "alt": "EDUCore registration form with a learner role selected",
        "provenance": "Application screenshot",
        "caption": "Original registration interface with role selection."
      },
      {
        "src": "/assets/projects/educore-role-guide.webp",
        "thumb": "/assets/projects/educore-role-guide-preview.webp",
        "width": 2940,
        "height": 1912,
        "title": "Role-specific guidance",
        "alt": "EDUCore help screen explaining administrator permissions and access through study groups",
        "provenance": "Application screenshot",
        "caption": "The in-app guide describes administrator tools and group-based access for learners."
      }
    ],
    "note": "Original desktop application screens. The source application uses Russian."
  },
  "autohub": {
    "images": [
      {
        "src": "/assets/projects/autohub-booking.webp",
        "thumb": "/assets/projects/autohub-booking-preview.webp",
        "width": 2047,
        "height": 1331,
        "title": "Customer booking overview",
        "alt": "AutoHub M demonstration booking page with service options and a visible connection error",
        "provenance": "Application screenshot",
        "caption": "Saved demo capture. The server was unavailable when this screen was recorded; the error is part of the original screenshot."
      },
      {
        "src": "/assets/projects/autohub-booking-form.webp",
        "thumb": "/assets/projects/autohub-booking-form-preview.webp",
        "width": 2047,
        "height": 1331,
        "title": "Booking form",
        "alt": "AutoHub M booking form showing unavailable services during a connection error",
        "provenance": "Application screenshot",
        "caption": "Original customer-flow capture, including the unavailable-service state. No customer records are shown."
      },
      {
        "src": "/assets/projects/autohub-owner.webp",
        "thumb": "/assets/projects/autohub-owner-preview.webp",
        "width": 636,
        "height": 827,
        "title": "Owner calendar · earlier demo",
        "alt": "Earlier car-service demo owner dashboard with a confirmed test-client appointment",
        "provenance": "Application screenshot",
        "caption": "Earlier demo iteration with its original “ПОСТ №1” branding. The appointment explicitly uses a test client and test vehicle."
      }
    ],
    "note": "Genuine demo captures, including an earlier owner-dashboard iteration. Customer screens show the saved connection-error state."
  },
  "electric": {
    "images": [
      {
        "src": "/assets/projects/electric-desktop.webp",
        "thumb": "/assets/projects/electric-desktop-preview.webp",
        "width": 1440,
        "height": 868,
        "title": "Desktop introduction",
        "alt": "Electric Design draft desktop homepage with electrical-network design introduction and transformer photograph",
        "provenance": "Redesign draft screenshot",
        "caption": "Captured responsive redesign draft; the linked original website is a separate version."
      },
      {
        "src": "/assets/projects/electric-mobile.webp",
        "thumb": "/assets/projects/electric-mobile-preview.webp",
        "width": 375,
        "height": 820,
        "title": "Mobile introduction",
        "alt": "Electric Design draft at 375 pixels wide with a compact header, introduction and contact action",
        "provenance": "Redesign draft screenshot",
        "caption": "Original 375-pixel mobile capture of the draft."
      },
      {
        "src": "/assets/projects/electric-services.webp",
        "thumb": "/assets/projects/electric-services-preview.webp",
        "width": 1440,
        "height": 846,
        "title": "Services",
        "alt": "Electric Design draft services section with three service categories",
        "provenance": "Redesign draft screenshot",
        "caption": "Original desktop services section from the same redesign draft."
      },
      {
        "src": "/assets/projects/electric-overview.webp",
        "thumb": "/assets/projects/electric-overview-preview.webp",
        "width": 815,
        "height": 2048,
        "title": "Full-page overview",
        "alt": "Electric Design full-page draft showing introduction, services, about and contact sections",
        "provenance": "Redesign draft screenshot",
        "caption": "Original full-page capture. The source is 815 pixels wide; the separate section views provide more readable detail."
      }
    ],
    "note": "Real screenshots of the unpublished redesign draft, including desktop and mobile. The link opens the original company website."
  },
  "moneymind": {
    "images": [
      {
        "src": "/assets/projects/moneymind-overview.webp",
        "thumb": "/assets/projects/moneymind-overview-preview.webp",
        "width": 2160,
        "height": 1500,
        "title": "Overview · Learning dashboard",
        "alt": "MoneyMind interface design with fictional learning progress, a featured budgeting lesson and a 50/30/20 example chart",
        "provenance": "UI redesign concept",
        "caption": "New HTML/CSS interface design, rendered from the working prototype. All learner progress and budget figures are fictional."
      },
      {
        "src": "/assets/projects/moneymind-learning.webp",
        "thumb": "/assets/projects/moneymind-learning-preview.webp",
        "width": 2160,
        "height": 1500,
        "title": "Learning · Topics and lesson",
        "alt": "MoneyMind learning interface with topic cards, a budgeting lesson and an accessible proportional allocation diagram",
        "provenance": "UI redesign concept",
        "caption": "New interface design with three switchable example lessons. The educational lesson library and saved progress remain planned mobile-app work."
      },
      {
        "src": "/assets/projects/moneymind-practice.webp",
        "thumb": "/assets/projects/moneymind-practice-preview.webp",
        "width": 2160,
        "height": 1500,
        "title": "Practice · Answer feedback",
        "alt": "MoneyMind practice interface showing a percentage question, selected answer, feedback and a worked explanation",
        "provenance": "UI redesign concept",
        "caption": "New interface design with working local answer feedback and reset. The selected correct answer is an illustrative state; no financial backend is connected."
      }
    ],
    "note": "Newly designed, renderable HTML/CSS interfaces for the in-progress project. These are rendered views of the presentation prototype, not screenshots of an integrated mobile release. All learner records and figures are fictional. Open the prototype to explore its lessons and local quiz feedback."
  }
}
