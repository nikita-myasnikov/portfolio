export const contacts = {
  email: 'nikitamyasnikov127@gmail.com',
  github: 'https://github.com/nikitamyasnikov127-cmyk',
  // Only render a Telegram destination after it has been confirmed.
  telegram: null as string | null
}

export const sections = [
  { id: 'projects', label: 'Projects' },
  { id: 'about', label: 'About me' },
  { id: 'now', label: 'Now' },
  { id: 'contact', label: 'Contact' }
]

const projectContent = [
  {
    id: 'autohub', name: 'AutoHub M', kind: 'Web application', status: 'Demo project',
    description: 'An online booking system for a car service, with an owner dashboard that brings requests, scheduling and customer history together.',
    technologies: ['SQLite', 'PWA'], image: null,
    task: 'Connect customer bookings with the day-to-day work of a car service.',
    contribution: 'Implemented booking workflows, confirmations, rescheduling and cancellation, customer history and private notes for the owner.',
    result: 'A working demonstration with booking reservation checks and a recorded walkthrough of the main workflows.',
    links: [] as { label: string; href: string }[]
  },
  {
    id: 'electric', name: 'Electric Design', kind: 'Company website', status: 'Redesign draft',
    description: 'A company homepage redesign with clearer service information, accessible contact details and a layout adapted for mobile.',
    technologies: ['WordPress', 'Onest', 'Inter'], image: null,
    task: 'Make the company’s services and contact information easier to explore on desktop and mobile.',
    contribution: 'Reworked typography, service cards, spacing, mobile navigation and the arrangement of contact information.',
    result: 'Prepared a responsive homepage draft. The link opens the original company website; the redesign has not been published.',
    links: [{ label: 'Original website', href: 'https://www.electric-design.by/' }]
  },
  {
    id: 'educore', name: 'EDUCore', kind: 'Desktop application', status: 'Academic project',
    description: 'A course management application with groups and classes, separate user roles, statistics and reports.',
    technologies: ['C++17', 'Qt Widgets', 'SQLite'], image: '/assets/projects/educore-overview.png',
    task: 'Organise courses, study groups and educational records in one application.',
    contribution: 'Built administrator, teacher and student interfaces, SQLite storage, course and group management, statistics and reporting.',
    result: 'An academic desktop application with role-based access and a local database. The preview is an actual screenshot from the project report.',
    links: [] as { label: string; href: string }[]
  },
  {
    id: 'moneymind', name: 'MoneyMind', kind: 'Financial education', status: 'In progress · New interface design',
    description: 'A financial-literacy application in progress, with a newly designed learning space, budgeting examples and knowledge practice.',
    technologies: ['React Native', 'Expo', 'TypeScript', 'Supabase'], image: null,
    task: 'Make financial concepts easier to understand through short lessons, fictional worked examples and immediate practice feedback.',
    contribution: 'The earlier mobile foundation covers navigation, authentication, profiles and transaction records. This update adds a renderable HTML/CSS educational interface: overview, learning topics, lesson details and a local interactive quiz.',
    result: 'Implemented for this presentation: three linked web screens, lesson switching and quiz answer feedback using fictional data. Planned: integrate this educational experience into the mobile app, add a complete lesson library and persist learning progress.',
    links: [{ label: 'Open interface prototype', href: '/moneymind/index.html' }]
  }
]

export const projects = ['educore', 'autohub', 'electric', 'moneymind'].map(id => projectContent.find(project => project.id === id)!)
export const projectTechnologies = [...new Set(projects.flatMap(project => project.technologies))].filter(tech => !['Onest', 'Inter'].includes(tech))

export const skills = [
  { title: 'Languages', icon: '{ }', items: ['C++', 'C#', 'TypeScript'] },
  { title: 'Frameworks', icon: '</>', items: ['Qt Widgets', '.NET', 'React Native', 'Expo', 'Vue', 'Nuxt'] },
  { title: 'Tools', icon: '[ ]', items: ['SQLite', 'Supabase', 'WordPress', 'Git'] }
]

// Current activities supplied by Nikita; these are not additional project cards.
export const now = {
  updatedAt: 'October 11, 2026',
  entries: [
    {
      title: 'Refining MoneyMind',
      text: 'I’m continuing work on MoneyMind, my financial-literacy application, improving its interface and developing the learning experience.'
    },
    {
      title: 'Building the LKB website',
      text: 'I’m developing a website for LKB, a car service, with a focus on presenting its services through a clear, modern interface.'
    }
  ]
}

export type PortfolioProject = typeof projects[number]
