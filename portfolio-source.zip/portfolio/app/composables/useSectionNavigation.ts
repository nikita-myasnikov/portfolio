import type { Ref } from 'vue'
import { installSectionNavigation } from '../utils/sectionNavigation.mjs'
export function useSectionNavigation(root: Ref<HTMLElement | null>, nav: Ref<HTMLElement | null>, header: Ref<HTMLElement | null>) {
  const active = ref('projects')
  let dispose = () => {}
  onMounted(() => {
    if (root.value && nav.value && header.value) dispose = installSectionNavigation(root.value, nav.value, header.value, (id: string) => { active.value = id })
  })
  onBeforeUnmount(() => dispose())
  return active
}
