import type { Ref } from 'vue'
import { installPresentationMotion } from '../utils/presentationMotion.mjs'
import { installPortfolioMotion } from '../utils/portfolioMotion.mjs'

export function usePortfolioMotion(
  root: Ref<HTMLElement | null>,
  glow: Ref<HTMLElement | null>
) {
  let dispose = () => {}
  onMounted(() => {
    if (root.value) {
      const stopMotion = installPortfolioMotion(root.value, glow.value)
      const stopPresentation = installPresentationMotion(root.value)
      dispose = () => { stopPresentation(); stopMotion() }
    }
  })
  onBeforeUnmount(() => dispose())
}
