<script setup lang="ts">
import { motionStyles } from './utils/motionTokens.mjs'
const props = defineProps<{ error: { statusCode?: number } }>()
const missing = computed(() => props.error.statusCode === 404)
useHead({ title: computed(() => missing.value ? 'Page not found — Nikita Myasnikov' : 'Could not load the page — Nikita Myasnikov'), htmlAttrs: { lang: 'en' } })
</script>

<template>
  <main class="error-page wrap" :style="motionStyles">
    <span class="eyebrow">Nikita Myasnikov · Portfolio</span>
    <h1>{{ missing ? 'Page not found' : 'Could not load the page' }}</h1>
    <p>{{ missing ? 'The link may be out of date. All portfolio sections are available on the homepage.' : 'Try returning to the homepage.' }}</p>
    <a class="button primary" href="/">Back to home <span aria-hidden="true">↗</span></a>
  </main>
</template>
