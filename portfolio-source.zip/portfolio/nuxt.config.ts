export default defineNuxtConfig({
  compatibilityDate: '2026-10-11',
  devtools: { enabled: false },
  css: ['~/assets/css/main.css'],
  app: {
    head: {
      htmlAttrs: { lang: 'en' },
      title: 'Nikita Myasnikov — Developer',
      meta: [
        { name: 'viewport', content: 'width=device-width, initial-scale=1' },
        { name: 'theme-color', content: '#0c0b12' },
        { name: 'description', content: 'Nikita Myasnikov — a developer building websites and applications with practical functionality and thoughtful design. Explore projects, technologies and my approach to development.' },
        { property: 'og:title', content: 'Nikita Myasnikov — Developer' },
        { property: 'og:description', content: 'Turning ideas into working software. Explore web, desktop and mobile projects by Nikita Myasnikov.' },
        { property: 'og:type', content: 'website' },
        { property: 'og:locale', content: 'en_US' }
      ],
      link: [
        { rel: 'canonical', href: 'https://nikita-myasnikov.nikitamyasnikov127.chatgpt.site/' },
        { rel: 'preload', href: '/assets/fonts/b612-400.woff2', as: 'font', type: 'font/woff2', crossorigin: '' },
        { rel: 'preload', href: '/assets/fonts/b612-700.woff2', as: 'font', type: 'font/woff2', crossorigin: '' },
        { rel: 'preload', href: '/assets/fonts/b612-mono-400.woff2', as: 'font', type: 'font/woff2', crossorigin: '' },
        { rel: 'icon', href: '/assets/favicon.svg', type: 'image/svg+xml' }
      ]
    }
  },
  nitro: { prerender: { routes: ['/'], crawlLinks: false, failOnError: true } }
})
