#ifndef DIALOG_H
#define DIALOG_H

#include <QDate>
#include <QDialog>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(int userId = -1, QWidget *parent = nullptr);
    ~Dialog();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_calendarWidget_clicked(const QDate &date);
    void on_pushButton_4_clicked();
    void on_pushButton_3_clicked();

private:
    bool initPlannerTables();
    QString buildTasksText() const;
    void showTextWindow(const QString &title, const QString &text);

    Ui::Dialog *ui;
    int currentUserId;

signals:
     void signal();

};

#endif // DIALOG_H
