QT += core gui sql

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

TEMPLATE = app
TARGET = TestPlanner

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    dialog.cpp \
    task.cpp \
    calendar.cpp \
    edit.cpp \
    myplans.cpp \
    mykontakts.cpp \
    registerdialog.cpp \
    profiledialog.cpp

HEADERS += \
    mainwindow.h \
    dialog.h \
    task.h \
    calendar.h \
    edit.h \
    myplans.h \
    mykontakts.h \
    registerdialog.h \
    profiledialog.h

FORMS += \
    mainwindow.ui \
    dialog.ui \
    task.ui \
    calendar.ui \
    edit.ui \
    myplans.ui \
    mykontakts.ui
