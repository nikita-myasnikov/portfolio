#include "calendar.h"
#include "ui_calendar.h"

#include <QDateTime>
#include <QMessageBox>
#include <QPushButton>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

Calendar::Calendar(const QDate &date, int userId, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Calendar),
    selectedDate(date.isValid() ? date : QDate::currentDate()),
    currentUserId(userId)
{
    ui->setupUi(this);
    this->setWindowTitle("Задача на " + selectedDate.toString("dd.MM.yyyy"));
    connect(ui->exitButton, &QPushButton::clicked, this, [this]() {
        if (QDialog *parentDialog = qobject_cast<QDialog*>(parentWidget())) {
            parentDialog->accept();
        }
        this->accept();
    });
    initPlannerTables();
}

Calendar::~Calendar()
{
    delete ui;
}

bool Calendar::initPlannerTables()
{
    if (!QSqlDatabase::contains("users_connection")) {
        return false;
    }

    QSqlDatabase db = QSqlDatabase::database("users_connection");
    if (!db.isOpen() && !db.open()) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось открыть базу данных: " + db.lastError().text());
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec("CREATE TABLE IF NOT EXISTS tasks ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    "user_id INTEGER, "
                    "title TEXT NOT NULL, "
                    "description TEXT NOT NULL, "
                    "task_date TEXT, "
                    "created_at TEXT NOT NULL)")) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось создать таблицу задач: " + query.lastError().text());
        return false;
    }

    return true;
}

void Calendar::on_pushButton_clicked()
{
    const QString taskclr = ui->taskcl->text().trimmed();
    const QString descriptionclr = ui->descriptioncl->text().trimmed();

    if (taskclr.isEmpty() || descriptionclr.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, заполните все поля.");
        return;
    }

    if (!initPlannerTables()) {
        return;
    }

    QSqlDatabase db = QSqlDatabase::database("users_connection");

    QSqlQuery duplicateQuery(db);
    duplicateQuery.prepare("SELECT id FROM tasks WHERE user_id = :user_id AND title = :title AND task_date = :task_date");
    duplicateQuery.bindValue(":user_id", currentUserId);
    duplicateQuery.bindValue(":title", taskclr);
    duplicateQuery.bindValue(":task_date", selectedDate.toString(Qt::ISODate));
    if (duplicateQuery.exec() && duplicateQuery.next()) {
        QMessageBox::warning(this, "Ошибка", "Задача с таким названием уже есть на выбранную дату.");
        return;
    }

    QSqlQuery query(db);
    query.prepare("INSERT INTO tasks (user_id, title, description, task_date, created_at) "
                  "VALUES (:user_id, :title, :description, :task_date, :created_at)");
    query.bindValue(":user_id", currentUserId);
    query.bindValue(":title", taskclr);
    query.bindValue(":description", descriptionclr);
    query.bindValue(":task_date", selectedDate.toString(Qt::ISODate));
    query.bindValue(":created_at", QDateTime::currentDateTime().toString(Qt::ISODate));

    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось сохранить задачу: " + query.lastError().text());
        return;
    }

    QMessageBox::information(this, "Готово", "Задача сохранена в приложении.");
    accept();
}
