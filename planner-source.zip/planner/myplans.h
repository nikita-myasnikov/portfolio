#ifndef MYPLANS_H
#define MYPLANS_H

#include <QWidget>
#include <QDate>

class QDateEdit;

namespace Ui {
class myplans;
}

class myplans : public QWidget
{
    Q_OBJECT

public:
    explicit myplans(int userId = -1, QWidget *parent = nullptr);
    ~myplans();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void loadPlanForSelectedDate();

private:
    bool initPlannerTables();
    QString buildPlanText(const QDate &date) const;
    void showTextWindow(const QString &title, const QString &text);
    QStringList currentLineValues() const;
    void setLineValues(const QStringList &values);
    void clearLineValues();

    Ui::myplans *ui;
    QDateEdit *dateEdit;
    int currentUserId;
    QString hour_7, hour_9, hour_11, hour_13, hour_15, hour_17, hour_19, hour_21, hour_23;

signals:
    void signal();
};

#endif // MYPLANS_H
