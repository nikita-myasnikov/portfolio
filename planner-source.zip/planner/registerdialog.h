#ifndef REGISTERDIALOG_H
#define REGISTERDIALOG_H

#include <QDialog>
#include <QString>

class QLineEdit;
class QPushButton;
class QTabWidget;
class QWidget;

class RegisterDialog : public QDialog
{
    Q_OBJECT

public:
    explicit RegisterDialog(QWidget *parent = nullptr);

    int currentUserId() const;
    QString currentLogin() const;

private slots:
    void loginUser();
    void registerUser();

private:
    QWidget *createLoginPage();
    QWidget *createRegisterPage();

    bool initDatabase();
    bool validateCredentials(const QString &login, const QString &password, bool forRegistration);
    QString hashPassword(const QString &password) const;

    QTabWidget *tabs;

    QLineEdit *loginLoginEdit;
    QLineEdit *loginPasswordEdit;

    QLineEdit *registerLoginEdit;
    QLineEdit *registerPasswordEdit;

    QPushButton *loginButton;
    QPushButton *registerButton;
    QPushButton *cancelButton;

    int currentUserIdValue;
    QString currentLoginValue;
};

#endif // REGISTERDIALOG_H
