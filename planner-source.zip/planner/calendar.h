#ifndef CALENDAR_H
#define CALENDAR_H

#include <QDate>
#include <QDialog>

namespace Ui {
class Calendar;
}

class Calendar : public QDialog
{
    Q_OBJECT

public:
    explicit Calendar(const QDate &date = QDate::currentDate(), int userId = -1, QWidget *parent = nullptr);
    ~Calendar();

private slots:
    void on_pushButton_clicked();

private:
    bool initPlannerTables();

    Ui::Calendar *ui;
    QDate selectedDate;
    int currentUserId;
};

#endif // CALENDAR_H
