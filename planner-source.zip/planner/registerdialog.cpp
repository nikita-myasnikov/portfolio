#include "registerdialog.h"

#include <QCryptographicHash>
#include <QDir>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPushButton>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QStringList>
#include <QTabWidget>
#include <QVBoxLayout>
#include <QVariant>
#include <QVector>
#include <QWidget>

RegisterDialog::RegisterDialog(QWidget *parent)
    : QDialog(parent),
      tabs(nullptr),
      loginLoginEdit(nullptr),
      loginPasswordEdit(nullptr),
      registerLoginEdit(nullptr),
      registerPasswordEdit(nullptr),
      loginButton(nullptr),
      registerButton(nullptr),
      cancelButton(nullptr),
      currentUserIdValue(-1)
{
    setWindowTitle("Вход в ежедневник");
    setModal(true);
    setMinimumSize(560, 430);
    resize(640, 480);
    setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);

    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(34, 26, 34, 26);
    mainLayout->setSpacing(14);

    auto *title = new QLabel("Ежедневный планировщик", this);
    title->setObjectName("TitleLabel");
    title->setAlignment(Qt::AlignCenter);

    auto *subtitle = new QLabel("Войдите в аккаунт или создайте нового пользователя", this);
    subtitle->setObjectName("SubtitleLabel");
    subtitle->setAlignment(Qt::AlignCenter);
    subtitle->setWordWrap(true);

    tabs = new QTabWidget(this);
    tabs->setObjectName("AuthTabs");
    tabs->addTab(createLoginPage(), "Войти");
    tabs->addTab(createRegisterPage(), "Регистрация");

    cancelButton = new QPushButton("Закрыть", this);
    cancelButton->setObjectName("CancelButton");
    cancelButton->setCursor(Qt::PointingHandCursor);

    auto *bottomLayout = new QHBoxLayout;
    bottomLayout->addStretch();
    bottomLayout->addWidget(cancelButton);

    mainLayout->addWidget(title);
    mainLayout->addWidget(subtitle);
    mainLayout->addSpacing(4);
    mainLayout->addWidget(tabs, 1);
    mainLayout->addLayout(bottomLayout);

    setStyleSheet(
        "QDialog {"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "        stop:0 #EEF4FF, stop:0.45 #F8FBFF, stop:1 #EAF7F1);"
        "}"
        "QLabel#TitleLabel {"
        "    color: #17223B;"
        "    font-size: 28px;"
        "    font-weight: 700;"
        "}"
        "QLabel#SubtitleLabel {"
        "    color: #5F6C86;"
        "    font-size: 14px;"
        "}"
        "QLabel#HintLabel {"
        "    color: #374151;"
        "    font-size: 15px;"
        "    font-weight: 600;"
        "}"
        "QLabel#FieldLabel {"
        "    color: #25324B;"
        "    font-size: 14px;"
        "    font-weight: 600;"
        "}"
        "QTabWidget::pane {"
        "    background: #FFFFFF;"
        "    border: 1px solid #DDE7F7;"
        "    border-radius: 18px;"
        "    top: -1px;"
        "}"
        "QTabBar::tab {"
        "    background: #E7EEF9;"
        "    color: #42526E;"
        "    border: 1px solid #D5E0F2;"
        "    border-bottom: none;"
        "    border-top-left-radius: 12px;"
        "    border-top-right-radius: 12px;"
        "    padding: 10px 28px;"
        "    margin-right: 6px;"
        "    font-size: 14px;"
        "    font-weight: 600;"
        "}"
        "QTabBar::tab:selected {"
        "    background: #FFFFFF;"
        "    color: #2450D9;"
        "}"
        "QLineEdit {"
        "    background: #F9FBFF;"
        "    color: #17223B;"
        "    border: 1px solid #C9D6EA;"
        "    border-radius: 13px;"
        "    padding: 10px 13px;"
        "    font-size: 15px;"
        "    min-height: 24px;"
        "}"
        "QLineEdit:focus {"
        "    background: #FFFFFF;"
        "    border: 2px solid #4C7DFF;"
        "}"
        "QPushButton {"
        "    border: none;"
        "    border-radius: 14px;"
        "    padding: 11px 18px;"
        "    font-size: 14px;"
        "    font-weight: 700;"
        "}"
        "QPushButton#PrimaryButton {"
        "    color: #FFFFFF;"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,"
        "        stop:0 #4C7DFF, stop:1 #2D5BFF);"
        "}"
        "QPushButton#PrimaryButton:hover {"
        "    background: #2450D9;"
        "}"
        "QPushButton#RegisterButton {"
        "    color: #FFFFFF;"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,"
        "        stop:0 #20B486, stop:1 #159A73);"
        "}"
        "QPushButton#RegisterButton:hover {"
        "    background: #0F8461;"
        "}"
        "QPushButton#CancelButton {"
        "    color: #42526E;"
        "    background: #E8EEF8;"
        "}"
        "QPushButton#CancelButton:hover {"
        "    background: #D8E2F2;"
        "}"
        "QPushButton#LinkButton {"
        "    color: #2450D9;"
        "    background: transparent;"
        "    padding: 6px;"
        "    font-weight: 600;"
        "}"
        "QPushButton#LinkButton:hover {"
        "    color: #1237A8;"
        "    text-decoration: underline;"
        "}"
    );

    connect(cancelButton, &QPushButton::clicked, this, &RegisterDialog::reject);

    loginLoginEdit->setFocus();
}

int RegisterDialog::currentUserId() const
{
    return currentUserIdValue;
}

QString RegisterDialog::currentLogin() const
{
    return currentLoginValue;
}

QWidget *RegisterDialog::createLoginPage()
{
    auto *page = new QWidget(this);
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(34, 28, 34, 28);
    layout->setSpacing(12);

    auto *hint = new QLabel("Вход в аккаунт", page);
    hint->setObjectName("HintLabel");
    hint->setAlignment(Qt::AlignCenter);

    auto *loginLabel = new QLabel("Логин", page);
    loginLabel->setObjectName("FieldLabel");

    loginLoginEdit = new QLineEdit(page);
    loginLoginEdit->setPlaceholderText("Введите логин");
    loginLoginEdit->setClearButtonEnabled(true);

    auto *passwordLabel = new QLabel("Пароль", page);
    passwordLabel->setObjectName("FieldLabel");

    loginPasswordEdit = new QLineEdit(page);
    loginPasswordEdit->setPlaceholderText("Введите пароль");
    loginPasswordEdit->setEchoMode(QLineEdit::Password);
    loginPasswordEdit->setClearButtonEnabled(true);

    loginButton = new QPushButton("Войти", page);
    loginButton->setObjectName("PrimaryButton");
    loginButton->setCursor(Qt::PointingHandCursor);

    auto *switchToRegisterButton = new QPushButton("Нет аккаунта? Зарегистрироваться", page);
    switchToRegisterButton->setObjectName("LinkButton");
    switchToRegisterButton->setCursor(Qt::PointingHandCursor);

    layout->addWidget(hint);
    layout->addSpacing(8);
    layout->addWidget(loginLabel);
    layout->addWidget(loginLoginEdit);
    layout->addWidget(passwordLabel);
    layout->addWidget(loginPasswordEdit);
    layout->addSpacing(8);
    layout->addWidget(loginButton);
    layout->addWidget(switchToRegisterButton, 0, Qt::AlignCenter);
    layout->addStretch();

    connect(loginButton, &QPushButton::clicked, this, &RegisterDialog::loginUser);
    connect(loginPasswordEdit, &QLineEdit::returnPressed, this, &RegisterDialog::loginUser);
    connect(loginLoginEdit, &QLineEdit::returnPressed, this, [this]() {
        loginPasswordEdit->setFocus();
    });
    connect(switchToRegisterButton, &QPushButton::clicked, this, [this]() {
        tabs->setCurrentIndex(1);
        registerLoginEdit->setFocus();
    });

    return page;
}

QWidget *RegisterDialog::createRegisterPage()
{
    auto *page = new QWidget(this);
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(34, 28, 34, 28);
    layout->setSpacing(12);

    auto *hint = new QLabel("Создание нового пользователя", page);
    hint->setObjectName("HintLabel");
    hint->setAlignment(Qt::AlignCenter);

    auto *loginLabel = new QLabel("Логин", page);
    loginLabel->setObjectName("FieldLabel");

    registerLoginEdit = new QLineEdit(page);
    registerLoginEdit->setPlaceholderText("Придумайте логин");
    registerLoginEdit->setClearButtonEnabled(true);

    auto *passwordLabel = new QLabel("Пароль", page);
    passwordLabel->setObjectName("FieldLabel");

    registerPasswordEdit = new QLineEdit(page);
    registerPasswordEdit->setPlaceholderText("Придумайте пароль");
    registerPasswordEdit->setEchoMode(QLineEdit::Password);
    registerPasswordEdit->setClearButtonEnabled(true);

    registerButton = new QPushButton("Зарегистрироваться", page);
    registerButton->setObjectName("RegisterButton");
    registerButton->setCursor(Qt::PointingHandCursor);

    auto *switchToLoginButton = new QPushButton("Уже есть аккаунт? Войти", page);
    switchToLoginButton->setObjectName("LinkButton");
    switchToLoginButton->setCursor(Qt::PointingHandCursor);

    layout->addWidget(hint);
    layout->addSpacing(8);
    layout->addWidget(loginLabel);
    layout->addWidget(registerLoginEdit);
    layout->addWidget(passwordLabel);
    layout->addWidget(registerPasswordEdit);
    layout->addSpacing(8);
    layout->addWidget(registerButton);
    layout->addWidget(switchToLoginButton, 0, Qt::AlignCenter);
    layout->addStretch();

    connect(registerButton, &QPushButton::clicked, this, &RegisterDialog::registerUser);
    connect(registerPasswordEdit, &QLineEdit::returnPressed, this, &RegisterDialog::registerUser);
    connect(registerLoginEdit, &QLineEdit::returnPressed, this, [this]() {
        registerPasswordEdit->setFocus();
    });
    connect(switchToLoginButton, &QPushButton::clicked, this, [this]() {
        tabs->setCurrentIndex(0);
        loginLoginEdit->setFocus();
    });

    return page;
}

bool RegisterDialog::initDatabase()
{
    QDir dir(QDir::currentPath());

    QSqlDatabase db;
    if (QSqlDatabase::contains("users_connection")) {
        db = QSqlDatabase::database("users_connection");
    } else {
        db = QSqlDatabase::addDatabase("QSQLITE", "users_connection");
        db.setDatabaseName(dir.filePath("users.db"));
    }

    if (!db.isOpen() && !db.open()) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось открыть базу данных: " + db.lastError().text());
        return false;
    }

    QSqlQuery query(db);
    const QString createTable =
        "CREATE TABLE IF NOT EXISTS users ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "login TEXT NOT NULL UNIQUE, "
        "password_hash TEXT NOT NULL, "
        "name TEXT, "
        "photo_path TEXT"
        ")";

    if (!query.exec(createTable)) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось создать таблицу пользователей: " + query.lastError().text());
        return false;
    }

    if (!query.exec("PRAGMA table_info(users)")) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось проверить таблицу пользователей: " + query.lastError().text());
        return false;
    }

    QStringList columns;
    while (query.next()) {
        columns << query.value(1).toString();
    }

    query.finish();

    const bool oldSchema = columns.contains("email")
                           || columns.contains("created_at")
                           || columns.contains("password")
                           || !columns.contains("password_hash");

    if (oldSchema) {
        struct UserRow
        {
            int id;
            QString login;
            QString passwordHash;
            QString name;
            QString photoPath;
        };

        QVector<UserRow> users;

        if (columns.contains("login") && (columns.contains("password_hash") || columns.contains("password"))) {
            const bool hasPasswordHash = columns.contains("password_hash");
            const bool hasName = columns.contains("name");
            const bool hasPhotoPath = columns.contains("photo_path");
            const QString passwordColumn = hasPasswordHash ? "password_hash" : "password";

            QString selectQuery = QString("SELECT id, login, %1").arg(passwordColumn);
            if (hasName) {
                selectQuery += ", name";
            }
            if (hasPhotoPath) {
                selectQuery += ", photo_path";
            }
            selectQuery += " FROM users";

            QSqlQuery readQuery(db);
            if (!readQuery.exec(selectQuery)) {
                QMessageBox::critical(this, "Ошибка БД", "Не удалось прочитать старую таблицу пользователей: " + readQuery.lastError().text());
                return false;
            }

            while (readQuery.next()) {
                UserRow row;
                row.id = readQuery.value(0).toInt();
                row.login = readQuery.value(1).toString();
                const QString passwordValue = readQuery.value(2).toString();
                row.passwordHash = hasPasswordHash ? passwordValue : hashPassword(passwordValue);

                int index = 3;
                row.name = hasName ? readQuery.value(index++).toString() : row.login;
                row.photoPath = hasPhotoPath ? readQuery.value(index++).toString() : QString();

                if (row.name.trimmed().isEmpty()) {
                    row.name = row.login;
                }

                users.append(row);
            }

            readQuery.finish();
        }

        QSqlQuery migration(db);

        if (!migration.exec("DROP TABLE IF EXISTS users_temp")) {
            QMessageBox::critical(this, "Ошибка БД", "Не удалось подготовить обновление таблицы: " + migration.lastError().text());
            return false;
        }

        if (!migration.exec("CREATE TABLE users_temp ("
                            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                            "login TEXT NOT NULL UNIQUE, "
                            "password_hash TEXT NOT NULL, "
                            "name TEXT, "
                            "photo_path TEXT)")) {
            QMessageBox::critical(this, "Ошибка БД", "Не удалось создать новую таблицу пользователей: " + migration.lastError().text());
            return false;
        }

        QSqlQuery insertQuery(db);
        insertQuery.prepare("INSERT OR IGNORE INTO users_temp (id, login, password_hash, name, photo_path) "
                            "VALUES (:id, :login, :password_hash, :name, :photo_path)");

        for (const UserRow &user : users) {
            insertQuery.bindValue(":id", user.id);
            insertQuery.bindValue(":login", user.login);
            insertQuery.bindValue(":password_hash", user.passwordHash);
            insertQuery.bindValue(":name", user.name);
            insertQuery.bindValue(":photo_path", user.photoPath);

            if (!insertQuery.exec()) {
                QMessageBox::critical(this, "Ошибка БД", "Не удалось перенести пользователей: " + insertQuery.lastError().text());
                return false;
            }
        }

        if (!migration.exec("DROP TABLE users")) {
            QMessageBox::critical(this, "Ошибка БД", "Не удалось удалить старую таблицу пользователей: " + migration.lastError().text());
            return false;
        }

        if (!migration.exec("ALTER TABLE users_temp RENAME TO users")) {
            QMessageBox::critical(this, "Ошибка БД", "Не удалось обновить таблицу пользователей: " + migration.lastError().text());
            return false;
        }
    }

    if (!query.exec("PRAGMA table_info(users)")) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось проверить обновлённую таблицу пользователей: " + query.lastError().text());
        return false;
    }

    columns.clear();
    while (query.next()) {
        columns << query.value(1).toString();
    }
    query.finish();

    if (!columns.contains("name")) {
        QSqlQuery alterQuery(db);
        if (!alterQuery.exec("ALTER TABLE users ADD COLUMN name TEXT")) {
            QMessageBox::critical(this, "Ошибка БД", "Не удалось добавить поле имени: " + alterQuery.lastError().text());
            return false;
        }
    }

    if (!columns.contains("photo_path")) {
        QSqlQuery alterQuery(db);
        if (!alterQuery.exec("ALTER TABLE users ADD COLUMN photo_path TEXT")) {
            QMessageBox::critical(this, "Ошибка БД", "Не удалось добавить поле фото: " + alterQuery.lastError().text());
            return false;
        }
    }

    QSqlQuery fillNameQuery(db);
    if (!fillNameQuery.exec("UPDATE users SET name = login WHERE name IS NULL OR TRIM(name) = ''")) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось заполнить имена пользователей: " + fillNameQuery.lastError().text());
        return false;
    }

    return true;
}

bool RegisterDialog::validateCredentials(const QString &login, const QString &password, bool forRegistration)
{
    if (login.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Проверка данных", "Введите логин и пароль.");
        return false;
    }

    if (forRegistration && login.length() < 3) {
        QMessageBox::warning(this, "Проверка данных", "Логин должен содержать минимум 3 символа.");
        return false;
    }

    if (forRegistration && password.length() < 6) {
        QMessageBox::warning(this, "Проверка данных", "Пароль должен содержать минимум 6 символов.");
        return false;
    }

    return true;
}

QString RegisterDialog::hashPassword(const QString &password) const
{
    const QByteArray hash = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256);
    return QString(hash.toHex());
}

void RegisterDialog::loginUser()
{
    const QString login = loginLoginEdit->text().trimmed();
    const QString password = loginPasswordEdit->text();

    if (!validateCredentials(login, password, false)) {
        return;
    }

    if (!initDatabase()) {
        return;
    }

    QSqlDatabase db = QSqlDatabase::database("users_connection");
    QSqlQuery query(db);
    query.prepare("SELECT id, password_hash FROM users WHERE login = :login");
    query.bindValue(":login", login);

    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось проверить пользователя: " + query.lastError().text());
        return;
    }

    if (!query.next()) {
        QMessageBox::warning(this, "Вход", "Пользователь с таким логином не найден.");
        return;
    }

    const int userId = query.value(0).toInt();
    const QString savedPasswordHash = query.value(1).toString();
    if (savedPasswordHash != hashPassword(password)) {
        QMessageBox::warning(this, "Вход", "Неверный пароль.");
        return;
    }

    currentUserIdValue = userId;
    currentLoginValue = login;

    accept();
}

void RegisterDialog::registerUser()
{
    const QString login = registerLoginEdit->text().trimmed();
    const QString password = registerPasswordEdit->text();

    if (!validateCredentials(login, password, true)) {
        return;
    }

    if (!initDatabase()) {
        return;
    }

    QSqlDatabase db = QSqlDatabase::database("users_connection");
    QSqlQuery query(db);
    query.prepare("INSERT INTO users (login, password_hash, name) "
                  "VALUES (:login, :password_hash, :name)");
    query.bindValue(":login", login);
    query.bindValue(":password_hash", hashPassword(password));
    query.bindValue(":name", login);

    if (!query.exec()) {
        if (query.lastError().text().contains("UNIQUE", Qt::CaseInsensitive)) {
            QMessageBox::warning(this, "Регистрация", "Пользователь с таким логином уже существует.");
        } else {
            QMessageBox::critical(this, "Ошибка БД", "Не удалось сохранить пользователя: " + query.lastError().text());
        }
        return;
    }

    currentUserIdValue = query.lastInsertId().toInt();
    currentLoginValue = login;

    if (currentUserIdValue <= 0) {
        QSqlQuery idQuery(db);
        idQuery.prepare("SELECT id FROM users WHERE login = :login");
        idQuery.bindValue(":login", login);
        if (idQuery.exec() && idQuery.next()) {
            currentUserIdValue = idQuery.value(0).toInt();
        }
    }

    QMessageBox::information(this,
                             "Регистрация",
                             "Регистрация успешно завершена!");

    accept();
}
