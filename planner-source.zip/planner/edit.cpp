#include "edit.h"
#include "ui_edit.h"

#include <QMessageBox>
#include <QPushButton>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

Edit::Edit(int userId, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Edit),
    currentUserId(userId)
{
    ui->setupUi(this);
    this->setWindowTitle("Удаление задачи");
    connect(ui->exitButton, &QPushButton::clicked, this, [this]() {
        if (QDialog *parentDialog = qobject_cast<QDialog*>(parentWidget())) {
            parentDialog->accept();
        }
        this->accept();
    });
    initPlannerTables();
}

Edit::~Edit()
{
    delete ui;
}

bool Edit::initPlannerTables()
{
    if (!QSqlDatabase::contains("users_connection")) {
        return false;
    }

    QSqlDatabase db = QSqlDatabase::database("users_connection");
    if (!db.isOpen() && !db.open()) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось открыть базу данных: " + db.lastError().text());
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec("CREATE TABLE IF NOT EXISTS tasks ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    "user_id INTEGER, "
                    "title TEXT NOT NULL, "
                    "description TEXT NOT NULL, "
                    "task_date TEXT, "
                    "created_at TEXT NOT NULL)")) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось создать таблицу задач: " + query.lastError().text());
        return false;
    }

    return true;
}

void Edit::on_pushButton_clicked()
{
    const QString searchName = ui->lineEdit->text().trimmed();

    if (searchName.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Введите название для удаления записи");
        return;
    }

    if (!initPlannerTables()) {
        return;
    }

    QSqlDatabase db = QSqlDatabase::database("users_connection");
    QSqlQuery query(db);
    query.prepare("DELETE FROM tasks WHERE user_id = :user_id AND title = :title");
    query.bindValue(":user_id", currentUserId);
    query.bindValue(":title", searchName);

    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось удалить задачу: " + query.lastError().text());
        return;
    }

    if (query.numRowsAffected() <= 0) {
        QMessageBox::information(this, "Удаление", "Задача с таким названием не найдена.");
        return;
    }

    QMessageBox::information(this, "Удаление", "Задача удалена.");
    accept();
}
