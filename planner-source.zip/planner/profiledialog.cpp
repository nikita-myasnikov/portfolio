#include "profiledialog.h"

#include <QCryptographicHash>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPixmap>
#include <QPushButton>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QStringList>
#include <QVBoxLayout>
#include <QVariant>

ProfileDialog::ProfileDialog(int userId, const QString &login, QWidget *parent)
    : QDialog(parent),
      currentUserId(userId),
      currentLogin(login),
      photoLabel(nullptr),
      loginValueLabel(nullptr),
      nameEdit(nullptr),
      newPasswordEdit(nullptr),
      repeatPasswordEdit(nullptr),
      choosePhotoButton(nullptr),
      saveButton(nullptr),
      closeButton(nullptr)
{
    setWindowTitle("Мой профиль");
    setModal(true);
    setMinimumSize(620, 480);
    resize(700, 520);
    setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);

    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(34, 28, 34, 28);
    mainLayout->setSpacing(18);

    auto *title = new QLabel("Мой профиль", this);
    title->setObjectName("TitleLabel");
    title->setAlignment(Qt::AlignCenter);

    auto *subtitle = new QLabel("Здесь можно изменить имя, пароль и фотографию профиля", this);
    subtitle->setObjectName("SubtitleLabel");
    subtitle->setAlignment(Qt::AlignCenter);
    subtitle->setWordWrap(true);

    auto *card = new QFrame(this);
    card->setObjectName("ProfileCard");
    auto *cardLayout = new QHBoxLayout(card);
    cardLayout->setContentsMargins(28, 26, 28, 26);
    cardLayout->setSpacing(28);

    auto *photoLayout = new QVBoxLayout;
    photoLayout->setSpacing(12);

    photoLabel = new QLabel(card);
    photoLabel->setObjectName("PhotoLabel");
    photoLabel->setFixedSize(160, 160);
    photoLabel->setAlignment(Qt::AlignCenter);
    photoLabel->setScaledContents(false);

    choosePhotoButton = new QPushButton("Добавить фото", card);
    choosePhotoButton->setObjectName("SecondaryButton");
    choosePhotoButton->setCursor(Qt::PointingHandCursor);

    photoLayout->addWidget(photoLabel, 0, Qt::AlignCenter);
    photoLayout->addWidget(choosePhotoButton);
    photoLayout->addStretch();

    auto *formLayout = new QVBoxLayout;
    formLayout->setSpacing(10);

    auto *loginTitle = new QLabel("Логин для входа", card);
    loginTitle->setObjectName("FieldLabel");

    loginValueLabel = new QLabel(card);
    loginValueLabel->setObjectName("LoginValueLabel");

    auto *nameLabel = new QLabel("Имя", card);
    nameLabel->setObjectName("FieldLabel");

    nameEdit = new QLineEdit(card);
    nameEdit->setPlaceholderText("Введите имя");
    nameEdit->setClearButtonEnabled(true);

    auto *passwordLabel = new QLabel("Новый пароль", card);
    passwordLabel->setObjectName("FieldLabel");

    newPasswordEdit = new QLineEdit(card);
    newPasswordEdit->setPlaceholderText("Оставьте пустым, если пароль менять не нужно");
    newPasswordEdit->setEchoMode(QLineEdit::Password);
    newPasswordEdit->setClearButtonEnabled(true);

    auto *repeatPasswordLabel = new QLabel("Повторите новый пароль", card);
    repeatPasswordLabel->setObjectName("FieldLabel");

    repeatPasswordEdit = new QLineEdit(card);
    repeatPasswordEdit->setPlaceholderText("Повторите новый пароль");
    repeatPasswordEdit->setEchoMode(QLineEdit::Password);
    repeatPasswordEdit->setClearButtonEnabled(true);

    formLayout->addWidget(loginTitle);
    formLayout->addWidget(loginValueLabel);
    formLayout->addSpacing(6);
    formLayout->addWidget(nameLabel);
    formLayout->addWidget(nameEdit);
    formLayout->addWidget(passwordLabel);
    formLayout->addWidget(newPasswordEdit);
    formLayout->addWidget(repeatPasswordLabel);
    formLayout->addWidget(repeatPasswordEdit);
    formLayout->addStretch();

    cardLayout->addLayout(photoLayout);
    cardLayout->addLayout(formLayout, 1);

    saveButton = new QPushButton("Сохранить изменения", this);
    saveButton->setObjectName("PrimaryButton");
    saveButton->setCursor(Qt::PointingHandCursor);

    closeButton = new QPushButton("Закрыть", this);
    closeButton->setObjectName("CancelButton");
    closeButton->setCursor(Qt::PointingHandCursor);

    auto *buttonsLayout = new QHBoxLayout;
    buttonsLayout->addStretch();
    buttonsLayout->addWidget(closeButton);
    buttonsLayout->addWidget(saveButton);

    mainLayout->addWidget(title);
    mainLayout->addWidget(subtitle);
    mainLayout->addWidget(card, 1);
    mainLayout->addLayout(buttonsLayout);

    setStyleSheet(
        "QDialog {"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
        "        stop:0 #F2F6FF, stop:0.48 #FFFFFF, stop:1 #F4FFF9);"
        "}"
        "QLabel#TitleLabel {"
        "    color: #121A2F;"
        "    font-size: 28px;"
        "    font-weight: 700;"
        "}"
        "QLabel#SubtitleLabel {"
        "    color: #4B5563;"
        "    font-size: 14px;"
        "}"
        "QFrame#ProfileCard {"
        "    background: #FFFFFF;"
        "    border: 1px solid #DDE7F7;"
        "    border-radius: 22px;"
        "}"
        "QLabel#PhotoLabel {"
        "    background: #EEF4FF;"
        "    color: #344054;"
        "    border: 2px dashed #9DB7F5;"
        "    border-radius: 80px;"
        "    font-size: 15px;"
        "    font-weight: 600;"
        "}"
        "QLabel#FieldLabel {"
        "    color: #1F2937;"
        "    font-size: 14px;"
        "    font-weight: 700;"
        "}"
        "QLabel#LoginValueLabel {"
        "    color: #2450D9;"
        "    background: #EEF4FF;"
        "    border: 1px solid #C9D6EA;"
        "    border-radius: 13px;"
        "    padding: 10px 13px;"
        "    font-size: 15px;"
        "    font-weight: 700;"
        "}"
        "QLineEdit {"
        "    background: #F9FBFF;"
        "    color: #111827;"
        "    border: 1px solid #C9D6EA;"
        "    border-radius: 13px;"
        "    padding: 10px 13px;"
        "    font-size: 15px;"
        "    min-height: 24px;"
        "}"
        "QLineEdit:focus {"
        "    background: #FFFFFF;"
        "    border: 2px solid #4C7DFF;"
        "}"
        "QPushButton {"
        "    border: none;"
        "    border-radius: 14px;"
        "    padding: 11px 18px;"
        "    font-size: 14px;"
        "    font-weight: 700;"
        "}"
        "QPushButton#PrimaryButton {"
        "    color: #FFFFFF;"
        "    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,"
        "        stop:0 #4C7DFF, stop:1 #2D5BFF);"
        "}"
        "QPushButton#PrimaryButton:hover {"
        "    background: #2450D9;"
        "}"
        "QPushButton#SecondaryButton {"
        "    color: #2450D9;"
        "    background: #EAF0FF;"
        "}"
        "QPushButton#SecondaryButton:hover {"
        "    background: #DDE7FF;"
        "}"
        "QPushButton#CancelButton {"
        "    color: #42526E;"
        "    background: #E8EEF8;"
        "}"
        "QPushButton#CancelButton:hover {"
        "    background: #D8E2F2;"
        "}"
        "QMessageBox QLabel { color: #000000; }"
    );

    connect(choosePhotoButton, &QPushButton::clicked, this, &ProfileDialog::choosePhoto);
    connect(saveButton, &QPushButton::clicked, this, &ProfileDialog::saveProfile);
    connect(closeButton, &QPushButton::clicked, this, &ProfileDialog::reject);
    connect(repeatPasswordEdit, &QLineEdit::returnPressed, this, &ProfileDialog::saveProfile);

    if (!loadProfile()) {
        showEmptyPhoto();
        loginValueLabel->setText(currentLogin);
        nameEdit->setText(currentLogin);
    }
}

QString ProfileDialog::profileName() const
{
    return currentName;
}

QString ProfileDialog::photoPath() const
{
    return currentPhotoPath;
}

bool ProfileDialog::initDatabase()
{
    QDir dir(QDir::currentPath());

    QSqlDatabase db;
    if (QSqlDatabase::contains("users_connection")) {
        db = QSqlDatabase::database("users_connection");
    } else {
        db = QSqlDatabase::addDatabase("QSQLITE", "users_connection");
        db.setDatabaseName(dir.filePath("users.db"));
    }

    if (!db.isOpen() && !db.open()) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось открыть базу данных: " + db.lastError().text());
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec("CREATE TABLE IF NOT EXISTS users ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    "login TEXT NOT NULL UNIQUE, "
                    "password_hash TEXT NOT NULL, "
                    "name TEXT, "
                    "photo_path TEXT)")) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось создать таблицу пользователей: " + query.lastError().text());
        return false;
    }

    if (!query.exec("PRAGMA table_info(users)")) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось проверить таблицу пользователей: " + query.lastError().text());
        return false;
    }

    QStringList columns;
    while (query.next()) {
        columns << query.value(1).toString();
    }
    query.finish();

    if (!columns.contains("name")) {
        QSqlQuery alterQuery(db);
        if (!alterQuery.exec("ALTER TABLE users ADD COLUMN name TEXT")) {
            QMessageBox::critical(this, "Ошибка БД", "Не удалось добавить поле имени: " + alterQuery.lastError().text());
            return false;
        }
    }

    if (!columns.contains("photo_path")) {
        QSqlQuery alterQuery(db);
        if (!alterQuery.exec("ALTER TABLE users ADD COLUMN photo_path TEXT")) {
            QMessageBox::critical(this, "Ошибка БД", "Не удалось добавить поле фото: " + alterQuery.lastError().text());
            return false;
        }
    }

    QSqlQuery fillNameQuery(db);
    if (!fillNameQuery.exec("UPDATE users SET name = login WHERE name IS NULL OR TRIM(name) = ''")) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось обновить имена пользователей: " + fillNameQuery.lastError().text());
        return false;
    }

    return true;
}

bool ProfileDialog::loadProfile()
{
    if (currentUserId <= 0) {
        return false;
    }

    if (!initDatabase()) {
        return false;
    }

    QSqlDatabase db = QSqlDatabase::database("users_connection");
    QSqlQuery query(db);
    query.prepare("SELECT login, name, photo_path FROM users WHERE id = :id");
    query.bindValue(":id", currentUserId);

    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось загрузить профиль: " + query.lastError().text());
        return false;
    }

    if (!query.next()) {
        QMessageBox::warning(this, "Профиль", "Пользователь не найден.");
        return false;
    }

    currentLogin = query.value(0).toString();
    currentName = query.value(1).toString().trimmed();
    currentPhotoPath = query.value(2).toString();

    if (currentName.isEmpty()) {
        currentName = currentLogin;
    }

    loginValueLabel->setText(currentLogin);
    nameEdit->setText(currentName);
    updatePhotoPreview(currentPhotoPath);

    return true;
}

QString ProfileDialog::hashPassword(const QString &password) const
{
    const QByteArray hash = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256);
    return QString(hash.toHex());
}

QString ProfileDialog::copyPhotoToAppFolder(const QString &sourcePath) const
{
    if (sourcePath.isEmpty()) {
        return currentPhotoPath;
    }

    QFileInfo sourceInfo(sourcePath);
    if (!sourceInfo.exists()) {
        return currentPhotoPath;
    }

    QDir appDir(QDir::currentPath());
    const QString photosFolderName = "profile_photos";
    if (!appDir.exists(photosFolderName) && !appDir.mkdir(photosFolderName)) {
        return sourcePath;
    }

    const QString suffix = sourceInfo.suffix().isEmpty() ? "png" : sourceInfo.suffix();
    const QString fileName = QString("user_%1_%2.%3")
                             .arg(currentUserId)
                             .arg(QDateTime::currentMSecsSinceEpoch())
                             .arg(suffix);
    const QString destinationPath = appDir.filePath(photosFolderName + "/" + fileName);

    if (QFile::exists(destinationPath)) {
        QFile::remove(destinationPath);
    }

    if (QFile::copy(sourcePath, destinationPath)) {
        return destinationPath;
    }

    return sourcePath;
}

void ProfileDialog::updatePhotoPreview(const QString &path)
{
    if (path.isEmpty()) {
        showEmptyPhoto();
        return;
    }

    QPixmap pixmap(path);
    if (pixmap.isNull()) {
        showEmptyPhoto();
        return;
    }

    photoLabel->setText(QString());
    photoLabel->setPixmap(pixmap.scaled(photoLabel->size(), Qt::KeepAspectRatioByExpanding, Qt::SmoothTransformation));
}

void ProfileDialog::showEmptyPhoto()
{
    photoLabel->setPixmap(QPixmap());
    photoLabel->setText("Фото\nпрофиля");
}

void ProfileDialog::choosePhoto()
{
    const QString fileName = QFileDialog::getOpenFileName(
        this,
        "Выберите фото профиля",
        QDir::homePath(),
        "Изображения (*.png *.jpg *.jpeg *.bmp)"
    );

    if (fileName.isEmpty()) {
        return;
    }

    selectedPhotoPath = fileName;
    updatePhotoPreview(selectedPhotoPath);
}

void ProfileDialog::saveProfile()
{
    if (currentUserId <= 0) {
        QMessageBox::warning(this, "Профиль", "Не удалось определить текущего пользователя.");
        return;
    }

    const QString name = nameEdit->text().trimmed();
    const QString newPassword = newPasswordEdit->text();
    const QString repeatPassword = repeatPasswordEdit->text();

    if (name.isEmpty()) {
        QMessageBox::warning(this, "Профиль", "Введите имя пользователя.");
        return;
    }

    if (!newPassword.isEmpty()) {
        if (newPassword.length() < 6) {
            QMessageBox::warning(this, "Профиль", "Новый пароль должен содержать минимум 6 символов.");
            return;
        }

        if (newPassword != repeatPassword) {
            QMessageBox::warning(this, "Профиль", "Пароли не совпадают.");
            return;
        }
    }

    if (!initDatabase()) {
        return;
    }

    QString savedPhotoPath = currentPhotoPath;
    if (!selectedPhotoPath.isEmpty()) {
        savedPhotoPath = copyPhotoToAppFolder(selectedPhotoPath);
    }

    QSqlDatabase db = QSqlDatabase::database("users_connection");
    QSqlQuery query(db);

    if (newPassword.isEmpty()) {
        query.prepare("UPDATE users SET name = :name, photo_path = :photo_path WHERE id = :id");
    } else {
        query.prepare("UPDATE users SET name = :name, photo_path = :photo_path, password_hash = :password_hash WHERE id = :id");
        query.bindValue(":password_hash", hashPassword(newPassword));
    }

    query.bindValue(":name", name);
    query.bindValue(":photo_path", savedPhotoPath);
    query.bindValue(":id", currentUserId);

    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось сохранить профиль: " + query.lastError().text());
        return;
    }

    currentName = name;
    currentPhotoPath = savedPhotoPath;
    selectedPhotoPath.clear();
    newPasswordEdit->clear();
    repeatPasswordEdit->clear();

    emit profileChanged(currentName, currentPhotoPath);
    QMessageBox::information(this, "Профиль", "Профиль успешно сохранён.");
    accept();
}
