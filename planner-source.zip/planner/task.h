#ifndef TASK_H
#define TASK_H

#include <QDialog>

namespace Ui {
class Task;
}

class Task : public QDialog
{
    Q_OBJECT

public:
    explicit Task(int userId = -1, QWidget *parent = nullptr);
    ~Task();

private slots:
    void on_pushButton_clicked();

private:
    bool initPlannerTables();

    Ui::Task *ui;
    int currentUserId;
};

#endif // TASK_H
