#ifndef MYKONTAKTS_H
#define MYKONTAKTS_H

#include <QDialog>
#include <QString>
#include <QMessageBox>
#include <QFile>
#include <QDate>
#include <QTextStream>
#include <QDesktopServices>
#include <QUrl>
#include <QDir>
#include <QDialog>
#include <QTextEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QLabel>
namespace Ui {
class mykontakts;
}

class mykontakts : public QDialog
{
    Q_OBJECT

public:
    explicit mykontakts(QWidget *parent = nullptr);
    ~mykontakts();

private:
    Ui::mykontakts *ui;

signals:
    void signal();
private slots:
    void on_save_button_clicked();
    void on_pushButton_clicked();
    void on_save_button_2_clicked();
    void on_save_button_3_clicked();
};

#endif // MYKONTAKTS_H
