#ifndef EDIT_H
#define EDIT_H

#include <QDialog>

namespace Ui {
class Edit;
}

class Edit : public QDialog
{
    Q_OBJECT

public:
    explicit Edit(int userId = -1, QWidget *parent = nullptr);
    ~Edit();

private slots:
    void on_pushButton_clicked();

private:
    bool initPlannerTables();

    Ui::Edit *ui;
    int currentUserId;
};

#endif // EDIT_H
