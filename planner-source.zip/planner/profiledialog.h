#ifndef PROFILEDIALOG_H
#define PROFILEDIALOG_H

#include <QDialog>
#include <QString>

class QLabel;
class QLineEdit;
class QPushButton;

class ProfileDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ProfileDialog(int userId, const QString &login, QWidget *parent = nullptr);

    QString profileName() const;
    QString photoPath() const;

signals:
    void profileChanged(const QString &name, const QString &photoPath);

private slots:
    void choosePhoto();
    void saveProfile();

private:
    bool initDatabase();
    bool loadProfile();
    QString hashPassword(const QString &password) const;
    QString copyPhotoToAppFolder(const QString &sourcePath) const;
    void updatePhotoPreview(const QString &path);
    void showEmptyPhoto();

    int currentUserId;
    QString currentLogin;
    QString currentName;
    QString currentPhotoPath;
    QString selectedPhotoPath;

    QLabel *photoLabel;
    QLabel *loginValueLabel;
    QLineEdit *nameEdit;
    QLineEdit *newPasswordEdit;
    QLineEdit *repeatPasswordEdit;
    QPushButton *choosePhotoButton;
    QPushButton *saveButton;
    QPushButton *closeButton;
};

#endif // PROFILEDIALOG_H
