#include "myplans.h"
#include "ui_myplans.h"

#include <QDateEdit>
#include <QDialog>
#include <QDialogButtonBox>
#include <QLabel>
#include <QLineEdit>
#include <QMap>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QVariant>

myplans::myplans(int userId, QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::myplans)
    , dateEdit(nullptr)
    , currentUserId(userId)
{
    ui->setupUi(this);
    this->setWindowTitle("Мои планы");
    resize(620, 430);

    auto *dateLabel = new QLabel("Выберите число:", this);
    dateLabel->setGeometry(250, 120, 190, 24);
    dateLabel->setStyleSheet("color: #000000; background: transparent; font: 12pt 'Century Gothic';");

    dateEdit = new QDateEdit(QDate::currentDate(), this);
    dateEdit->setGeometry(250, 150, 230, 34);
    dateEdit->setCalendarPopup(true);
    dateEdit->setDisplayFormat("dd.MM.yyyy");
    dateEdit->setStyleSheet("QDateEdit { color: #000000; background: #FFFFFF; border: 1px solid #B8A6E8; border-radius: 10px; padding: 5px; font: 11pt 'Century Gothic'; }");

    connect(dateEdit, &QDateEdit::dateChanged, this, &myplans::loadPlanForSelectedDate);

    initPlannerTables();
    loadPlanForSelectedDate();
}

myplans::~myplans()
{
    delete ui;
}

bool myplans::initPlannerTables()
{
    if (!QSqlDatabase::contains("users_connection")) {
        return false;
    }

    QSqlDatabase db = QSqlDatabase::database("users_connection");
    if (!db.isOpen() && !db.open()) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось открыть базу данных: " + db.lastError().text());
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec("CREATE TABLE IF NOT EXISTS daily_plans ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    "user_id INTEGER, "
                    "plan_date TEXT NOT NULL, "
                    "hour TEXT NOT NULL, "
                    "task_text TEXT, "
                    "UNIQUE(user_id, plan_date, hour))")) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось создать таблицу планов: " + query.lastError().text());
        return false;
    }

    return true;
}

QStringList myplans::currentLineValues() const
{
    return QStringList()
           << ui->lineEdit->text().trimmed()
           << ui->lineEdit_2->text().trimmed()
           << ui->lineEdit_3->text().trimmed()
           << ui->lineEdit_4->text().trimmed()
           << ui->lineEdit_5->text().trimmed()
           << ui->lineEdit_6->text().trimmed()
           << ui->lineEdit_7->text().trimmed()
           << ui->lineEdit_8->text().trimmed()
           << ui->lineEdit_9->text().trimmed();
}

void myplans::setLineValues(const QStringList &values)
{
    QList<QLineEdit*> edits = {
        ui->lineEdit, ui->lineEdit_2, ui->lineEdit_3,
        ui->lineEdit_4, ui->lineEdit_5, ui->lineEdit_6,
        ui->lineEdit_7, ui->lineEdit_8, ui->lineEdit_9
    };

    for (int i = 0; i < edits.size(); ++i) {
        edits[i]->setText(i < values.size() ? values[i] : QString());
    }
}

void myplans::clearLineValues()
{
    setLineValues(QStringList());
}

void myplans::loadPlanForSelectedDate()
{
    if (!dateEdit || !initPlannerTables()) {
        return;
    }

    QStringList values;
    values << "" << "" << "" << "" << "" << "" << "" << "" << "";

    const QStringList hours = {"7:00", "9:00", "11:00", "13:00", "15:00", "17:00", "19:00", "21:00", "23:00"};
    QSqlDatabase db = QSqlDatabase::database("users_connection");
    QSqlQuery query(db);
    query.prepare("SELECT hour, task_text FROM daily_plans WHERE user_id = :user_id AND plan_date = :plan_date");
    query.bindValue(":user_id", currentUserId);
    query.bindValue(":plan_date", dateEdit->date().toString(Qt::ISODate));

    if (query.exec()) {
        while (query.next()) {
            const int index = hours.indexOf(query.value(0).toString());
            if (index >= 0 && index < values.size()) {
                values[index] = query.value(1).toString();
            }
        }
    }

    setLineValues(values);
}

void myplans::on_pushButton_clicked()
{
    if (!dateEdit || !initPlannerTables()) {
        return;
    }

    const QStringList hours = {"7:00", "9:00", "11:00", "13:00", "15:00", "17:00", "19:00", "21:00", "23:00"};
    const QStringList values = currentLineValues();

    QSqlDatabase db = QSqlDatabase::database("users_connection");
    QSqlQuery deleteQuery(db);
    deleteQuery.prepare("DELETE FROM daily_plans WHERE user_id = :user_id AND plan_date = :plan_date");
    deleteQuery.bindValue(":user_id", currentUserId);
    deleteQuery.bindValue(":plan_date", dateEdit->date().toString(Qt::ISODate));
    if (!deleteQuery.exec()) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось обновить планы: " + deleteQuery.lastError().text());
        return;
    }

    QSqlQuery insertQuery(db);
    insertQuery.prepare("INSERT INTO daily_plans (user_id, plan_date, hour, task_text) "
                        "VALUES (:user_id, :plan_date, :hour, :task_text)");

    for (int i = 0; i < hours.size(); ++i) {
        if (values[i].trimmed().isEmpty()) {
            continue;
        }

        insertQuery.bindValue(":user_id", currentUserId);
        insertQuery.bindValue(":plan_date", dateEdit->date().toString(Qt::ISODate));
        insertQuery.bindValue(":hour", hours[i]);
        insertQuery.bindValue(":task_text", values[i]);

        if (!insertQuery.exec()) {
            QMessageBox::critical(this, "Ошибка БД", "Не удалось сохранить планы: " + insertQuery.lastError().text());
            return;
        }
    }

    QMessageBox::information(this, "Готово", "Планы сохранены в приложении на выбранное число.");
}

void myplans::on_pushButton_4_clicked()
{
    emit signal();
    this->close();
}

void myplans::on_pushButton_2_clicked()
{
    if (!dateEdit || !initPlannerTables()) {
        return;
    }

    QSqlDatabase db = QSqlDatabase::database("users_connection");
    QSqlQuery query(db);
    query.prepare("DELETE FROM daily_plans WHERE user_id = :user_id AND plan_date = :plan_date");
    query.bindValue(":user_id", currentUserId);
    query.bindValue(":plan_date", dateEdit->date().toString(Qt::ISODate));

    if (!query.exec()) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось удалить планы: " + query.lastError().text());
        return;
    }

    clearLineValues();
    QMessageBox::information(this, "Готово", "Планы на выбранное число удалены.");
}

QString myplans::buildPlanText(const QDate &date) const
{
    if (!QSqlDatabase::contains("users_connection")) {
        return "База данных не подключена.";
    }

    QSqlDatabase db = QSqlDatabase::database("users_connection");
    if (!db.isOpen() && !db.open()) {
        return "Не удалось открыть базу данных.";
    }

    const QStringList hours = {"7:00", "9:00", "11:00", "13:00", "15:00", "17:00", "19:00", "21:00", "23:00"};
    QMap<QString, QString> values;

    QSqlQuery query(db);
    query.prepare("SELECT hour, task_text FROM daily_plans WHERE user_id = :user_id AND plan_date = :plan_date ORDER BY hour");
    query.bindValue(":user_id", currentUserId);
    query.bindValue(":plan_date", date.toString(Qt::ISODate));

    if (!query.exec()) {
        return "Не удалось прочитать планы: " + query.lastError().text();
    }

    while (query.next()) {
        values[query.value(0).toString()] = query.value(1).toString();
    }

    QString text = "Планы на " + date.toString("dd.MM.yyyy") + "\n\n";
    bool hasAny = false;
    for (const QString &hour : hours) {
        const QString value = values.value(hour).trimmed();
        text += hour + " - " + (value.isEmpty() ? "" : value) + "\n";
        if (!value.isEmpty()) {
            hasAny = true;
        }
    }

    if (!hasAny) {
        text += "\nНа выбранное число планов пока нет.";
    }

    return text.trimmed();
}

void myplans::showTextWindow(const QString &title, const QString &text)
{
    QDialog window(this);
    window.setWindowTitle(title);
    window.resize(520, 420);

    auto *layout = new QVBoxLayout(&window);
    auto *editor = new QTextEdit(&window);
    editor->setReadOnly(true);
    editor->setText(text);
    editor->setStyleSheet("QTextEdit { color: #000000; background: #FFFFFF; font-size: 14px; }");

    auto *buttons = new QDialogButtonBox(QDialogButtonBox::Close, &window);
    connect(buttons, &QDialogButtonBox::rejected, &window, &QDialog::accept);

    layout->addWidget(editor);
    layout->addWidget(buttons);
    window.exec();
}

void myplans::on_pushButton_3_clicked()
{
    if (!dateEdit) {
        return;
    }

    showTextWindow("Планы", buildPlanText(dateEdit->date()));
}
