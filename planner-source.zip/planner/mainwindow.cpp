#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"
#include "profiledialog.h"

#include <QApplication>
#include <QDebug>
#include <QMessageBox>
#include <QPixmap>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>

MainWindow::MainWindow(int userId, const QString &userLogin, QWidget *parent)
    : QMainWindow(parent),
      ui(new Ui::MainWindow),
      kontakt(nullptr),
      plans(nullptr),
      dialog1(nullptr),
      currentUserId(userId),
      currentUserLogin(userLogin),
      currentProfileName(userLogin)
{
    ui->setupUi(this);
    this->setWindowTitle("Ежедневник");

    if (currentUserId > 0 && QSqlDatabase::contains("users_connection")) {
        QSqlDatabase db = QSqlDatabase::database("users_connection");
        if (db.isOpen() || db.open()) {
            QSqlQuery query(db);
            query.prepare("SELECT name FROM users WHERE id = :id");
            query.bindValue(":id", currentUserId);
            if (query.exec() && query.next()) {
                const QString name = query.value(0).toString().trimmed();
                if (!name.isEmpty()) {
                    currentProfileName = name;
                }
            }
        }
    }

    updateProfileLabel(currentProfileName);

    kontakt = new mykontakts;
    connect(kontakt, &mykontakts::signal, this, &MainWindow::show);

    dialog1 = new Dialog(currentUserId);
    connect(dialog1, &Dialog::signal, this, &MainWindow::show);

    plans = new myplans(currentUserId);
    connect(plans, &myplans::signal, this, &MainWindow::show);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::updateProfileLabel(const QString &name)
{
    const QString shownName = name.trimmed().isEmpty() ? QString("Пользователь") : name.trimmed();
    ui->profileLabel->setText("Пользователь: " + shownName);
}

void MainWindow::on_pushButton_2_clicked()
{
    QMessageBox::StandardButton Exit = QMessageBox::question(this, "Ежедневник", "Нажмите да, если хотите выйти", QMessageBox::Yes | QMessageBox::No);
    if (Exit == QMessageBox::Yes) {
        QApplication::quit();
    } else {
        qDebug() << "";
    }
}

void MainWindow::on_pushButton_clicked()
{
    Dialog planner(currentUserId, this);
    hide();
    planner.setModal(true);
    planner.exec();
    show();
}

void MainWindow::on_pushButton_3_clicked()
{
    kontakt->show();
    this->close();
}

void MainWindow::on_pushButton_4_clicked()
{
    plans->show();
    this->close();
}

void MainWindow::on_pushButton_5_clicked()
{
    if (currentUserId <= 0) {
        QMessageBox::warning(this, "Профиль", "Профиль доступен после входа или регистрации пользователя.");
        return;
    }

    ProfileDialog profile(currentUserId, currentUserLogin, this);
    connect(&profile, &ProfileDialog::profileChanged, this, [this](const QString &name, const QString &) {
        currentProfileName = name;
        updateProfileLabel(currentProfileName);
    });

    profile.exec();
}
