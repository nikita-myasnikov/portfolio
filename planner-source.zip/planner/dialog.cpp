#include "dialog.h"
#include "ui_dialog.h"
#include "task.h"
#include "calendar.h"
#include "edit.h"

#include <QDateTime>
#include <QDialogButtonBox>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QVariant>

Dialog::Dialog(int userId, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog),
    currentUserId(userId)
{
    ui->setupUi(this);
    this->setWindowTitle("Календарь задач");
    initPlannerTables();
}

Dialog::~Dialog()
{
    delete ui;
}

bool Dialog::initPlannerTables()
{
    if (!QSqlDatabase::contains("users_connection")) {
        return false;
    }

    QSqlDatabase db = QSqlDatabase::database("users_connection");
    if (!db.isOpen() && !db.open()) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось открыть базу данных: " + db.lastError().text());
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec("CREATE TABLE IF NOT EXISTS tasks ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    "user_id INTEGER, "
                    "title TEXT NOT NULL, "
                    "description TEXT NOT NULL, "
                    "task_date TEXT, "
                    "created_at TEXT NOT NULL)")) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось создать таблицу задач: " + query.lastError().text());
        return false;
    }

    return true;
}

void Dialog::on_pushButton_clicked()
{
    Task forma(currentUserId, this);
    forma.setModal(true);
    forma.exec();
}

QString Dialog::buildTasksText() const
{
    if (!QSqlDatabase::contains("users_connection")) {
        return "База данных не подключена.";
    }

    QSqlDatabase db = QSqlDatabase::database("users_connection");
    if (!db.isOpen() && !db.open()) {
        return "Не удалось открыть базу данных.";
    }

    QSqlQuery query(db);
    query.prepare("SELECT title, description, task_date, created_at FROM tasks "
                  "WHERE user_id = :user_id OR :user_id <= 0 "
                  "ORDER BY COALESCE(task_date, created_at) DESC, id DESC");
    query.bindValue(":user_id", currentUserId);

    if (!query.exec()) {
        return "Не удалось прочитать задачи: " + query.lastError().text();
    }

    QString text;
    while (query.next()) {
        const QString title = query.value(0).toString();
        const QString description = query.value(1).toString();
        const QString date = query.value(2).toString();
        const QString created = query.value(3).toString();

        text += "Задача: " + title + "\n";
        text += "Описание: " + description + "\n";
        if (!date.isEmpty()) {
            text += "Дата: " + QDate::fromString(date, Qt::ISODate).toString("dd.MM.yyyy") + "\n";
        }
        text += "Добавлено: " + QDateTime::fromString(created, Qt::ISODate).toString("dd.MM.yyyy HH:mm") + "\n";
        text += "------------------------------\n";
    }

    return text.trimmed().isEmpty() ? "Список задач пока пуст." : text.trimmed();
}

void Dialog::showTextWindow(const QString &title, const QString &text)
{
    QDialog window(this);
    window.setWindowTitle(title);
    window.resize(560, 420);

    auto *layout = new QVBoxLayout(&window);
    auto *editor = new QTextEdit(&window);
    editor->setReadOnly(true);
    editor->setText(text);
    editor->setStyleSheet("QTextEdit { color: #000000; background: #FFFFFF; font-size: 14px; }");

    auto *buttons = new QDialogButtonBox(QDialogButtonBox::Close, &window);
    connect(buttons, &QDialogButtonBox::rejected, &window, &QDialog::accept);

    layout->addWidget(editor);
    layout->addWidget(buttons);
    window.exec();
}

void Dialog::on_pushButton_2_clicked()
{
    initPlannerTables();
    showTextWindow("Список задач", buildTasksText());
}

void Dialog::on_calendarWidget_clicked(const QDate &date)
{
    Calendar formacl(date, currentUserId, this);
    formacl.setModal(true);
    formacl.exec();
}

void Dialog::on_pushButton_4_clicked()
{
    emit signal();
    this->accept();
}

void Dialog::on_pushButton_3_clicked()
{
    Edit editmain(currentUserId, this);
    editmain.setModal(true);
    editmain.exec();
}
