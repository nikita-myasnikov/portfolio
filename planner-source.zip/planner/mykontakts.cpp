#include "mykontakts.h"
#include "ui_mykontakts.h"

mykontakts::mykontakts(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::mykontakts)
{
    ui->setupUi(this);
}

mykontakts::~mykontakts()
{
    delete ui;
}

void mykontakts::on_save_button_clicked()
{
    if (ui->nameLine->text().isEmpty()
        || ui->surnameLine->text().isEmpty()
        || ui->phoneLine->text().isEmpty()
        || ui->telegramLine->text().isEmpty())
    {
        QMessageBox::warning(this, "Ошибка!", "Пожалуйста, заполните все поля.");
    }
    else
    {
        QFile contact_file("Contact.txt");
        if (contact_file.open(QIODevice::Append | QIODevice::ReadWrite | QIODevice::Text))
        {
            QTextStream in(&contact_file);
            in << "***\nНомер телефона: " << ui->phoneLine->text()
               << "\nФамилия: " << ui->surnameLine->text()
               << "\nИмя: " << ui->nameLine->text()
               << "\nТелеграм: " << ui->telegramLine->text()
               << "\nДата рождения: " << ui->dateEdit->date().toString("dd-MM-yyyy") << "\n";
        }
    }
}


void mykontakts::on_pushButton_clicked()
{
    emit signal();
    this->close();
}


void mykontakts::on_save_button_2_clicked()
{
    QFile contact_file("Contact.txt");
    QString contactsText;

    if (contact_file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextStream in(&contact_file);
        contactsText = in.readAll().trimmed();
        contact_file.close();
    }

    if (contactsText.isEmpty())
    {
        contactsText = "Список контактов пока пуст.\nДобавьте контакт и нажмите кнопку «Сохранить».";
    }

    QDialog contactsDialog(this);
    contactsDialog.setWindowTitle("Список контактов");
    contactsDialog.resize(650, 520);
    contactsDialog.setStyleSheet(
        "QDialog { background-color: rgb(208, 190, 251); }"
        "QLabel { color: rgb(61, 0, 91); font: 22pt 'Century Gothic'; }"
        "QTextEdit { background-color: white; color: black; font: 13pt 'Century Gothic';"
        "border: 2px solid rgb(116, 7, 184); border-radius: 14px; padding: 10px; }"
        "QPushButton { background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1,"
        "stop:0 rgba(208, 190, 251, 255), stop:1 rgba(255, 255, 255, 255));"
        "color: rgb(116, 7, 184); font: 15pt 'Century Gothic'; border-radius: 19px; padding: 10px; }"
    );

    QLabel *titleLabel = new QLabel("Список контактов", &contactsDialog);
    titleLabel->setAlignment(Qt::AlignCenter);

    QTextEdit *contactsEdit = new QTextEdit(&contactsDialog);
    contactsEdit->setReadOnly(true);
    contactsEdit->setPlainText(contactsText);

    QPushButton *closeButton = new QPushButton("Выход в меню", &contactsDialog);
    connect(closeButton, &QPushButton::clicked, &contactsDialog, &QDialog::accept);

    QVBoxLayout *layout = new QVBoxLayout(&contactsDialog);
    layout->setContentsMargins(25, 25, 25, 25);
    layout->setSpacing(15);
    layout->addWidget(titleLabel);
    layout->addWidget(contactsEdit);
    layout->addWidget(closeButton);

    contactsDialog.exec();
}


void mykontakts::on_save_button_3_clicked()
{
    QFile file("Contact.txt");
    QFile tempFile("Contact1.txt");
    QTextStream in(&file);
    QTextStream out(&tempFile);
    QString phone = ui->phoneLine->text();
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        qDebug() << "Не удалось открыть файл";
        return;
    }

    if(!tempFile.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        qDebug() << "Не удалось создать временный файл";
        file.close();
        return;
    }
    while (!in.atEnd())
    {
        QString line = in.readLine();
        if (line.contains(phone))
        {
            in.readLine();
            in.readLine();
            in.readLine();
            in.readLine();
            continue;
        }
        out << line << "\n";
    }
    file.close();
    tempFile.close();

    QFile::remove("Contact.txt"); // удаляем исходный файл
    QFile::rename("Contact1.txt", "Contact.txt");
}

