#include "mainwindow.h"
#include "registerdialog.h"

#include <QApplication>
#include <QDialog>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    a.setStyleSheet(
        "QMessageBox { background-color: #FFFFFF; }"
        "QMessageBox QLabel { color: #000000; font-size: 12px; }"
        "QMessageBox QPushButton { color: #000000; min-width: 82px; padding: 6px 12px; }"
    );

    RegisterDialog registration;
    if (registration.exec() != QDialog::Accepted) {
        return 0;
    }

    MainWindow w(registration.currentUserId(), registration.currentLogin());
    w.show();

    return a.exec();
}
