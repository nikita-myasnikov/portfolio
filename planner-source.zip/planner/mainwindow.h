#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "mykontakts.h"
#include <QMainWindow>
#include <QString>
#include "dialog.h"
#include "myplans.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(int userId = -1, const QString &userLogin = QString(), QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

private:
    void updateProfileLabel(const QString &name);

    Ui::MainWindow *ui;
    mykontakts *kontakt;
    myplans *plans;
    Dialog *dialog1;
    int currentUserId;
    QString currentUserLogin;
    QString currentProfileName;

signals:
    void signal();
};
#endif // MAINWINDOW_H
