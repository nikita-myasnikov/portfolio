using System;
using NegativeNumbersTrainer.Models;

namespace NegativeNumbersTrainer.Modules;

public sealed class TaskGenerator
{
    private readonly Random _random;

    public TaskGenerator()
        : this(new Random())
    {
    }

    internal TaskGenerator(Random random)
    {
        _random = random ?? throw new ArgumentNullException(nameof(random));
    }

    public TrainingTask Generate(DifficultyLevel level)
    {
        var (minimum, maximum) = GetRange(level);
        var firstNumber = _random.Next(minimum, maximum + 1);
        var secondNumber = _random.Next(minimum, maximum + 1);
        var operation = _random.Next(2) == 0 ? '+' : '-';
        var correctAnswer = operation == '+'
            ? firstNumber + secondNumber
            : firstNumber - secondNumber;

        return new TrainingTask(firstNumber, secondNumber, operation, correctAnswer);
    }

    private static (int Minimum, int Maximum) GetRange(DifficultyLevel level)
    {
        return level switch
        {
            DifficultyLevel.Easy => (-10, 10),
            DifficultyLevel.Medium => (-50, 50),
            DifficultyLevel.Hard => (-100, 100),
            _ => throw new ArgumentOutOfRangeException(nameof(level), level, "Неизвестный уровень сложности.")
        };
    }
}
