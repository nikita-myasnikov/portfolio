namespace NegativeNumbersTrainer.Modules;

public sealed class TheoryModule
{
    private const string Material =
        "Чтобы сложить два отрицательных числа, необходимо сложить их модули " +
        "и поставить перед результатом знак минус.\n\n" +
        "Чтобы вычесть число, замените вычитание сложением с противоположным числом. " +
        "Например: −7 − (−3) = −7 + 3 = −4.";

    public string GetMaterial()
    {
        return Material;
    }
}
