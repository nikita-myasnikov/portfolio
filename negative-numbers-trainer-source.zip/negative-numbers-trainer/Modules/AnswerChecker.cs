using System;
using NegativeNumbersTrainer.Models;

namespace NegativeNumbersTrainer.Modules;

public sealed class AnswerChecker
{
    public TrainingResult Check(TrainingTask task, int userAnswer)
    {
        ArgumentNullException.ThrowIfNull(task);

        return new TrainingResult(
            task,
            userAnswer,
            userAnswer == task.CorrectAnswer);
    }
}
