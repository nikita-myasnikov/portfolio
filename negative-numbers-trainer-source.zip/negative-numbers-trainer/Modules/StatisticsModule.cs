using System.Collections.Generic;
using System.Linq;
using System;
using NegativeNumbersTrainer.Models;

namespace NegativeNumbersTrainer.Modules;

public sealed class StatisticsModule
{
    private readonly List<TrainingResult> _results = new();

    public IReadOnlyList<TrainingResult> Results => _results.AsReadOnly();

    public int TotalCount => _results.Count;

    public int CorrectCount => _results.Count(result => result.IsCorrect);

    public int IncorrectCount => TotalCount - CorrectCount;

    public double CorrectPercent => TotalCount == 0
        ? 0
        : (double)CorrectCount / TotalCount * 100;

    public void Add(TrainingResult result)
    {
        ArgumentNullException.ThrowIfNull(result);
        _results.Add(result);
    }

    public void Reset()
    {
        _results.Clear();
    }
}
