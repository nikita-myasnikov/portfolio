using System;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using NegativeNumbersTrainer.Controllers;
using NegativeNumbersTrainer.Modules;
using NegativeNumbersTrainer.Views;

namespace NegativeNumbersTrainer;

public partial class MainWindow : Window
{
    private readonly LearningController _learningController;
    private ContentControl _contentHost = null!;

    public MainWindow()
        : this(CreateDefaultController())
    {
    }

    public MainWindow(LearningController learningController)
    {
        _learningController = learningController;
        InitializeComponent();
        ShowMainMenu();
    }

    private void InitializeComponent()
    {
        AvaloniaXamlLoader.Load(this);
        _contentHost = this.FindControl<ContentControl>("ContentHost")
            ?? throw new InvalidOperationException("Не удалось загрузить область содержимого главного окна.");
    }

    private static LearningController CreateDefaultController()
    {
        return new LearningController(
            new TheoryModule(),
            new TaskGenerator(),
            new AnswerChecker(),
            new StatisticsModule());
    }

    private void ShowMainMenu()
    {
        var view = new MainMenuView();
        view.NavigationRequested += OnNavigationRequested;
        SetContent(view);
    }

    private void OnNavigationRequested(string destination)
    {
        switch (destination)
        {
            case MainMenuView.TheoryDestination:
                SetContent(new TheoryView(_learningController.GetTheoryMaterial()));
                break;
            case MainMenuView.PracticeDestination:
                ShowDifficultyView();
                break;
            case MainMenuView.StatisticsDestination:
                ShowStatisticsView();
                break;
            case MainMenuView.SettingsDestination:
                SetContent(new SettingsView());
                break;
            default:
                ShowMainMenu();
                break;
        }
    }

    private void ShowDifficultyView()
    {
        var view = new DifficultyView(_learningController);
        view.TrainingStarted += OnTrainingStarted;
        SetContent(view);
    }

    private void OnTrainingStarted(object? sender, EventArgs e)
    {
        ShowPracticeView();
    }

    private void ShowPracticeView()
    {
        var view = new PracticeView(_learningController);
        view.ResultsRequested += OnResultsRequested;
        SetContent(view);
    }

    private void OnResultsRequested(object? sender, EventArgs e)
    {
        ShowStatisticsView();
    }

    private void ShowStatisticsView()
    {
        SetContent(new StatisticsView(_learningController.GetStatistics()));
    }

    private void SetContent(UserControl view)
    {
        if (_contentHost.Content is MainMenuView currentMenu)
        {
            currentMenu.NavigationRequested -= OnNavigationRequested;
        }

        if (_contentHost.Content is DifficultyView currentDifficulty)
        {
            currentDifficulty.TrainingStarted -= OnTrainingStarted;
        }

        if (_contentHost.Content is PracticeView currentPractice)
        {
            currentPractice.ResultsRequested -= OnResultsRequested;
        }

        if (_contentHost.Content is IBackNavigable currentBackNavigable)
        {
            currentBackNavigable.BackRequested -= OnBackRequested;
        }

        if (view is IBackNavigable backNavigable)
        {
            backNavigable.BackRequested += OnBackRequested;
        }

        _contentHost.Content = view;
    }

    private void OnBackRequested(object? sender, EventArgs e)
    {
        ShowMainMenu();
    }
}
