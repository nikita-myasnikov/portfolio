using System;
using NegativeNumbersTrainer.Models;
using NegativeNumbersTrainer.Modules;

namespace NegativeNumbersTrainer.Controllers;

public sealed class LearningController
{
    public const int TotalTaskCount = 10;

    private readonly TheoryModule _theoryModule;
    private readonly TaskGenerator _taskGenerator;
    private readonly AnswerChecker _answerChecker;
    private readonly StatisticsModule _statisticsModule;
    private DifficultyLevel _currentDifficulty = DifficultyLevel.Easy;
    private TrainingTask? _currentTask;
    private bool _currentTaskAnswered;

    public LearningController(
        TheoryModule theoryModule,
        TaskGenerator taskGenerator,
        AnswerChecker answerChecker,
        StatisticsModule statisticsModule)
    {
        _theoryModule = theoryModule ?? throw new ArgumentNullException(nameof(theoryModule));
        _taskGenerator = taskGenerator ?? throw new ArgumentNullException(nameof(taskGenerator));
        _answerChecker = answerChecker ?? throw new ArgumentNullException(nameof(answerChecker));
        _statisticsModule = statisticsModule ?? throw new ArgumentNullException(nameof(statisticsModule));
    }

    public void SetDifficulty(DifficultyLevel level)
    {
        if (!Enum.IsDefined(level))
        {
            throw new ArgumentOutOfRangeException(nameof(level), level, "Неизвестный уровень сложности.");
        }

        _currentDifficulty = level;
    }

    public DifficultyLevel CurrentDifficulty => _currentDifficulty;

    public TrainingTask? CurrentTask => _currentTask;

    public int CurrentTaskNumber { get; private set; }

    public bool HasMoreTasks => CurrentTaskNumber > 0 && CurrentTaskNumber < TotalTaskCount;

    public bool IsTrainingComplete =>
        CurrentTaskNumber == TotalTaskCount && _currentTaskAnswered;

    public TrainingTask StartTraining(DifficultyLevel level)
    {
        SetDifficulty(level);
        _statisticsModule.Reset();
        CurrentTaskNumber = 0;
        _currentTask = null;
        _currentTaskAnswered = false;

        return CreateNextTask();
    }

    public TrainingTask CreateNextTask()
    {
        if (CurrentTaskNumber == 0)
        {
            CurrentTaskNumber = 1;
        }
        else
        {
            if (!_currentTaskAnswered)
            {
                throw new InvalidOperationException("Сначала необходимо ответить на текущее задание.");
            }

            if (!HasMoreTasks)
            {
                throw new InvalidOperationException("Тренировочная серия уже завершена.");
            }

            CurrentTaskNumber++;
        }

        _currentTask = _taskGenerator.Generate(_currentDifficulty);
        _currentTaskAnswered = false;
        return _currentTask;
    }

    public TrainingResult CheckAnswer(int userAnswer)
    {
        if (_currentTask is null)
        {
            throw new InvalidOperationException("Сначала необходимо сформировать задание.");
        }

        if (_currentTaskAnswered)
        {
            throw new InvalidOperationException("Ответ на текущее задание уже был проверен.");
        }

        var result = _answerChecker.Check(_currentTask, userAnswer);
        _statisticsModule.Add(result);
        _currentTaskAnswered = true;
        return result;
    }

    public StatisticsModule GetStatistics()
    {
        return _statisticsModule;
    }

    public string GetTheoryMaterial()
    {
        return _theoryModule.GetMaterial();
    }
}
