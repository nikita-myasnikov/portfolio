using System;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;

namespace NegativeNumbersTrainer.Views;

public partial class MainMenuView : UserControl
{
    public const string TheoryDestination = "Theory";
    public const string PracticeDestination = "Practice";
    public const string StatisticsDestination = "Statistics";
    public const string SettingsDestination = "Settings";

    public MainMenuView()
    {
        InitializeComponent();
    }

    public event Action<string>? NavigationRequested;

    private void InitializeComponent()
    {
        AvaloniaXamlLoader.Load(this);
    }

    private void OnTheoryClick(object? sender, RoutedEventArgs e)
    {
        NavigationRequested?.Invoke(TheoryDestination);
    }

    private void OnPracticeClick(object? sender, RoutedEventArgs e)
    {
        NavigationRequested?.Invoke(PracticeDestination);
    }

    private void OnStatisticsClick(object? sender, RoutedEventArgs e)
    {
        NavigationRequested?.Invoke(StatisticsDestination);
    }

    private void OnSettingsClick(object? sender, RoutedEventArgs e)
    {
        NavigationRequested?.Invoke(SettingsDestination);
    }
}
