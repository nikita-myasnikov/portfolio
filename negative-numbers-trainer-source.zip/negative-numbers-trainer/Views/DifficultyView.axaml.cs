using System;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using NegativeNumbersTrainer.Controllers;
using NegativeNumbersTrainer.Models;

namespace NegativeNumbersTrainer.Views;

public partial class DifficultyView : UserControl, IBackNavigable
{
    private readonly LearningController? _learningController;

    public DifficultyView()
    {
        InitializeComponent();
    }

    public DifficultyView(LearningController learningController)
        : this()
    {
        _learningController = learningController ?? throw new ArgumentNullException(nameof(learningController));
    }

    public event EventHandler? BackRequested;

    public event EventHandler? TrainingStarted;

    private void InitializeComponent()
    {
        AvaloniaXamlLoader.Load(this);
    }

    private void OnBackClick(object? sender, RoutedEventArgs e)
    {
        BackRequested?.Invoke(this, EventArgs.Empty);
    }

    private void OnEasyClick(object? sender, RoutedEventArgs e)
    {
        StartTraining(DifficultyLevel.Easy);
    }

    private void OnMediumClick(object? sender, RoutedEventArgs e)
    {
        StartTraining(DifficultyLevel.Medium);
    }

    private void OnHardClick(object? sender, RoutedEventArgs e)
    {
        StartTraining(DifficultyLevel.Hard);
    }

    private void StartTraining(DifficultyLevel level)
    {
        if (_learningController is null)
        {
            throw new InvalidOperationException("Контроллер обучения не был подключён.");
        }

        _learningController.StartTraining(level);
        TrainingStarted?.Invoke(this, EventArgs.Empty);
    }
}
