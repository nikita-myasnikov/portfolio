using System;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;

namespace NegativeNumbersTrainer.Views;

public partial class TheoryView : UserControl, IBackNavigable
{
    private TextBlock _materialText = null!;

    public TheoryView()
    {
        InitializeComponent();
    }

    public TheoryView(string material)
        : this()
    {
        _materialText.Text = material;
    }

    public event EventHandler? BackRequested;

    private void InitializeComponent()
    {
        AvaloniaXamlLoader.Load(this);
        _materialText = this.FindControl<TextBlock>("MaterialText")
            ?? throw new InvalidOperationException("Не удалось загрузить теоретический материал.");
    }

    private void OnBackClick(object? sender, RoutedEventArgs e)
    {
        BackRequested?.Invoke(this, EventArgs.Empty);
    }
}
