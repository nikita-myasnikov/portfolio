using System;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Avalonia.Threading;
using NegativeNumbersTrainer.Controllers;
using NegativeNumbersTrainer.Models;

namespace NegativeNumbersTrainer.Views;

public partial class PracticeView : UserControl, IBackNavigable
{
    private readonly LearningController? _learningController;
    private TextBlock _difficultyText = null!;
    private TextBlock _progressText = null!;
    private TextBlock _taskText = null!;
    private TextBox _answerTextBox = null!;
    private TextBlock _validationText = null!;
    private TextBlock _feedbackText = null!;
    private TextBlock _correctAnswerText = null!;
    private Button _actionButton = null!;
    private bool _answerChecked;

    public PracticeView()
    {
        InitializeComponent();
    }

    public PracticeView(LearningController learningController)
        : this()
    {
        _learningController = learningController ?? throw new ArgumentNullException(nameof(learningController));
        ShowCurrentTask();
    }

    public event EventHandler? BackRequested;

    public event EventHandler? ResultsRequested;

    private void InitializeComponent()
    {
        AvaloniaXamlLoader.Load(this);
        _difficultyText = FindRequired<TextBlock>("DifficultyText");
        _progressText = FindRequired<TextBlock>("ProgressText");
        _taskText = FindRequired<TextBlock>("TaskText");
        _answerTextBox = FindRequired<TextBox>("AnswerTextBox");
        _validationText = FindRequired<TextBlock>("ValidationText");
        _feedbackText = FindRequired<TextBlock>("FeedbackText");
        _correctAnswerText = FindRequired<TextBlock>("CorrectAnswerText");
        _actionButton = FindRequired<Button>("ActionButton");
    }

    private void OnBackClick(object? sender, RoutedEventArgs e)
    {
        BackRequested?.Invoke(this, EventArgs.Empty);
    }

    private void OnActionClick(object? sender, RoutedEventArgs e)
    {
        PerformPrimaryAction();
    }

    private void OnAnswerKeyDown(object? sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter)
        {
            return;
        }

        e.Handled = true;
        PerformPrimaryAction();
    }

    private void PerformPrimaryAction()
    {
        if (_answerChecked)
        {
            MoveForward();
        }
        else
        {
            CheckAnswer();
        }
    }

    private void CheckAnswer()
    {
        if (_learningController is null)
        {
            return;
        }

        if (!int.TryParse(_answerTextBox.Text?.Trim(), out var userAnswer))
        {
            _validationText.Text = "Введите целое число.";
            _validationText.IsVisible = true;
            _answerTextBox.Focus();
            return;
        }

        _validationText.IsVisible = false;
        var result = _learningController.CheckAnswer(userAnswer);
        _answerChecked = true;
        _answerTextBox.IsReadOnly = true;
        _feedbackText.IsVisible = true;

        if (result.IsCorrect)
        {
            _feedbackText.Text = "Верно!";
            _feedbackText.Foreground = Brushes.SeaGreen;
            _correctAnswerText.IsVisible = false;
        }
        else
        {
            _feedbackText.Text = "Неверно";
            _feedbackText.Foreground = Brushes.Firebrick;
            _correctAnswerText.Text = $"Правильный ответ: {result.Task.CorrectAnswer}";
            _correctAnswerText.IsVisible = true;
        }

        _actionButton.Content = _learningController.HasMoreTasks
            ? "Следующее задание"
            : "Посмотреть результаты";
        _actionButton.Focus();
    }

    private void MoveForward()
    {
        if (_learningController is null)
        {
            return;
        }

        if (_learningController.HasMoreTasks)
        {
            _learningController.CreateNextTask();
            ShowCurrentTask();
            return;
        }

        if (_learningController.IsTrainingComplete)
        {
            ResultsRequested?.Invoke(this, EventArgs.Empty);
        }
    }

    private void ShowCurrentTask()
    {
        if (_learningController?.CurrentTask is not TrainingTask task)
        {
            throw new InvalidOperationException("Текущее задание не было сформировано.");
        }

        _difficultyText.Text = $"Уровень: {GetDifficultyName(_learningController.CurrentDifficulty)}";
        _progressText.Text = $"Задание {_learningController.CurrentTaskNumber} из {LearningController.TotalTaskCount}";
        _taskText.Text = task.GetText();
        _answerTextBox.Text = string.Empty;
        _answerTextBox.IsReadOnly = false;
        _validationText.IsVisible = false;
        _feedbackText.IsVisible = false;
        _correctAnswerText.IsVisible = false;
        _actionButton.Content = "Проверить";
        _answerChecked = false;

        Dispatcher.UIThread.Post(() => _answerTextBox.Focus());
    }

    private T FindRequired<T>(string name)
        where T : Control
    {
        return this.FindControl<T>(name)
            ?? throw new InvalidOperationException("Не удалось загрузить элемент экрана практики.");
    }

    private static string GetDifficultyName(DifficultyLevel level)
    {
        return level switch
        {
            DifficultyLevel.Easy => "Лёгкий",
            DifficultyLevel.Medium => "Средний",
            DifficultyLevel.Hard => "Сложный",
            _ => throw new ArgumentOutOfRangeException(nameof(level), level, "Неизвестный уровень сложности.")
        };
    }
}
