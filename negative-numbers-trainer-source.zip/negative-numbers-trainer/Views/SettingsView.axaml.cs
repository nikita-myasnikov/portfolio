using System;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;

namespace NegativeNumbersTrainer.Views;

public partial class SettingsView : UserControl, IBackNavigable
{
    public SettingsView()
    {
        InitializeComponent();
    }

    public event EventHandler? BackRequested;

    private void InitializeComponent()
    {
        AvaloniaXamlLoader.Load(this);
    }

    private void OnBackClick(object? sender, RoutedEventArgs e)
    {
        BackRequested?.Invoke(this, EventArgs.Empty);
    }
}
