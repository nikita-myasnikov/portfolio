using System;

namespace NegativeNumbersTrainer.Views;

public interface IBackNavigable
{
    event EventHandler? BackRequested;
}
