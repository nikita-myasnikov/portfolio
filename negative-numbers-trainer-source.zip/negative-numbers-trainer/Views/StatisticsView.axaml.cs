using System;
using System.Globalization;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using NegativeNumbersTrainer.Modules;

namespace NegativeNumbersTrainer.Views;

public partial class StatisticsView : UserControl, IBackNavigable
{
    private TextBlock _totalCountText = null!;
    private TextBlock _correctCountText = null!;
    private TextBlock _incorrectCountText = null!;
    private TextBlock _correctPercentText = null!;

    public StatisticsView()
    {
        InitializeComponent();
    }

    public StatisticsView(StatisticsModule statisticsModule)
        : this()
    {
        _totalCountText.Text = statisticsModule.TotalCount.ToString();
        _correctCountText.Text = statisticsModule.CorrectCount.ToString();
        _incorrectCountText.Text = statisticsModule.IncorrectCount.ToString();
        var russianCulture = CultureInfo.GetCultureInfo("ru-RU");
        _correctPercentText.Text = $"{statisticsModule.CorrectPercent.ToString("F1", russianCulture)} %";
    }

    public event EventHandler? BackRequested;

    private void InitializeComponent()
    {
        AvaloniaXamlLoader.Load(this);
        _totalCountText = FindRequiredTextBlock("TotalCountText");
        _correctCountText = FindRequiredTextBlock("CorrectCountText");
        _incorrectCountText = FindRequiredTextBlock("IncorrectCountText");
        _correctPercentText = FindRequiredTextBlock("CorrectPercentText");
    }

    private TextBlock FindRequiredTextBlock(string name)
    {
        return this.FindControl<TextBlock>(name)
            ?? throw new InvalidOperationException("Не удалось загрузить элемент статистики.");
    }

    private void OnBackClick(object? sender, RoutedEventArgs e)
    {
        BackRequested?.Invoke(this, EventArgs.Empty);
    }
}
