namespace NegativeNumbersTrainer.Models;

public enum DifficultyLevel
{
    Easy,
    Medium,
    Hard
}
