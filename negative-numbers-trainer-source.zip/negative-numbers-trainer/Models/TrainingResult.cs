using System;

namespace NegativeNumbersTrainer.Models;

public sealed class TrainingResult
{
    public TrainingResult(TrainingTask task, int userAnswer, bool isCorrect)
    {
        Task = task ?? throw new ArgumentNullException(nameof(task));
        UserAnswer = userAnswer;
        IsCorrect = isCorrect;
    }

    public TrainingTask Task { get; }

    public int UserAnswer { get; }

    public bool IsCorrect { get; }
}
