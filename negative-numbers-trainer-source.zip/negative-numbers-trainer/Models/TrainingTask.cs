namespace NegativeNumbersTrainer.Models;

public sealed class TrainingTask
{
    public TrainingTask(int firstNumber, int secondNumber, char operation, int correctAnswer)
    {
        FirstNumber = firstNumber;
        SecondNumber = secondNumber;
        Operation = operation;
        CorrectAnswer = correctAnswer;
    }

    public int FirstNumber { get; }

    public int SecondNumber { get; }

    public char Operation { get; }

    public int CorrectAnswer { get; }

    public string GetText()
    {
        var secondNumberText = SecondNumber < 0
            ? $"({SecondNumber})"
            : SecondNumber.ToString();

        return $"{FirstNumber} {Operation} {secondNumberText} = ?";
    }
}
