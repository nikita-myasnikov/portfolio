using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using NegativeNumbersTrainer.Controllers;
using NegativeNumbersTrainer.Modules;

namespace NegativeNumbersTrainer;

public partial class App : Application
{
    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
    }

    public override void OnFrameworkInitializationCompleted()
    {
        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            var theoryModule = new TheoryModule();
            var taskGenerator = new TaskGenerator();
            var answerChecker = new AnswerChecker();
            var statisticsModule = new StatisticsModule();

            var learningController = new LearningController(
                theoryModule,
                taskGenerator,
                answerChecker,
                statisticsModule);

            desktop.MainWindow = new MainWindow(learningController);
        }

        base.OnFrameworkInitializationCompleted();
    }
}
