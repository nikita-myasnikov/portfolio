import assert from "node:assert/strict";
import test from "node:test";
import { calculateOrderTotal, canTransition, isProductOrderable, validateBelarusPhone } from "../lib/domain.mjs";

test("validates Belarus phone numbers with a human-facing format", () => {
  assert.equal(validateBelarusPhone("+375 29 123-45-67"), true);
  assert.equal(validateBelarusPhone("+7 999 123-45-67"), false);
  assert.equal(validateBelarusPhone("375291234567"), false);
});

test("calculates quantities, delivery threshold and promo discount", () => {
  assert.deepEqual(calculateOrderTotal([{ price: 129, quantity: 1 }]), { subtotal: 129, discount: 0, delivery: 10, total: 139 });
  assert.deepEqual(calculateOrderTotal([{ price: 100, quantity: 2 }], 10, 180, 10), { subtotal: 200, discount: 20, delivery: 0, total: 180 });
});

test("prevents unavailable products from entering checkout", () => {
  assert.equal(isProductOrderable({ active: true, available: true, price: 129 }), true);
  assert.equal(isProductOrderable({ active: true, available: false, price: 129 }), false);
});

test("keeps order status updates in the expected sequence", () => {
  assert.equal(canTransition("accepted", "paid"), true);
  assert.equal(canTransition("paid", "ready"), false);
  assert.equal(canTransition("on_the_way", "delivered"), true);
});
