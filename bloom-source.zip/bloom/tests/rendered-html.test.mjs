import assert from "node:assert/strict";
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("..", import.meta.url));

async function readBuildTree(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const contents = await Promise.all(entries.map(async (entry) => {
    const entryPath = path.join(directory, entry.name);
    if (entry.isDirectory()) return readBuildTree(entryPath);
    if (!/\.(js|html)$/.test(entry.name)) return "";
    return readFile(entryPath, "utf8");
  }));
  return contents.join("\n");
}

test("build contains the BLOOM storefront metadata and primary action", async () => {
  const output = await readBuildTree(path.join(root, "dist"));
  assert.match(output, /BLOOM/);
  assert.match(output, /доставка цветов в Минске/i);
  assert.match(output, /Выбрать букет/i);
  assert.doesNotMatch(output, /Starter Project/);
});
