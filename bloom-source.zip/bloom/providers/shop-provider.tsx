"use client";

import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { addons, products } from "@/data/products";
import type { CartItem, Product, ProductSize } from "@/types/shop";
import { analytics } from "@/lib/providers";

type ShopContextValue = {
  cart: CartItem[];
  favorites: string[];
  cartCount: number;
  subtotal: number;
  addToCart: (product: Product, size: ProductSize, options?: Partial<CartItem>) => void;
  updateQuantity: (lineId: string, quantity: number) => void;
  removeFromCart: (lineId: string) => void;
  clearCart: () => void;
  toggleFavorite: (productId: string) => void;
  resolveProduct: (id: string) => Product;
  lineTotal: (item: CartItem) => number;
};

const ShopContext = createContext<ShopContextValue | null>(null);

function createLineId() {
  const values = new Uint32Array(4);
  globalThis.crypto.getRandomValues(values);
  return Array.from(values, (value) => value.toString(16).padStart(8, "0")).join("");
}

export function ShopProvider({ children }: { children: React.ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const storedCart = JSON.parse(localStorage.getItem("bloom_cart") || "[]") as CartItem[];
      const storedFavorites = JSON.parse(localStorage.getItem("bloom_favorites") || "[]") as string[];
      setCart((current) => current.length ? current : storedCart);
      setFavorites((current) => current.length ? current : storedFavorites);
    } catch { /* corrupted browser draft: begin clean */ }
    setHydrated(true);
  }, []);

  useEffect(() => { if (hydrated) localStorage.setItem("bloom_cart", JSON.stringify(cart)); }, [cart, hydrated]);
  useEffect(() => { if (hydrated) localStorage.setItem("bloom_favorites", JSON.stringify(favorites)); }, [favorites, hydrated]);

  const resolveProduct = (id: string) => products.find((product) => product.id === id) ?? products[0];
  const lineTotal = (item: CartItem) => {
    const product = resolveProduct(item.productId);
    const extras = item.addons.reduce((sum, id) => sum + (addons.find((addon) => addon.id === id)?.price ?? 0), 0);
    return (product.sizes[item.size].price + extras) * item.quantity;
  };

  const value = useMemo<ShopContextValue>(() => ({
    cart,
    favorites,
    cartCount: cart.reduce((sum, item) => sum + item.quantity, 0),
    subtotal: cart.reduce((sum, item) => sum + lineTotal(item), 0),
    addToCart(product, size, options = {}) {
      const line: CartItem = {
        lineId: createLineId(), productId: product.id, size, quantity: 1,
        cardText: "", unsignedCard: false, anonymous: false, surprise: false,
        surpriseMode: "Не звонить заранее", photoBeforeDelivery: true, addons: [], ...options,
      };
      setCart((current) => [...current, line]);
      analytics.track("add_to_cart", { productId: product.id, size });
    },
    updateQuantity(lineId, quantity) { setCart((current) => current.map((item) => item.lineId === lineId ? { ...item, quantity: Math.max(1, quantity) } : item)); },
    removeFromCart(lineId) { setCart((current) => current.filter((item) => item.lineId !== lineId)); analytics.track("remove_from_cart", { lineId }); },
    clearCart() { setCart([]); },
    toggleFavorite(productId) {
      setFavorites((current) => current.includes(productId) ? current.filter((id) => id !== productId) : [...current, productId]);
      analytics.track("favorite", { productId });
    },
    resolveProduct,
    lineTotal,
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [cart, favorites]);

  return <ShopContext.Provider value={value}>{children}</ShopContext.Provider>;
}

export function useShop() {
  const context = useContext(ShopContext);
  if (!context) throw new Error("useShop must be used within ShopProvider");
  return context;
}
