# BLOOM

Полноценная демонстрационная версия интернет-магазина цветов с доставкой по Минску. В проекте работают каталог, фильтры, избранное, карточка букета, дополнения, открытка, анонимная доставка, корзина, checkout, создание заказа, приватное отслеживание и защищённая административная панель.

## Запуск

Требуется Node.js 22.13+.

```bash
npm ci
npm run db:generate
npm run dev
```

Для production-проверки:

```bash
npm run lint
npx tsc --noEmit
npm test
```

## Development admin

- URL: `/admin-login`
- Email: `admin@bloom.local`
- Пароль: `BloomDemo2026!`

Эти данные работают только при `BLOOM_DEMO_ADMIN_ENABLED=true`. Перед публикацией отключите demo-доступ, задайте новый `ADMIN_SESSION_SECRET`, включите `BLOOM_COOKIE_SECURE=true` и подключите корпоративную авторизацию/allowlist.

## Где менять данные

- бренд, телефон, доставка и валюта: `lib/config.ts`;
- товары, цены, размеры, изображения и дополнения: `data/products.ts`;
- реляционная схема заказов, товаров, клиентов и доставки: `db/schema.ts`;
- checkout и storefront: `components/shop/shop-app.tsx`;
- заказы и статусы: D1-таблицы `orders` и `order_status_history`, API `app/api/orders/route.ts`;
- административные экраны: `components/admin/admin-dashboard.tsx`.

После изменения `db/schema.ts` выполните `npm run db:generate` и сохраните созданную миграцию.

## Интеграции

Сейчас в безопасном development-режиме работают mock-адаптеры:

- `PaymentProvider` — оплата без передачи данных карты;
- `NotificationProvider` — SMS, email и Telegram;
- `MapProvider` — подсказки адреса без внешнего API;
- analytics abstraction — события e-commerce.

Интерфейсы находятся в `lib/providers.ts`. Чтобы подключить production-эквайринг, создайте реализацию `PaymentProvider`, передавайте на сервер только идентификатор платёжной сессии провайдера, храните ключ в `PAYMENT_API_KEY` и обрабатывайте подтверждение через подписанный webhook. Данные банковских карт в BLOOM не сохраняются.

## Переменные окружения

Полный список находится в `.env.example`. Критичные значения:

- `ADMIN_SESSION_SECRET`;
- `DEMO_ADMIN_EMAIL` / `DEMO_ADMIN_PASSWORD` — только development;
- `PAYMENT_PROVIDER` / `PAYMENT_API_KEY`;
- `MAPS_API_KEY`;
- ключи SMS, email и Telegram.

## Безопасность

Заказы валидируются на сервере через Zod. Tracking использует случайный токен, а не последовательный номер. Административный API проверяет подписанную HttpOnly/SameSite cookie. Платёжные реквизиты не проходят через приложение. Для production необходимо дополнительно настроить rate limiting на edge, реальный эквайринг, проверенные юридические документы и политику доступа сотрудников.
