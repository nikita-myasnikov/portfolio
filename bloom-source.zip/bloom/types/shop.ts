export type ProductSize = "S" | "M" | "L";

export type Product = {
  id: string;
  slug: string;
  name: string;
  composition: string;
  description: string;
  category: "Букеты" | "Розы" | "Монобукеты" | "Композиции";
  flower: string;
  color: string;
  occasions: string[];
  image: string;
  accent: string;
  rating: number;
  reviews: number;
  today: boolean;
  new?: boolean;
  bestseller?: boolean;
  sizes: Record<ProductSize, { price: number; diameter: number; stems: number }>;
};

export type CartItem = {
  lineId: string;
  productId: string;
  size: ProductSize;
  quantity: number;
  cardText: string;
  unsignedCard: boolean;
  anonymous: boolean;
  surprise: boolean;
  surpriseMode: string;
  photoBeforeDelivery: boolean;
  addons: string[];
};

export type OrderStatus = "accepted" | "paid" | "assembling" | "ready" | "courier" | "on_the_way" | "delivered";

export type OrderPayload = {
  buyerName: string;
  buyerPhone: string;
  buyerEmail?: string;
  recipientName: string;
  recipientPhone: string;
  address: string;
  deliveryDate: string;
  deliveryTime: string;
  paymentMethod: string;
  anonymous: boolean;
  surprise: boolean;
  photoBeforeDelivery: boolean;
  comment?: string;
  subtotal: number;
  deliveryFee: number;
  total: number;
  items: Array<{ productId: string; name: string; size: ProductSize; quantity: number; price: number; cardText: string; addons: string[]; image: string }>;
};

export type OrderRecord = OrderPayload & {
  id: string;
  publicNumber: string;
  trackingToken: string;
  paymentStatus: string;
  status: OrderStatus;
  createdAt: string;
  history?: Array<{ status: OrderStatus; note: string; createdAt: string }>;
};
