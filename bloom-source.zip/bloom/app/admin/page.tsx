import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { AdminDashboard } from "@/components/admin/admin-dashboard";
import { verifyAdminToken } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const cookieStore = await cookies();
  if (!(await verifyAdminToken(cookieStore.get("bloom_admin")?.value))) redirect("/admin-login");
  return <AdminDashboard />;
}
