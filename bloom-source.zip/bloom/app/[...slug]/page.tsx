import { ShopApp } from "@/components/shop/shop-app";

export default async function CatchAllPage({ params }: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await params;
  return <ShopApp segments={slug} />;
}
