import { adminCookieHeader, adminCredentialsMatch, createAdminToken } from "@/lib/admin-auth";

export async function POST(request: Request) {
  const payload = await request.json().catch(() => ({})) as { email?: string; password?: string };
  if (!payload.email || !payload.password || !adminCredentialsMatch(payload.email, payload.password)) {
    return Response.json({ error: "Неверный email или пароль" }, { status: 401 });
  }
  const token = await createAdminToken();
  return Response.json({ ok: true }, { headers: { "Set-Cookie": adminCookieHeader(token) } });
}
