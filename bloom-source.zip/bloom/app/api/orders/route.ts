import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { getDb } from "@/db";
import { orders, orderStatusHistory } from "@/db/schema";
import { getAdminCookie, verifyAdminToken } from "@/lib/admin-auth";

const requestWindows = new Map<string, { count: number; resetAt: number }>();

function rateLimited(request: Request) {
  const key = request.headers.get("cf-connecting-ip") ?? request.headers.get("x-forwarded-for") ?? "local";
  const now = Date.now();
  const current = requestWindows.get(key);
  if (!current || current.resetAt < now) {
    requestWindows.set(key, { count: 1, resetAt: now + 60_000 });
    return false;
  }
  current.count += 1;
  return current.count > 10;
}

const orderSchema = z.object({
  buyerName: z.string().trim().min(2).max(80),
  buyerPhone: z.string().regex(/^\+375\s?\d{2}\s?\d{3}[-\s]?\d{2}[-\s]?\d{2}$/),
  buyerEmail: z.string().email().optional().or(z.literal("")),
  recipientName: z.string().trim().min(2).max(80),
  recipientPhone: z.string().regex(/^\+375\s?\d{2}\s?\d{3}[-\s]?\d{2}[-\s]?\d{2}$/),
  address: z.string().trim().min(5).max(240),
  deliveryDate: z.string().min(4).max(40),
  deliveryTime: z.string().min(4).max(40),
  paymentMethod: z.string().min(2).max(50),
  anonymous: z.boolean(), surprise: z.boolean(), photoBeforeDelivery: z.boolean(),
  comment: z.string().max(500).optional(),
  subtotal: z.number().nonnegative(), deliveryFee: z.number().nonnegative(), total: z.number().positive(),
  items: z.array(z.object({
    productId: z.string(), name: z.string(), size: z.enum(["S", "M", "L"]), quantity: z.number().int().positive(),
    price: z.number().positive(), cardText: z.string().max(300), addons: z.array(z.string()), image: z.string().url(),
  })).min(1).max(25),
});

function mapOrder(row: typeof orders.$inferSelect, history: Array<typeof orderStatusHistory.$inferSelect> = []) {
  return { ...row, items: JSON.parse(row.itemsJson), history };
}

export async function POST(request: Request) {
  if (rateLimited(request)) return Response.json({ error: "Слишком много попыток. Подождите минуту и попробуйте снова." }, { status: 429 });
  const parsed = orderSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Проверьте данные получателя и доставки", fields: parsed.error.flatten().fieldErrors }, { status: 400 });
  const input = parsed.data;
  const id = crypto.randomUUID();
  const trackingToken = `${crypto.randomUUID().replaceAll("-", "")}${crypto.randomUUID().replaceAll("-", "")}`;
  const publicNumber = `BL-${Math.floor(10000 + Math.random() * 89999)}`;
  const db = getDb();
  await db.batch([
    db.insert(orders).values({
      id, publicNumber, trackingToken, buyerName: input.buyerName, buyerPhone: input.buyerPhone,
      buyerEmail: input.buyerEmail ?? "", recipientName: input.recipientName, recipientPhone: input.recipientPhone,
      address: input.address, deliveryDate: input.deliveryDate, deliveryTime: input.deliveryTime,
      paymentMethod: input.paymentMethod, paymentStatus: input.paymentMethod === "card" ? "paid" : "pending",
      status: "accepted", anonymous: input.anonymous, surprise: input.surprise, photoBeforeDelivery: input.photoBeforeDelivery,
      subtotal: input.subtotal, deliveryFee: input.deliveryFee, total: input.total, comment: input.comment ?? "", itemsJson: JSON.stringify(input.items),
    }),
    db.insert(orderStatusHistory).values({ id: crypto.randomUUID(), orderId: id, status: "accepted", note: "Заказ принят и передан команде BLOOM" }),
  ]);
  const [created] = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return Response.json({ order: mapOrder(created) }, { status: 201 });
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const token = url.searchParams.get("token");
  const db = getDb();
  if (token) {
    const [order] = await db.select().from(orders).where(eq(orders.trackingToken, token)).limit(1);
    if (!order) return Response.json({ error: "Заказ не найден" }, { status: 404 });
    const history = await db.select().from(orderStatusHistory).where(eq(orderStatusHistory.orderId, order.id)).orderBy(orderStatusHistory.createdAt);
    return Response.json({ order: mapOrder(order, history) });
  }
  if (!(await verifyAdminToken(getAdminCookie(request)))) return Response.json({ error: "Нет доступа" }, { status: 401 });
  const rows = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(100);
  return Response.json({ orders: rows.map((row) => mapOrder(row)) });
}

export async function PATCH(request: Request) {
  if (!(await verifyAdminToken(getAdminCookie(request)))) return Response.json({ error: "Нет доступа" }, { status: 401 });
  const payload = await request.json().catch(() => ({})) as { id?: string; status?: string };
  const allowed = ["accepted", "paid", "assembling", "ready", "courier", "on_the_way", "delivered"];
  if (!payload.id || !payload.status || !allowed.includes(payload.status)) return Response.json({ error: "Некорректный статус" }, { status: 400 });
  const db = getDb();
  await db.batch([
    db.update(orders).set({ status: payload.status, updatedAt: new Date().toISOString() }).where(eq(orders.id, payload.id)),
    db.insert(orderStatusHistory).values({ id: crypto.randomUUID(), orderId: payload.id, status: payload.status, note: "Статус обновлён командой BLOOM" }),
  ]);
  return Response.json({ ok: true });
}
