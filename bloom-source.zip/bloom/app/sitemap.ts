import type { MetadataRoute } from "next";
import { products } from "@/data/products";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://bloom.example";
  const staticRoutes = ["", "/catalog", "/about", "/delivery", "/contacts", "/faq", "/reviews", "/privacy", "/offer"];
  return [
    ...staticRoutes.map((route) => ({ url: `${base}${route}`, lastModified: new Date(), changeFrequency: "weekly" as const })),
    ...products.map((product) => ({ url: `${base}/product/${product.slug}`, lastModified: new Date(), changeFrequency: "daily" as const })),
  ];
}
