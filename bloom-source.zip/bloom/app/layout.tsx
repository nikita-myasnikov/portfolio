import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://bloom.example"),
  title: { default: "BLOOM — доставка цветов в Минске", template: "%s | BLOOM" },
  description: "Свежие букеты с доставкой по Минску. Соберём, покажем перед отправкой и привезём точно ко времени.",
  alternates: { canonical: "/" },
  openGraph: {
    title: "BLOOM — цветы, которые говорят за вас",
    description: "Выберите букет, дату и время доставки за пару минут.",
    locale: "ru_BY",
    type: "website",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <body className="antialiased">
        {children}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "BLOOM",
              description: "Доставка свежих цветов и букетов по Минску",
              telephone: "+375297007070",
              email: "hello@bloom.by",
              address: { "@type": "PostalAddress", addressLocality: "Минск", addressCountry: "BY" },
            }),
          }}
        />
      </body>
    </html>
  );
}
