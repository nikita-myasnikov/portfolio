import { env } from "cloudflare:workers";

const encoder = new TextEncoder();
const cookieName = "bloom_admin";

function runtimeValue(key: string) {
  return (env as unknown as Record<string, string | undefined>)[key];
}

function toBase64Url(bytes: Uint8Array) {
  let binary = "";
  bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function sign(value: string) {
  const secret = runtimeValue("ADMIN_SESSION_SECRET") ?? "development-only-change-me";
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return toBase64Url(new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(value))));
}

export async function createAdminToken() {
  const expires = Date.now() + 1000 * 60 * 60 * 8;
  const payload = `admin.${expires}`;
  return `${payload}.${await sign(payload)}`;
}

export async function verifyAdminToken(token?: string | null) {
  if (!token) return false;
  const [role, expires, signature] = token.split(".");
  if (role !== "admin" || !expires || !signature || Number(expires) < Date.now()) return false;
  const expected = await sign(`${role}.${expires}`);
  if (expected.length !== signature.length) return false;
  let mismatch = 0;
  for (let i = 0; i < expected.length; i += 1) mismatch |= expected.charCodeAt(i) ^ signature.charCodeAt(i);
  return mismatch === 0;
}

export function getAdminCookie(request: Request) {
  const cookies = request.headers.get("cookie") ?? "";
  const match = cookies.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${cookieName}=`));
  return match?.slice(cookieName.length + 1) ?? null;
}

export function adminCookieHeader(token: string) {
  const secure = runtimeValue("BLOOM_COOKIE_SECURE") === "true" ? "; Secure" : "";
  return `${cookieName}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800${secure}`;
}

export function adminCredentialsMatch(email: string, password: string) {
  const enabled = runtimeValue("BLOOM_DEMO_ADMIN_ENABLED") === "true";
  if (!enabled) return false;
  return email === runtimeValue("DEMO_ADMIN_EMAIL") && password === runtimeValue("DEMO_ADMIN_PASSWORD");
}
