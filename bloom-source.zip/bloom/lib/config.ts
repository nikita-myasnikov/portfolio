export const STORE_CONFIG = {
  name: "BLOOM",
  tagline: "Цветы, которые говорят за вас",
  city: "Минск",
  phone: "+375 29 700-70-70",
  email: "hello@bloom.by",
  deliveryFee: 10,
  freeDeliveryFrom: 180,
  currency: "BYN",
} as const;
