export interface PaymentProvider {
  createPayment(orderId: string, amount: number): Promise<{ status: "paid" | "pending"; reference: string }>;
}

export const mockPaymentProvider: PaymentProvider = {
  async createPayment(orderId, amount) {
    await new Promise((resolve) => setTimeout(resolve, 350));
    return { status: "paid", reference: `mock_${orderId}_${Math.round(amount * 100)}` };
  },
};

export interface MapProvider {
  suggest(query: string): Promise<string[]>;
}

export const fallbackMapProvider: MapProvider = {
  async suggest(query) {
    if (query.trim().length < 3) return [];
    return [`Минск, ${query}`, `Минск, ${query}, 12`, `Минск, ${query}, 24`];
  },
};

export interface NotificationProvider {
  send(event: string, destination: string): Promise<void>;
}

export const mockNotificationProvider: NotificationProvider = {
  async send() {
    await Promise.resolve();
  },
};

export type AnalyticsEvent =
  | "view_product" | "select_variant" | "add_to_cart" | "remove_from_cart"
  | "begin_checkout" | "add_delivery_info" | "add_payment_info" | "purchase"
  | "search" | "favorite" | "custom_bouquet_request";

export const analytics = {
  track(event: AnalyticsEvent, payload: Record<string, unknown> = {}) {
    if (typeof window !== "undefined" && process.env.NODE_ENV !== "production") {
      console.info("[BLOOM analytics]", event, payload);
    }
  },
};
