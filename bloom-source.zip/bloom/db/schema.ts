import { sql } from "drizzle-orm";
import { index, integer, real, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

const timestamps = {
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
};

export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  email: text("email").notNull(),
  role: text("role", { enum: ["customer", "admin", "florist", "courier"] }).notNull().default("customer"),
  ...timestamps,
}, (table) => [uniqueIndex("users_email_uq").on(table.email)]);

export const profiles = sqliteTable("profiles", {
  userId: text("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull().default(""),
  phone: text("phone").notNull().default(""),
  ...timestamps,
});

export const addresses = sqliteTable("addresses", {
  id: text("id").primaryKey(),
  userId: text("user_id").references(() => users.id, { onDelete: "cascade" }),
  label: text("label").notNull().default("Дом"),
  city: text("city").notNull(),
  street: text("street").notNull(),
  house: text("house").notNull(),
  details: text("details").notNull().default(""),
  ...timestamps,
}, (table) => [index("addresses_user_idx").on(table.userId)]);

export const recipients = sqliteTable("recipients", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  birthDate: text("birth_date"),
  addressId: text("address_id").references(() => addresses.id, { onDelete: "set null" }),
  reminderDays: integer("reminder_days").notNull().default(0),
  ...timestamps,
}, (table) => [index("recipients_user_idx").on(table.userId)]);

export const categories = sqliteTable("categories", {
  id: text("id").primaryKey(),
  slug: text("slug").notNull(),
  name: text("name").notNull(),
  ...timestamps,
}, (table) => [uniqueIndex("categories_slug_uq").on(table.slug)]);

export const products = sqliteTable("products", {
  id: text("id").primaryKey(),
  slug: text("slug").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  stockStatus: text("stock_status").notNull().default("available"),
  availabilityDate: text("availability_date"),
  ...timestamps,
}, (table) => [uniqueIndex("products_slug_uq").on(table.slug), index("products_active_idx").on(table.active)]);

export const productVariants = sqliteTable("product_variants", {
  id: text("id").primaryKey(),
  productId: text("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
  size: text("size").notNull(),
  price: real("price").notNull(),
  diameterCm: integer("diameter_cm").notNull(),
  composition: text("composition").notNull(),
  available: integer("available", { mode: "boolean" }).notNull().default(true),
  ...timestamps,
}, (table) => [index("variants_product_idx").on(table.productId)]);

export const productCategories = sqliteTable("product_categories", {
  productId: text("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
  categoryId: text("category_id").notNull().references(() => categories.id, { onDelete: "cascade" }),
});

export const productImages = sqliteTable("product_images", {
  id: text("id").primaryKey(),
  productId: text("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
  url: text("url").notNull(),
  alt: text("alt").notNull(),
  position: integer("position").notNull().default(0),
});

export const flowers = sqliteTable("flowers", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  seasonal: integer("seasonal", { mode: "boolean" }).notNull().default(false),
  ...timestamps,
});

export const productFlowers = sqliteTable("product_flowers", {
  productId: text("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
  flowerId: text("flower_id").notNull().references(() => flowers.id, { onDelete: "restrict" }),
  approximateQuantity: integer("approximate_quantity"),
});

export const addons = sqliteTable("addons", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  price: real("price").notNull(),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  ...timestamps,
});

export const favorites = sqliteTable("favorites", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  productId: text("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [uniqueIndex("favorites_user_product_uq").on(table.userId, table.productId)]);

export const carts = sqliteTable("carts", {
  id: text("id").primaryKey(),
  userId: text("user_id").references(() => users.id, { onDelete: "set null" }),
  sessionId: text("session_id"),
  ...timestamps,
});

export const cartItems = sqliteTable("cart_items", {
  id: text("id").primaryKey(),
  cartId: text("cart_id").notNull().references(() => carts.id, { onDelete: "cascade" }),
  variantId: text("variant_id").notNull().references(() => productVariants.id, { onDelete: "cascade" }),
  quantity: integer("quantity").notNull().default(1),
  optionsJson: text("options_json").notNull().default("{}"),
  ...timestamps,
});

export const orders = sqliteTable("orders", {
  id: text("id").primaryKey(),
  publicNumber: text("public_number").notNull(),
  trackingToken: text("tracking_token").notNull(),
  buyerName: text("buyer_name").notNull(),
  buyerPhone: text("buyer_phone").notNull(),
  buyerEmail: text("buyer_email").notNull().default(""),
  recipientName: text("recipient_name").notNull(),
  recipientPhone: text("recipient_phone").notNull(),
  address: text("address").notNull(),
  deliveryDate: text("delivery_date").notNull(),
  deliveryTime: text("delivery_time").notNull(),
  paymentMethod: text("payment_method").notNull(),
  paymentStatus: text("payment_status").notNull().default("pending"),
  status: text("status").notNull().default("accepted"),
  anonymous: integer("anonymous", { mode: "boolean" }).notNull().default(false),
  surprise: integer("surprise", { mode: "boolean" }).notNull().default(false),
  photoBeforeDelivery: integer("photo_before_delivery", { mode: "boolean" }).notNull().default(true),
  subtotal: real("subtotal").notNull(),
  deliveryFee: real("delivery_fee").notNull().default(0),
  total: real("total").notNull(),
  comment: text("comment").notNull().default(""),
  itemsJson: text("items_json").notNull(),
  ...timestamps,
}, (table) => [uniqueIndex("orders_public_number_uq").on(table.publicNumber), uniqueIndex("orders_tracking_token_uq").on(table.trackingToken), index("orders_status_idx").on(table.status), index("orders_created_idx").on(table.createdAt)]);

export const orderItems = sqliteTable("order_items", {
  id: text("id").primaryKey(),
  orderId: text("order_id").notNull().references(() => orders.id, { onDelete: "cascade" }),
  productId: text("product_id").references(() => products.id, { onDelete: "set null" }),
  variantLabel: text("variant_label").notNull(),
  nameSnapshot: text("name_snapshot").notNull(),
  priceSnapshot: real("price_snapshot").notNull(),
  quantity: integer("quantity").notNull(),
  cardText: text("card_text").notNull().default(""),
});

export const orderAddons = sqliteTable("order_addons", {
  id: text("id").primaryKey(),
  orderItemId: text("order_item_id").notNull().references(() => orderItems.id, { onDelete: "cascade" }),
  addonId: text("addon_id").references(() => addons.id, { onDelete: "set null" }),
  nameSnapshot: text("name_snapshot").notNull(),
  priceSnapshot: real("price_snapshot").notNull(),
});

export const payments = sqliteTable("payments", {
  id: text("id").primaryKey(),
  orderId: text("order_id").notNull().references(() => orders.id, { onDelete: "cascade" }),
  provider: text("provider").notNull(),
  providerReference: text("provider_reference"),
  amount: real("amount").notNull(),
  status: text("status").notNull(),
  ...timestamps,
});

export const deliveryZones = sqliteTable("delivery_zones", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  basePrice: real("base_price").notNull(),
  freeFrom: real("free_from"),
  urgentEnabled: integer("urgent_enabled", { mode: "boolean" }).notNull().default(false),
  slotsJson: text("slots_json").notNull().default("[]"),
  ...timestamps,
});

export const branches = sqliteTable("branches", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  hours: text("hours").notNull(),
  ...timestamps,
});

export const deliveries = sqliteTable("deliveries", {
  id: text("id").primaryKey(),
  orderId: text("order_id").notNull().references(() => orders.id, { onDelete: "cascade" }),
  zoneId: text("zone_id").references(() => deliveryZones.id, { onDelete: "set null" }),
  branchId: text("branch_id").references(() => branches.id, { onDelete: "set null" }),
  courierUserId: text("courier_user_id").references(() => users.id, { onDelete: "set null" }),
  type: text("type").notNull().default("courier"),
  status: text("status").notNull().default("scheduled"),
  exactTime: text("exact_time"),
  ...timestamps,
});

export const reviews = sqliteTable("reviews", {
  id: text("id").primaryKey(),
  orderId: text("order_id").references(() => orders.id, { onDelete: "set null" }),
  productId: text("product_id").references(() => products.id, { onDelete: "set null" }),
  rating: integer("rating").notNull(),
  text: text("text").notNull(),
  photoUrl: text("photo_url"),
  status: text("status").notNull().default("pending"),
  ...timestamps,
});

export const promoCodes = sqliteTable("promo_codes", {
  id: text("id").primaryKey(),
  code: text("code").notNull(),
  type: text("type").notNull(),
  value: real("value").notNull(),
  minOrder: real("min_order").notNull().default(0),
  startsAt: text("starts_at"),
  endsAt: text("ends_at"),
  usageLimit: integer("usage_limit"),
  usageCount: integer("usage_count").notNull().default(0),
  ...timestamps,
}, (table) => [uniqueIndex("promo_codes_code_uq").on(table.code)]);

export const notifications = sqliteTable("notifications", {
  id: text("id").primaryKey(),
  orderId: text("order_id").references(() => orders.id, { onDelete: "cascade" }),
  channel: text("channel").notNull(),
  event: text("event").notNull(),
  destinationMasked: text("destination_masked").notNull(),
  status: text("status").notNull().default("queued"),
  ...timestamps,
});

export const customBouquetRequests = sqliteTable("custom_bouquet_requests", {
  id: text("id").primaryKey(),
  budget: real("budget").notNull(),
  recipient: text("recipient").notNull(),
  occasion: text("occasion").notNull(),
  palette: text("palette").notNull(),
  likedFlowers: text("liked_flowers").notNull().default(""),
  excludedFlowers: text("excluded_flowers").notNull().default(""),
  style: text("style").notNull(),
  comment: text("comment").notNull().default(""),
  status: text("status").notNull().default("new"),
  ...timestamps,
});

export const orderStatusHistory = sqliteTable("order_status_history", {
  id: text("id").primaryKey(),
  orderId: text("order_id").notNull().references(() => orders.id, { onDelete: "cascade" }),
  status: text("status").notNull(),
  note: text("note").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [index("status_history_order_idx").on(table.orderId)]);
