// ---------- CANVAS MODULE ----------
import {
    state,
    pushUndo,
    pushUndoSnapshot,
    snapshotLayers
} from "./state.js";

// ---------- SELECTION / DRAGGING STATE ----------
let draggingObject = null;
let selectedObject = null;
let offsetX = 0;
let offsetY = 0;

// Состояние свободного рисования
let freeDrawing = false;
let freePoints = [];

// Hover / курсор / анимация
let hoveredObject = null;
let animationFrameId = null;
let pulsePhase = 0;

// ---------- EVENT BUS ----------
const eventBus = new EventTarget();

export function onObjectSelected(callback) {
    eventBus.addEventListener("objectselected", (e) => callback(e.detail));
}

function emitSelection() {
    eventBus.dispatchEvent(
        new CustomEvent("objectselected", { detail: selectedObject })
    );
}

// ---------- SELECTION API ----------
export function getSelectedObject() {
    return selectedObject;
}

export function clearSelection() {
    selectedObject = null;
    redraw();
    emitSelection();
}

export function updateSelectedObject(props, skipUndo = false) {
    if (!selectedObject) return false;
    if (!skipUndo) pushUndo();

    Object.assign(selectedObject, props);
    redraw();
    return true;
}

// ---------- RESIZE CANVAS ----------
export function resizeCanvas() {
    const canvas = document.getElementById("canvas");
    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;
    redraw();
}

// ---------- CLEAR CANVAS ----------
export function clearCanvas() {
    const canvas = document.getElementById("canvas");
    const ctx = canvas.getContext("2d");

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

// ---------- REDRAW ALL LAYERS ----------
export function redraw() {
    clearCanvas();
    const canvas = document.getElementById("canvas");
    const ctx = canvas.getContext("2d");

    for (const layer of state.layers) {
        if (!layer.visible) continue;

        for (const obj of layer.objects) {
            drawObject(ctx, obj);
        }
    }

    if (selectedObject) {
        highlightObject(ctx, selectedObject);
    }
}

// ---------- DRAW OBJECT ----------
function drawObject(ctx, obj) {
    ctx.save();

    ctx.lineWidth = obj.lineWidth ?? 2;
    ctx.strokeStyle = obj.strokeColor ?? "#000";
    ctx.fillStyle = obj.fillColor ?? "#1976d2";
    ctx.setLineDash(obj.lineType === "dash" ? [10, 5] : []);

    switch (obj.type) {
        case "rect":
            ctx.fillRect(obj.x, obj.y, obj.size, obj.size);
            ctx.strokeRect(obj.x, obj.y, obj.size, obj.size);
            break;

        case "ellipse":
            ctx.beginPath();
            ctx.ellipse(
                obj.x + obj.size / 2,
                obj.y + obj.size / 2,
                obj.size / 2,
                obj.size / 3,
                0,
                0,
                Math.PI * 2
            );
            ctx.fill();
            ctx.stroke();
            break;

        case "line":
            ctx.beginPath();
            ctx.moveTo(obj.x, obj.y);
            ctx.lineTo(obj.x + obj.size, obj.y + obj.size);
            ctx.stroke();
            break;

        case "text":
            ctx.font = "24px Segoe UI";
            ctx.fillStyle = obj.fillColor ?? "#000";
            ctx.fillText(obj.text || "Текст", obj.x, obj.y);
            break;

        case "gradient": {
            const grad = ctx.createLinearGradient(
                obj.x, obj.y,
                obj.x + obj.size, obj.y
            );
            grad.addColorStop(0, obj.fillColor);
            grad.addColorStop(1, obj.strokeColor);
            ctx.fillStyle = grad;
            ctx.fillRect(obj.x, obj.y, obj.size * 1.5, obj.size);
            break;
        }

        case "pattern": {
            const pattern = getPattern(ctx);
            ctx.fillStyle = pattern;
            ctx.fillRect(obj.x, obj.y, obj.size * 2, obj.size * 1.5);
            break;
        }

        case "matrix":
            ctx.translate(obj.x, obj.y);
            ctx.rotate(0.2);
            ctx.scale(1.2, 0.8);
            ctx.fillRect(0, 0, obj.size, obj.size);
            ctx.strokeRect(0, 0, obj.size, obj.size);
            break;

        case "shear":
            ctx.transform(1, 0, 0.5, 1, obj.x, obj.y);
            ctx.fillRect(0, 0, obj.size, obj.size);
            ctx.strokeRect(0, 0, obj.size, obj.size);
            break;

        case "perspective":
            ctx.transform(1, 0.3, 0, 1, obj.x, obj.y);
            ctx.fillRect(0, 0, obj.size * 2, obj.size);
            ctx.strokeRect(0, 0, obj.size * 2, obj.size);
            break;

        case "free":
            if (!obj.points || obj.points.length < 2) break;
            ctx.beginPath();
            ctx.moveTo(obj.points[0].x, obj.points[0].y);
            for (let i = 1; i < obj.points.length; i++) {
                ctx.lineTo(obj.points[i].x, obj.points[i].y);
            }
            ctx.stroke();
            break;

        case "image":
            if (obj.img && obj.img.complete) {
                ctx.drawImage(obj.img, obj.x, obj.y, obj.size * 2, obj.size * 1.5);
            }
            break;
    }

    ctx.restore();
}

// ---------- PATTERN ----------
let cachedPatternCanvas = null;
function getPattern(ctx) {
    if (cachedPatternCanvas) return ctx.createPattern(cachedPatternCanvas, "repeat");

    const size = 20;
    const c = document.createElement("canvas");
    c.width = size;
    c.height = size;
    const cctx = c.getContext("2d");

    cctx.fillStyle = "#ffffff";
    cctx.fillRect(0, 0, size, size);
    cctx.fillStyle = "#1976d2";
    cctx.beginPath();
    cctx.arc(size / 2, size / 2, size / 4, 0, Math.PI * 2);
    cctx.fill();

    cachedPatternCanvas = c;
    return ctx.createPattern(c, "repeat");
}

// ---------- ADD OBJECT TO ACTIVE LAYER ----------
export function addObjectToLayer() {
    const canvas = document.getElementById("canvas");

    const obj = {
        type: state.method,
        x: canvas.width / 2 - state.shapeSize / 2,
        y: canvas.height / 2 - state.shapeSize / 2,
        size: state.shapeSize,
        fillColor: state.fillColor,
        strokeColor: state.strokeColor,
        lineWidth: state.lineWidth,
        lineType: state.lineType
    };

    if (state.method === "text") {
        obj.text = "Текст";
    }

    if (state.method === "image" || state.method === "free") {
        return;
    }

    pushUndo();
    state.layers[state.activeLayer].objects.push(obj);
    redraw();
}

// ---------- ADD IMAGE OBJECT ----------
export function addImageObject(img) {
    const canvas = document.getElementById("canvas");
    const obj = {
        type: "image",
        img: img,
        x: canvas.width / 2 - state.shapeSize,
        y: canvas.height / 2 - state.shapeSize * 0.75,
        size: state.shapeSize,
        lineWidth: state.lineWidth,
        strokeColor: state.strokeColor,
        fillColor: state.fillColor,
        lineType: state.lineType
    };

    pushUndo();
    state.layers[state.activeLayer].objects.push(obj);
    redraw();
}

// ---------- FREE DRAWING ----------
export function startFreeDraw() {
    freeDrawing = true;
    freePoints = [];
}

export function addFreePoint(x, y) {
    if (!freeDrawing) return;
    freePoints.push({ x, y });
    redraw();

    const canvas = document.getElementById("canvas");
    const ctx = canvas.getContext("2d");
    if (freePoints.length >= 2) {
        ctx.save();
        ctx.lineWidth = state.lineWidth;
        ctx.strokeStyle = state.strokeColor;
        ctx.setLineDash(state.lineType === "dash" ? [10, 5] : []);
        ctx.beginPath();
        ctx.moveTo(freePoints[0].x, freePoints[0].y);
        for (let i = 1; i < freePoints.length; i++) {
            ctx.lineTo(freePoints[i].x, freePoints[i].y);
        }
        ctx.stroke();
        ctx.restore();
    }
}

export function finishFreeDraw() {
    if (!freeDrawing) return;
    freeDrawing = false;

    if (freePoints.length >= 2) {
        pushUndo();
        state.layers[state.activeLayer].objects.push({
            type: "free",
            points: freePoints.slice(),
            lineWidth: state.lineWidth,
            strokeColor: state.strokeColor,
            fillColor: state.fillColor,
            lineType: state.lineType
        });
    }
    freePoints = [];
    redraw();
}

// ---------- EFFECTS ----------
function applyPixelEffect(transform) {
    const canvas = document.getElementById("canvas");
    const ctx = canvas.getContext("2d");
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const d = imgData.data;

    for (let i = 0; i < d.length; i += 4) {
        const [r, g, b] = transform(d[i], d[i + 1], d[i + 2]);
        d[i] = r;
        d[i + 1] = g;
        d[i + 2] = b;
    }
    ctx.putImageData(imgData, 0, 0);
}

export function effectGrayscale() {
    applyPixelEffect((r, g, b) => {
        const avg = Math.round(0.299 * r + 0.587 * g + 0.114 * b);
        return [avg, avg, avg];
    });
}

export function effectInvert() {
    applyPixelEffect((r, g, b) => [255 - r, 255 - g, 255 - b]);
}

export function effectBright() {
    const delta = 40;
    applyPixelEffect((r, g, b) => [
        Math.min(255, r + delta),
        Math.min(255, g + delta),
        Math.min(255, b + delta)
    ]);
}

// ---------- HIT TEST ----------
function isPointInObject(ctx, obj, x, y) {
    if (obj.type === "line") {
        return distanceToSegment(
            x, y,
            obj.x, obj.y,
            obj.x + obj.size, obj.y + obj.size
        ) <= 6;
    }

    if (obj.type === "free" && obj.points) {
        for (let i = 1; i < obj.points.length; i++) {
            if (distanceToSegment(
                x, y,
                obj.points[i - 1].x, obj.points[i - 1].y,
                obj.points[i].x, obj.points[i].y
            ) <= 6) return true;
        }
        return false;
    }

    ctx.save();
    ctx.beginPath();

    switch (obj.type) {
        case "rect":
            ctx.rect(obj.x, obj.y, obj.size, obj.size);
            break;
        case "ellipse":
            ctx.ellipse(
                obj.x + obj.size / 2,
                obj.y + obj.size / 2,
                obj.size / 2,
                obj.size / 3,
                0,
                0,
                Math.PI * 2
            );
            break;
        case "text":
            ctx.rect(obj.x, obj.y - 24, obj.size * 2, 30);
            break;
        case "image":
            ctx.rect(obj.x, obj.y, obj.size * 2, obj.size * 1.5);
            break;
        default:
            ctx.rect(obj.x, obj.y, obj.size, obj.size);
            break;
    }

    const hit = ctx.isPointInPath(x, y);
    ctx.restore();
    return hit;
}

function distanceToSegment(px, py, x1, y1, x2, y2) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const len2 = dx * dx + dy * dy;
    if (len2 === 0) return Math.hypot(px - x1, py - y1);

    let t = ((px - x1) * dx + (py - y1) * dy) / len2;
    t = Math.max(0, Math.min(1, t));

    const cx = x1 + t * dx;
    const cy = y1 + t * dy;
    return Math.hypot(px - cx, py - cy);
}

// ---------- OBJECT TOOLTIP ----------
function formatObjectTitle(obj) {
    const typeNames = {
        rect: "Прямоугольник",
        ellipse: "Эллипс",
        line: "Линия",
        text: "Текст",
        gradient: "Градиент",
        pattern: "Паттерн",
        matrix: "Матрица",
        shear: "Скос",
        perspective: "Перспектива",
        free: "Свободное рисование",
        image: "Изображение"
    };
    const name = typeNames[obj.type] || obj.type;
    if (obj.size != null && obj.type !== "image" && obj.type !== "free") {
        return `${name} • размер: ${obj.size}`;
    }
    return name;
}

// ---------- DRAGGING + DELETE + EDIT ----------
export function enableDragging() {
    const canvas = document.getElementById("canvas");
    const ctx = canvas.getContext("2d");

    // Запускаем анимацию пульсации рамки выделения
    startPulseAnimation();

    let snapshotBeforeDrag = null;
    let dragMoved = false;

    canvas.addEventListener("mousedown", (e) => {
        const rect = canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        if (state.method === "free") {
            startFreeDraw();
            addFreePoint(x, y);
            return;
        }

        const previousSelected = selectedObject;
        selectedObject = null;
        dragMoved = false;

        const objects = state.layers[state.activeLayer].objects;
        for (let i = objects.length - 1; i >= 0; i--) {
            const obj = objects[i];
            if (isPointInObject(ctx, obj, x, y)) {
                draggingObject = obj;
                selectedObject = obj;
                offsetX = x - obj.x;
                offsetY = y - obj.y;
                snapshotBeforeDrag = snapshotLayers();
                canvas.style.cursor = "grabbing";
                break;
            }
        }

        redraw();

        if (selectedObject !== previousSelected) {
            emitSelection();
        }
    });

    canvas.addEventListener("mousemove", (e) => {
        const rect = canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        // Обновление координат мыши
        const coordsEl = document.getElementById("canvasCoords");
        if (coordsEl) {
            coordsEl.textContent = `x: ${Math.round(x)}  y: ${Math.round(y)}`;
        }

        // Свободное рисование
        if (state.method === "free" && freeDrawing) {
            addFreePoint(x, y);
            return;
        }

        // Перетаскивание
        if (draggingObject) {
            const newX = x - offsetX;
            const newY = y - offsetY;

            if (newX !== draggingObject.x || newY !== draggingObject.y) {
                dragMoved = true;
            }

            draggingObject.x = newX;
            draggingObject.y = newY;

            redraw();
            return;
        }

        // Hover-подсказка и курсор
        if (state.method !== "free") {
            let hit = null;
            const objects = state.layers[state.activeLayer].objects;
            for (let i = objects.length - 1; i >= 0; i--) {
                if (isPointInObject(ctx, objects[i], x, y)) {
                    hit = objects[i];
                    break;
                }
            }

            if (hit !== hoveredObject) {
                hoveredObject = hit;
                canvas.style.cursor = hit ? "move" : "crosshair";
                canvas.title = hit ? formatObjectTitle(hit) : "";
            }
        } else {
            canvas.style.cursor = "crosshair";
            canvas.title = "";
        }
    });

    canvas.addEventListener("mouseup", () => {
        if (state.method === "free" && freeDrawing) {
            finishFreeDraw();
            return;
        }

        if (draggingObject && dragMoved && snapshotBeforeDrag) {
            pushUndoSnapshot(snapshotBeforeDrag);
        }

        draggingObject = null;
        snapshotBeforeDrag = null;
        dragMoved = false;
        canvas.style.cursor = hoveredObject ? "move" : "crosshair";
    });

    canvas.addEventListener("mouseleave", () => {
        const coordsEl = document.getElementById("canvasCoords");
        if (coordsEl) coordsEl.textContent = "x: —  y: —";

        hoveredObject = null;
        canvas.style.cursor = "crosshair";
        canvas.title = "";
    });

    // Двойной клик — редактирование текста
    canvas.addEventListener("dblclick", () => {
        if (selectedObject && selectedObject.type === "text") {
            const newText = prompt("Введите текст:", selectedObject.text || "Текст");
            if (newText !== null && newText !== selectedObject.text) {
                pushUndo();
                selectedObject.text = newText;
                redraw();
            }
        }
    });

    // Клавиатура — Delete + стрелки
    window.addEventListener("keydown", (e) => {
        if (e.key === "Delete" && selectedObject) {
            const objects = state.layers[state.activeLayer].objects;
            const index = objects.indexOf(selectedObject);
            if (index !== -1) {
                pushUndo();
                objects.splice(index, 1);
                selectedObject = null;
                redraw();
                emitSelection();
            }
            return;
        }

        if (selectedObject &&
            ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
            e.preventDefault();
            const step = e.shiftKey ? 10 : 1;
            pushUndo();

            switch (e.key) {
                case "ArrowUp":    selectedObject.y -= step; break;
                case "ArrowDown":  selectedObject.y += step; break;
                case "ArrowLeft":  selectedObject.x -= step; break;
                case "ArrowRight": selectedObject.x += step; break;
            }
            redraw();
        }
    });
}

// ---------- HIGHLIGHT SELECTED (с угловыми маркерами) ----------
function highlightObject(ctx, obj) {
    ctx.save();

    let bx, by, bw, bh;

    if (obj.type === "line") {
        bx = Math.min(obj.x, obj.x + obj.size);
        by = Math.min(obj.y, obj.y + obj.size);
        bw = Math.abs(obj.size);
        bh = Math.abs(obj.size);
    } else if (obj.type === "free" && obj.points && obj.points.length) {
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        for (const p of obj.points) {
            if (p.x < minX) minX = p.x;
            if (p.y < minY) minY = p.y;
            if (p.x > maxX) maxX = p.x;
            if (p.y > maxY) maxY = p.y;
        }
        bx = minX;
        by = minY;
        bw = maxX - minX;
        bh = maxY - minY;
    } else if (obj.type === "image") {
        bx = obj.x;
        by = obj.y;
        bw = obj.size * 2;
        bh = obj.size * 1.5;
    } else {
        bx = obj.x;
        by = obj.y;
        bw = obj.size;
        bh = obj.size;
    }

    const pad = 4;
    bx -= pad;
    by -= pad;
    bw += pad * 2;
    bh += pad * 2;

    // Пульсация прозрачности рамки
    const alpha = 0.55 + 0.45 * Math.sin(pulsePhase);

    // Пунктирная рамка
    ctx.strokeStyle = `rgba(211, 47, 47, ${alpha})`;
    ctx.lineWidth = 1.5;
    ctx.setLineDash([5, 3]);
    ctx.strokeRect(bx, by, bw, bh);

    // Угловые маркеры
    const mSize = 6;
    ctx.setLineDash([]);
    ctx.fillStyle = "#d32f2f";
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 1;

    const corners = [
        [bx, by],
        [bx + bw, by],
        [bx, by + bh],
        [bx + bw, by + bh]
    ];

    for (const [cx, cy] of corners) {
        ctx.beginPath();
        ctx.rect(cx - mSize / 2, cy - mSize / 2, mSize, mSize);
        ctx.fill();
        ctx.stroke();
    }

    ctx.restore();
}

// ---------- АНИМАЦИЯ ПУЛЬСАЦИИ РАМКИ ----------
function startPulseAnimation() {
    if (animationFrameId) return;

    const tick = () => {
        pulsePhase += 0.06;
        if (pulsePhase > Math.PI * 2) pulsePhase -= Math.PI * 2;

        // Перерисовываем только если есть выделенный объект
        if (selectedObject) {
            redraw();
        }
        animationFrameId = requestAnimationFrame(tick);
    };

    animationFrameId = requestAnimationFrame(tick);
}