// ---------- UI MODULE ----------

import {
    state,
    methods,
    saveState,
    loadState,
    undo,
    redo,
    pushUndo,
    snapshotLayers,
    undoStack,
    redoStack
} from "./state.js";

import {
    redraw,
    addObjectToLayer,
    addImageObject,
    clearCanvas,
    getSelectedObject,
    updateSelectedObject,
    onObjectSelected,
    clearSelection
} from "./canvas.js";

import {
    effectGrayscale,
    effectInvert,
    effectBright
} from "./canvas.js";

// Подключаем модуль теста
import "./test.js";

// ---------- DOM ELEMENTS ----------
const methodSelect = document.getElementById("methodSelect");

const fillColorInput = document.getElementById("fillColor");
const strokeColorInput = document.getElementById("strokeColor");
const lineWidthInput = document.getElementById("lineWidth");
const shapeSizeInput = document.getElementById("shapeSize");
const lineTypeSelect = document.getElementById("lineType");

const infoTitle = document.getElementById("infoTitle");
const infoTheory = document.getElementById("infoTheory");
const infoCode = document.getElementById("infoCode");

const layersList = document.getElementById("layersList");
const btnAddLayer = document.getElementById("btnAddLayer");
const btnDeleteLayer = document.getElementById("btnDeleteLayer");
const btnLayerUp = document.getElementById("btnLayerUp");
const btnLayerDown = document.getElementById("btnLayerDown");

const btnAddObject = document.getElementById("btnAddObject");
const btnClearCanvas = document.getElementById("btnClearCanvas");
const btnUndo = document.getElementById("btnUndo");
const btnRedo = document.getElementById("btnRedo");
const btnSavePng = document.getElementById("btnSavePng");

const btnEffectGrayscale = document.getElementById("btnEffectGrayscale");
const btnEffectInvert = document.getElementById("btnEffectInvert");
const btnEffectBright = document.getElementById("btnEffectBright");

const imageInput = document.getElementById("imageInput");

const btnResetAll = document.getElementById("btnResetAll");

// ---------- INTERNAL CLIPBOARD ----------
let copyBuffer = null;

// ---------- INIT METHOD LIST ----------
export function initMethodList() {
    methodSelect.innerHTML = "";

    Object.keys(methods).forEach(key => {
        const opt = document.createElement("option");
        opt.value = key;
        opt.textContent = methods[key].name;
        methodSelect.appendChild(opt);
    });

    methodSelect.value = state.method;
}

// ---------- UPDATE INFO PANEL ----------
export function updateInfoPanel() {
    const m = methods[state.method];
    if (!m) return;
    infoTitle.textContent = m.name;
    infoTheory.textContent = m.theory;
    infoCode.innerHTML = highlightCSharp(m.code);
}

// ============================================================
// ПОДСВЕТКА КОДА C#
// ============================================================
function escapeHtml(s) {
    return s
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

const CS_KEYWORDS = [
    "var", "new", "int", "float", "double", "bool", "string", "void",
    "class", "public", "private", "protected", "static", "return",
    "if", "else", "for", "while", "using", "true", "false", "null",
    "this", "base", "override", "virtual", "const", "readonly",
    "get", "set", "out", "ref", "in", "as", "is", "switch", "case",
    "break", "continue", "default"
];

const CS_TYPES = [
    "Graphics", "Pen", "Brush", "SolidBrush", "LinearGradientBrush",
    "TextureBrush", "HatchBrush", "PathGradientBrush",
    "Matrix", "Rectangle", "RectangleF", "Point", "PointF",
    "Image", "Bitmap", "Font", "Color", "Size", "SizeF",
    "GraphicsPath", "Region", "StringFormat", "SmoothingMode"
];

function highlightCSharp(code) {
    let html = escapeHtml(code);
    html = html.replace(/(\/\/[^\n]*)/g, '<span class="c-comment">$1</span>');
    html = html.replace(/("(?:[^"\\]|\\.)*")/g, '<span class="c-string">$1</span>');

    const kwRegex = new RegExp(`\\b(${CS_KEYWORDS.join("|")})\\b`, "g");
    html = replaceOutsideSpans(html, kwRegex, '<span class="c-keyword">$1</span>');

    const typeRegex = new RegExp(`\\b(${CS_TYPES.join("|")})\\b`, "g");
    html = replaceOutsideSpans(html, typeRegex, '<span class="c-type">$1</span>');

    html = replaceOutsideSpans(
        html,
        /\b(\d+(?:\.\d+)?f?)\b/g,
        '<span class="c-number">$1</span>'
    );

    return html;
}

function replaceOutsideSpans(html, regex, replacement) {
    const parts = html.split(/(<span[^>]*>.*?<\/span>)/g);
    return parts
        .map(part => {
            if (part.startsWith("<span")) return part;
            return part.replace(regex, replacement);
        })
        .join("");
}

// ---------- КОПИРОВАНИЕ КОДА ПО КЛИКУ ----------
if (infoCode) {
    infoCode.style.cursor = "pointer";
    infoCode.title = "Кликните, чтобы скопировать";

    infoCode.addEventListener("click", () => {
        const text = infoCode.textContent;
        navigator.clipboard.writeText(text).then(() => {
            const oldTitle = infoCode.title;
            infoCode.title = "Скопировано!";
            setTimeout(() => (infoCode.title = oldTitle), 1200);
        }).catch(() => {
            const range = document.createRange();
            range.selectNodeContents(infoCode);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
        });
    });
}

// ---------- RENDER LAYERS (с тумблерами) ----------
function renderLayers() {
    layersList.innerHTML = "";

    state.layers.forEach((layer, index) => {
        const li = document.createElement("li");
        li.className = index === state.activeLayer ? "active-layer" : "";
        if (!layer.visible) li.classList.add("layer-hidden");

        const label = document.createElement("span");
        label.className = "layer-label";
        const count = layer.objects.length;
        label.textContent = `Слой ${layer.id}${count ? ` (${count})` : ""}`;
        label.addEventListener("click", () => {
            state.activeLayer = index;
            renderLayers();
            redraw();
            saveState();
        });

        const toggle = document.createElement("label");
        toggle.className = "layer-toggle";
        toggle.title = layer.visible ? "Скрыть слой" : "Показать слой";
        toggle.addEventListener("click", (e) => e.stopPropagation());

        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.checked = layer.visible;
        checkbox.addEventListener("change", () => {
            layer.visible = checkbox.checked;
            renderLayers();
            redraw();
            saveState();
        });

        const slider = document.createElement("span");
        slider.className = "layer-toggle-slider";

        toggle.appendChild(checkbox);
        toggle.appendChild(slider);

        li.appendChild(label);
        li.appendChild(toggle);
        layersList.appendChild(li);
    });
}

// ---------- LAYER BUTTONS ----------
btnAddLayer.addEventListener("click", () => {
    pushUndo();
    const id = state.layers.length + 1;
    state.layers.push({ id, visible: true, objects: [] });
    state.activeLayer = state.layers.length - 1;
    renderLayers();
    redraw();
    saveState();
});

btnDeleteLayer.addEventListener("click", () => {
    if (state.layers.length <= 1) {
        alert("Нельзя удалить последний слой.");
        return;
    }
    pushUndo();
    state.layers.splice(state.activeLayer, 1);
    state.activeLayer = Math.max(0, state.activeLayer - 1);
    clearSelection();
    renderLayers();
    redraw();
    saveState();
});

btnLayerUp.addEventListener("click", () => {
    if (state.activeLayer === 0) return;
    pushUndo();
    const i = state.activeLayer;
    [state.layers[i], state.layers[i - 1]] = [state.layers[i - 1], state.layers[i]];
    state.activeLayer--;
    renderLayers();
    redraw();
    saveState();
});

btnLayerDown.addEventListener("click", () => {
    if (state.activeLayer === state.layers.length - 1) return;
    pushUndo();
    const i = state.activeLayer;
    [state.layers[i], state.layers[i + 1]] = [state.layers[i + 1], state.layers[i]];
    state.activeLayer++;
    renderLayers();
    redraw();
    saveState();
});

// ---------- INPUT HANDLERS ----------
methodSelect.addEventListener("change", () => {
    state.method = methodSelect.value;
    updateInfoPanel();
    saveState();
});

fillColorInput.addEventListener("input", () => {
    const value = fillColorInput.value;
    state.fillColor = value;
    updateSelectedObject({ fillColor: value });
    saveState();
});

strokeColorInput.addEventListener("input", () => {
    const value = strokeColorInput.value;
    state.strokeColor = value;
    updateSelectedObject({ strokeColor: value });
    saveState();
});

lineWidthInput.addEventListener("input", () => {
    const value = parseInt(lineWidthInput.value, 10);
    state.lineWidth = value;
    updateSelectedObject({ lineWidth: value });
    saveState();
});

shapeSizeInput.addEventListener("input", () => {
    const value = parseInt(shapeSizeInput.value, 10);
    state.shapeSize = value;
    updateSelectedObject({ size: value });
    saveState();
});

lineTypeSelect.addEventListener("change", () => {
    const value = lineTypeSelect.value;
    state.lineType = value;
    updateSelectedObject({ lineType: value });
    saveState();
});

// ---------- SELECTION LISTENER ----------
onObjectSelected((obj) => {
    if (!obj) return;

    if (obj.fillColor)   fillColorInput.value   = obj.fillColor;
    if (obj.strokeColor) strokeColorInput.value = obj.strokeColor;
    if (obj.lineWidth != null) lineWidthInput.value = obj.lineWidth;
    if (obj.size != null)      shapeSizeInput.value = obj.size;
    if (obj.lineType)    lineTypeSelect.value   = obj.lineType;
});

// ---------- SAVE PNG ----------
function savePng() {
    const link = document.createElement("a");
    link.href = document.getElementById("canvas").toDataURL("image/png");
    link.download = "canvas.png";
    link.click();
}

// ---------- CANVAS BUTTONS ----------
btnAddObject.addEventListener("click", () => {
    addObjectToLayer();
    redraw();
    saveState();
});

btnClearCanvas.addEventListener("click", () => {
    if (!confirm("Очистить активный слой?")) return;
    pushUndo();
    state.layers[state.activeLayer].objects = [];
    clearSelection();
    saveState();
});

btnUndo.addEventListener("click", () => {
    if (undo()) {
        renderLayers();
        redraw();
        saveState();
    }
});

if (btnRedo) {
    btnRedo.addEventListener("click", () => {
        if (redo()) {
            renderLayers();
            redraw();
            saveState();
        }
    });
}

btnSavePng.addEventListener("click", savePng);

// ---------- EFFECTS ----------
btnEffectGrayscale.addEventListener("click", () => {
    effectGrayscale();
    saveState();
});

btnEffectInvert.addEventListener("click", () => {
    effectInvert();
    saveState();
});

btnEffectBright.addEventListener("click", () => {
    effectBright();
    saveState();
});

// ---------- IMAGE LOADING ----------
imageInput.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;

    state.method = "image";
    methodSelect.value = "image";
    updateInfoPanel();

    const img = new Image();
    img.src = URL.createObjectURL(file);

    img.onload = () => {
        addImageObject(img);
        URL.revokeObjectURL(img.src);
        saveState();
    };

    img.onerror = () => {
        alert("Не удалось загрузить изображение.");
    };
});

// ============================================================
// THEME TOGGLE
// ============================================================
const btnThemeToggle = document.getElementById("btnThemeToggle");
const THEME_KEY = "gdi_theme";

function applyTheme(theme) {
    if (theme === "dark" || theme === "light") {
        document.documentElement.setAttribute("data-theme", theme);
    } else {
        document.documentElement.removeAttribute("data-theme");
    }
    updateThemeButton();
}

function updateThemeButton() {
    if (!btnThemeToggle) return;
    const isDark = document.documentElement.getAttribute("data-theme") === "dark"
        || (!document.documentElement.hasAttribute("data-theme")
            && window.matchMedia("(prefers-color-scheme: dark)").matches);
    btnThemeToggle.textContent = isDark ? "☀️" : "🌙";
    btnThemeToggle.title = isDark ? "Светлая тема" : "Тёмная тема";
}

if (btnThemeToggle) {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved) applyTheme(saved);
    else updateThemeButton();

    btnThemeToggle.addEventListener("click", () => {
        const isDark = document.documentElement.getAttribute("data-theme") === "dark"
            || (!document.documentElement.hasAttribute("data-theme")
                && window.matchMedia("(prefers-color-scheme: dark)").matches);

        const next = isDark ? "light" : "dark";
        applyTheme(next);
        localStorage.setItem(THEME_KEY, next);
    });

    window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => {
        if (!localStorage.getItem(THEME_KEY)) updateThemeButton();
    });
}

// ============================================================
// ХОТКЕИ (Ctrl+Z / Ctrl+Y / Ctrl+S / Ctrl+C / Ctrl+V)
// ============================================================
window.addEventListener("keydown", (e) => {
    const ctrl = e.ctrlKey || e.metaKey;

    const tag = (e.target.tagName || "").toLowerCase();
    const inputType = (e.target.type || "").toLowerCase();
    const isTextInput =
        (tag === "input" && ["text", "search", "email", "url", "tel", "password", "number"].includes(inputType)) ||
        tag === "textarea";

    if (ctrl && e.key === "z" && !e.shiftKey && !isTextInput) {
        e.preventDefault();
        if (undo()) {
            renderLayers();
            redraw();
            saveState();
        }
        return;
    }

    if ((ctrl && e.shiftKey && e.key.toLowerCase() === "z") || (ctrl && e.key === "y")) {
        if (isTextInput) return;
        e.preventDefault();
        if (redo()) {
            renderLayers();
            redraw();
            saveState();
        }
        return;
    }

    if (ctrl && e.key === "s" && !isTextInput) {
        e.preventDefault();
        savePng();
        return;
    }

    if (ctrl && e.key === "c" && !isTextInput) {
        const selection = window.getSelection().toString();
        if (selection) return;

        const sel = getSelectedObject();
        if (sel) {
            e.preventDefault();
            copyBuffer = JSON.parse(JSON.stringify(
                sel.type === "image" ? { ...sel, img: null } : sel
            ));
            if (sel.type === "image") {
                copyBuffer.__img = sel.img;
            }
        }
        return;
    }

    if (ctrl && e.key === "v" && !isTextInput) {
        e.preventDefault();

        if (copyBuffer) {
            const clone = JSON.parse(JSON.stringify(copyBuffer));
            if (copyBuffer.__img) clone.img = copyBuffer.__img;
            delete clone.__img;

            clone.x = (clone.x ?? 0) + 20;
            clone.y = (clone.y ?? 0) + 20;

            pushUndo();
            state.layers[state.activeLayer].objects.push(clone);
            redraw();
            saveState();
            return;
        }

        if (navigator.clipboard && navigator.clipboard.read) {
            navigator.clipboard.read().then(items => {
                for (const item of items) {
                    const imageType = item.types.find(t => t.startsWith("image/"));
                    if (imageType) {
                        item.getType(imageType).then(blob => {
                            const img = new Image();
                            img.onload = () => {
                                addImageObject(img);
                                URL.revokeObjectURL(img.src);
                                saveState();
                            };
                            img.onerror = () => {
                                alert("Не удалось вставить изображение из буфера.");
                            };
                            img.src = URL.createObjectURL(blob);
                        });
                        break;
                    }
                }
            }).catch(() => {});
        }
        return;
    }
});

// ============================================================
// КНОПКА «СБРОСИТЬ ВСЁ»
// ============================================================
if (btnResetAll) {
    btnResetAll.addEventListener("click", () => {
        if (!confirm("Сбросить всё? Будут удалены все слои, настройки и история тестирования.")) return;

        // Чистим localStorage
        localStorage.removeItem("gdi_app_state");
        localStorage.removeItem("gdi_theme");

        // Сбрасываем state
        state.method = "rect";
        state.fillColor = "#1976d2";
        state.strokeColor = "#000000";
        state.lineWidth = 2;
        state.shapeSize = 120;
        state.lineType = "solid";
        state.layers = [{ id: 1, visible: true, objects: [] }];
        state.activeLayer = 0;
        state.history = [];

        // Чистим undo/redo
        undoStack.length = 0;
        redoStack.length = 0;

        // Обновляем инпуты
        methodSelect.value = "rect";
        fillColorInput.value = "#1976d2";
        strokeColorInput.value = "#000000";
        lineWidthInput.value = 2;
        shapeSizeInput.value = 120;
        lineTypeSelect.value = "solid";

        // Обновляем UI
        updateInfoPanel();
        renderLayers();
        clearSelection();
        redraw();

        // Сбрасываем тему на системную
        document.documentElement.removeAttribute("data-theme");
        updateThemeButton();

        alert("Сброшено. Все данные удалены.");
    });
}

// ============================================================
// RIPPLE-ЭФФЕКТ НА КНОПКАХ
// ============================================================
window.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("button").forEach(btn => {
        btn.addEventListener("click", (e) => {
            const rect = btn.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);

            const circle = document.createElement("span");
            circle.className = "ripple-circle";
            circle.style.width = circle.style.height = `${size}px`;
            circle.style.left = `${e.clientX - rect.left - size / 2}px`;
            circle.style.top  = `${e.clientY - rect.top  - size / 2}px`;

            btn.appendChild(circle);
            setTimeout(() => circle.remove(), 600);
        });
    });
});

// ---------- INIT UI ----------
export function initUI() {
    loadState();

    initMethodList();
    updateInfoPanel();
    renderLayers();

    fillColorInput.value = state.fillColor;
    strokeColorInput.value = state.strokeColor;
    lineWidthInput.value = state.lineWidth;
    shapeSizeInput.value = state.shapeSize;
    lineTypeSelect.value = state.lineType;

    const saved = localStorage.getItem(THEME_KEY);
    if (saved) applyTheme(saved);

    redraw();
}