// ---------- STATE MODULE ----------

export const state = {
    // Текущий выбранный метод
    method: "rect",

    // Параметры рисования
    fillColor: "#1976d2",
    strokeColor: "#000000",
    lineWidth: 2,
    shapeSize: 120,
    lineType: "solid",

    // Слои
    layers: [
        { id: 1, visible: true, objects: [] }
    ],

    activeLayer: 0,

    // История тестирования
    history: []
};

// ---------- UNDO / REDO STACKS ----------
export const undoStack = [];
export const redoStack = [];

// ---------- METHODS DATA ----------

export const methods = {
    rect: {
        name: "Прямоугольник",
        theory: "Базовая фигура. Используется для демонстрации заливки и обводки.",
        code: `g.FillRectangle(brush, x, y, w, h);
g.DrawRectangle(pen, x, y, w, h);`
    },

    ellipse: {
        name: "Эллипс",
        theory: "Овал, рисуется через метод DrawEllipse.",
        code: `g.FillEllipse(brush, x, y, w, h);
g.DrawEllipse(pen, x, y, w, h);`
    },

    line: {
        name: "Линия",
        theory: "Простая линия между двумя точками.",
        code: `g.DrawLine(pen, x1, y1, x2, y2);`
    },

    text: {
        name: "Текст",
        theory: "Отрисовка текста через DrawString.",
        code: `g.DrawString("Hello", font, brush, x, y);`
    },

    image: {
        name: "Изображение",
        theory: "Отрисовка bitmap через DrawImage.",
        code: `g.DrawImage(img, x, y, w, h);`
    },

    free: {
        name: "Свободное рисование",
        theory: "Рисование линий по точкам.",
        code: `g.DrawLines(pen, points);`
    },

    gradient: {
        name: "Градиент",
        theory: "Линейный градиент через LinearGradientBrush.",
        code: `var br = new LinearGradientBrush(rect, c1, c2, 0f);
g.FillRectangle(br, rect);`
    },

    pattern: {
        name: "Паттерн",
        theory: "Заливка текстурой через TextureBrush.",
        code: `var br = new TextureBrush(img);
g.FillRectangle(br, rect);`
    },

    matrix: {
        name: "Матрица трансформации",
        theory: "Применение матрицы к Graphics.",
        code: `var m = new Matrix();
m.Rotate(15);
m.Scale(1.2f, 0.8f);
g.Transform = m;`
    },

    shear: {
        name: "Скос (Shear)",
        theory: "Скос по оси X или Y.",
        code: `var m = new Matrix();
m.Shear(0.5f, 0);
g.Transform = m;`
    },

    perspective: {
        name: "Перспектива",
        theory: "Псевдо‑перспектива через матрицу.",
        code: `var m = new Matrix(1, 0.3f, 0, 1, 0, 0);
g.Transform = m;`
    }
};

// ---------- TEST QUESTIONS ----------

export const questions = [
    {
        text: "Какой метод GDI+ используется для рисования залитого прямоугольника?",
        answers: [
            "g.DrawRectangle(pen, x, y, w, h)",
            "g.FillRectangle(brush, x, y, w, h)",
            "g.DrawEllipse(pen, x, y, w, h)",
            "g.FillEllipse(brush, x, y, w, h)"
        ],
        correct: 1,
        explanation: "Метод FillRectangle заливает прямоугольник цветом кисти (Brush), а DrawRectangle только обводит контуром (Pen)."
    },
    {
        text: "Какой объект GDI+ отвечает за цвет и толщину контура фигуры?",
        answers: ["Brush", "Pen", "Font", "Matrix"],
        correct: 1,
        explanation: "Pen задаёт цвет, толщину и стиль линии (контура). Brush отвечает за заливку."
    },
    {
        text: "Какой метод рисует текст на графической поверхности?",
        answers: [
            "g.DrawText(...)",
            "g.DrawString(...)",
            "g.FillText(...)",
            "g.WriteLine(...)"
        ],
        correct: 1,
        explanation: "DrawString — это метод класса Graphics, который рисует текст заданным шрифтом и кистью в указанной точке."
    },
    {
        text: "Какой класс GDI+ используется для заливки фигуры сплошным цветом?",
        answers: [
            "SolidBrush",
            "LinearGradientBrush",
            "TextureBrush",
            "HatchBrush"
        ],
        correct: 0,
        explanation: "SolidBrush заливает фигуру одним сплошным цветом. Остальные кисти дают градиент, текстуру или штриховку."
    },
    {
        text: "Какой класс GDI+ создаёт линейный градиент?",
        answers: [
            "SolidBrush",
            "LinearGradientBrush",
            "TextureBrush",
            "PathGradientBrush"
        ],
        correct: 1,
        explanation: "LinearGradientBrush создаёт плавный переход между двумя цветами по прямой линии."
    },
    {
        text: "Какой класс GDI+ заливает фигуру текстурой (изображением)?",
        answers: [
            "SolidBrush",
            "LinearGradientBrush",
            "TextureBrush",
            "HatchBrush"
        ],
        correct: 2,
        explanation: "TextureBrush использует изображение как шаблон для заливки фигуры."
    },
    {
        text: "Какой метод класса Matrix выполняет поворот?",
        answers: [
            "m.Scale(...)",
            "m.Rotate(...)",
            "m.Translate(...)",
            "m.Shear(...)"
        ],
        correct: 1,
        explanation: "Matrix.Rotate(angle) поворачивает систему координат на заданный угол (в градусах)."
    },
    {
        text: "Какой метод класса Matrix выполняет скос (shear)?",
        answers: [
            "m.Scale(...)",
            "m.Rotate(...)",
            "m.Shear(...)",
            "m.Translate(...)"
        ],
        correct: 2,
        explanation: "Matrix.Shear(shearX, shearY) наклоняет систему координат по осям X и Y."
    },
    {
        text: "Какой метод GDI+ рисует изображение (bitmap) на поверхности?",
        answers: [
            "g.DrawImage(img, x, y, w, h)",
            "g.DrawBitmap(img, x, y, w, h)",
            "g.PaintImage(img, x, y, w, h)",
            "g.RenderImage(img, x, y, w, h)"
        ],
        correct: 0,
        explanation: "DrawImage — это стандартный метод Graphics для вывода изображения (Image/Bitmap) на поверхность."
    },
    {
        text: "Какой метод GDI+ рисует линию по массиву точек?",
        answers: [
            "g.DrawLine(pen, points)",
            "g.DrawLines(pen, points)",
            "g.DrawCurve(pen, points)",
            "g.DrawPolygon(pen, points)"
        ],
        correct: 1,
        explanation: "DrawLines соединяет массив точек ломаной линией. DrawCurve делает сглаженную кривую, DrawPolygon — замкнутый многоугольник."
    }
];

// ---------- LOCAL STORAGE ----------

const STORAGE_KEY = "gdi_app_state";

export function saveState() {
    try {
        const data = {
            method: state.method,
            fillColor: state.fillColor,
            strokeColor: state.strokeColor,
            lineWidth: state.lineWidth,
            shapeSize: state.shapeSize,
            lineType: state.lineType,
            layers: state.layers,
            activeLayer: state.activeLayer,
            history: state.history
        };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
        console.error("Не удалось сохранить состояние:", e);
    }
}

export function loadState() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return;

        const data = JSON.parse(raw);

        if (typeof data.method === "string") state.method = data.method;
        if (typeof data.fillColor === "string") state.fillColor = data.fillColor;
        if (typeof data.strokeColor === "string") state.strokeColor = data.strokeColor;
        if (typeof data.lineWidth === "number") state.lineWidth = data.lineWidth;
        if (typeof data.shapeSize === "number") state.shapeSize = data.shapeSize;
        if (typeof data.lineType === "string") state.lineType = data.lineType;
        if (Array.isArray(data.layers) && data.layers.length > 0) state.layers = data.layers;
        if (typeof data.activeLayer === "number") state.activeLayer = data.activeLayer;
        if (Array.isArray(data.history)) state.history = data.history;
    } catch (e) {
        console.error("Не удалось загрузить состояние:", e);
    }
}

// ---------- UNDO / REDO HELPERS ----------

export function snapshotLayers() {
    return JSON.parse(JSON.stringify(state.layers));
}

export function pushUndo() {
    undoStack.push(snapshotLayers());
    if (undoStack.length > 50) undoStack.shift();
    redoStack.length = 0;
}

export function pushUndoSnapshot(snapshot) {
    undoStack.push(snapshot);
    if (undoStack.length > 50) undoStack.shift();
    redoStack.length = 0;
}

export function undo() {
    if (undoStack.length === 0) return false;

    redoStack.push(snapshotLayers());
    const prev = undoStack.pop();
    state.layers = prev;

    if (state.activeLayer >= state.layers.length) {
        state.activeLayer = state.layers.length - 1;
    }
    return true;
}

export function redo() {
    if (redoStack.length === 0) return false;

    undoStack.push(snapshotLayers());
    const next = redoStack.pop();
    state.layers = next;

    if (state.activeLayer >= state.layers.length) {
        state.activeLayer = state.layers.length - 1;
    }
    return true;
}