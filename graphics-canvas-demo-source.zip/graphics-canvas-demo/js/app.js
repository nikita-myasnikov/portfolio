// ---------- APP MODULE ----------
// Единая точка входа приложения.

import { initUI } from "./ui.js";
import { resizeCanvas, enableDragging } from "./canvas.js";

// Инициализация после загрузки DOM
window.addEventListener("DOMContentLoaded", () => {
    // initUI() внутри вызывает loadState() и первый redraw()
    initUI();
    // После того как DOM готов и state загружен — подгоняем canvas
    resizeCanvas();
    // Включаем перетаскивание объектов мышью
    enableDragging();
});

// Автоматическое обновление размера Canvas при изменении окна
window.addEventListener("resize", resizeCanvas);