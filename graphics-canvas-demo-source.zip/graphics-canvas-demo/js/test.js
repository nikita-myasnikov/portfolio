// ---------- TEST MODULE ----------

import { state, questions, saveState } from "./state.js";

// ---------- DOM ELEMENTS ----------
const testModalBackdrop = document.getElementById("testModalBackdrop");
const btnStartTest = document.getElementById("btnStartTest");
const btnCloseTest = document.getElementById("btnCloseTest");
const btnNextQuestion = document.getElementById("btnNextQuestion");

const testProgress = document.getElementById("testProgress");
const testProgressFill = document.getElementById("testProgressFill");
const testQuestion = document.getElementById("testQuestion");
const testAnswers = document.getElementById("testAnswers");
const testExplanation = document.getElementById("testExplanation");
const testTimer = document.getElementById("testTimer");

const testResultBlock = document.getElementById("testResultBlock");
const testResultText = document.getElementById("testResultText");
const testUserName = document.getElementById("testUserName");

const btnSaveResult = document.getElementById("btnSaveResult");
const btnExportCsv = document.getElementById("btnExportCsv");
const btnClearHistory = document.getElementById("btnClearHistory");
const resultsHistory = document.getElementById("resultsHistory");

// ---------- TEST STATE ----------
const testState = {
    currentIndex: 0,
    correctCount: 0,
    finished: false,
    answered: false,
    selected: null,
    startTime: 0,
    elapsed: 0,       // секунды
    timerId: null
};

// ---------- TIMER ----------
function formatTime(sec) {
    const m = Math.floor(sec / 60).toString().padStart(2, "0");
    const s = (sec % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
}

function startTimer() {
    stopTimer();
    testState.startTime = Date.now();
    testState.elapsed = 0;
    if (testTimer) testTimer.textContent = "00:00";

    testState.timerId = setInterval(() => {
        testState.elapsed = Math.floor((Date.now() - testState.startTime) / 1000);
        if (testTimer) testTimer.textContent = formatTime(testState.elapsed);
    }, 250);
}

function stopTimer() {
    if (testState.timerId) {
        clearInterval(testState.timerId);
        testState.timerId = null;
    }
}

// ---------- OPEN / CLOSE ----------
export function openTestModal() {
    if (!testModalBackdrop) return;

    if (!questions || questions.length === 0) {
        alert("Вопросы теста не загружены.");
        return;
    }

    testModalBackdrop.style.display = "flex";

    resetTest();
    renderQuestion();
    renderHistory();
    startTimer();
}

export function closeTestModal() {
    if (!testModalBackdrop) return;

    if (!testState.finished && testState.currentIndex > 0) {
        if (!confirm("Прервать тест? Прогресс не сохранится.")) return;
    }

    stopTimer();
    testModalBackdrop.style.display = "none";
}

// ---------- RESET ----------
function resetTest() {
    testState.currentIndex = 0;
    testState.correctCount = 0;
    testState.finished = false;
    testState.answered = false;
    testState.selected = null;
    testState.elapsed = 0;

    if (testResultBlock) testResultBlock.style.display = "none";
    if (testUserName) testUserName.value = "";
    if (testExplanation) {
        testExplanation.style.display = "none";
        testExplanation.textContent = "";
    }
    if (btnNextQuestion) {
        btnNextQuestion.disabled = true;
        btnNextQuestion.textContent = "Далее";
    }
    if (testProgressFill) testProgressFill.style.width = "0%";
    if (testTimer) testTimer.textContent = "00:00";
}

// ---------- RENDER QUESTION ----------
function renderQuestion() {
    const q = questions[testState.currentIndex];
    if (!q) return;

    testState.answered = false;
    testState.selected = null;

    if (testProgress) {
        testProgress.textContent = `Вопрос ${testState.currentIndex + 1} из ${questions.length}`;
    }
    if (testQuestion) {
        testQuestion.textContent = q.text;
    }

    if (testExplanation) {
        testExplanation.style.display = "none";
        testExplanation.textContent = "";
    }

    if (!testAnswers) return;
    testAnswers.innerHTML = "";

    q.answers.forEach((ans, idx) => {
        const id = `q${testState.currentIndex}_a${idx}`;

        const label = document.createElement("label");
        label.className = "answer-label";
        label.dataset.index = idx;

        const input = document.createElement("input");
        input.type = "radio";
        input.name = "answer";
        input.value = idx;
        input.id = id;

        const span = document.createElement("span");
        span.textContent = ans;

        label.htmlFor = id;
        label.appendChild(input);
        label.appendChild(span);

        label.addEventListener("change", () => {
            if (testState.answered) return;
            testState.selected = idx;
            if (btnNextQuestion) btnNextQuestion.disabled = false;
        });

        testAnswers.appendChild(label);
    });

    if (btnNextQuestion) {
        btnNextQuestion.disabled = true;
        if (testState.currentIndex === questions.length - 1) {
            btnNextQuestion.textContent = "Завершить";
        } else {
            btnNextQuestion.textContent = "Ответить";
        }
    }

    if (testProgressFill) {
        const percent = ((testState.currentIndex + 1) / questions.length) * 100;
        testProgressFill.style.width = percent + "%";
    }
}

// ---------- GET SELECTED ----------
function getSelectedAnswer() {
    if (!testAnswers) return null;
    const inputs = testAnswers.querySelectorAll("input[name='answer']");
    for (const input of inputs) {
        if (input.checked) return parseInt(input.value, 10);
    }
    return null;
}

// ---------- ПОКАЗАТЬ ПРАВИЛЬНЫЙ ОТВЕТ + ОБЪЯСНЕНИЕ ----------
function showAnswer() {
    const q = questions[testState.currentIndex];
    const selected = testState.selected;

    const labels = testAnswers.querySelectorAll(".answer-label");
    labels.forEach(label => {
        const idx = parseInt(label.dataset.index, 10);
        label.classList.add("answered");
        if (idx === q.correct) label.classList.add("correct");
        if (idx === selected && selected !== q.correct) label.classList.add("wrong");
        const input = label.querySelector("input");
        if (input) input.disabled = true;
    });

    if (testExplanation && q.explanation) {
        testExplanation.textContent = q.explanation;
        testExplanation.style.display = "block";
    }

    if (btnNextQuestion) {
        btnNextQuestion.disabled = false;
        if (testState.currentIndex === questions.length - 1) {
            btnNextQuestion.textContent = "Показать результат";
        } else {
            btnNextQuestion.textContent = "Продолжить";
        }
    }

    testState.answered = true;
}

// ---------- FINISH TEST ----------
function finishTest() {
    testState.finished = true;
    stopTimer();

    const score10 = Math.round((testState.correctCount / questions.length) * 10);

    if (testResultText) {
        testResultText.textContent =
            `Правильных ответов: ${testState.correctCount} из ${questions.length}. ` +
            `Оценка: ${score10}/10. Время: ${formatTime(testState.elapsed)}.`;
    }

    if (testResultBlock) testResultBlock.style.display = "block";
    if (btnNextQuestion) btnNextQuestion.disabled = true;
}

// ---------- HISTORY ----------
export function renderHistory() {
    if (!resultsHistory) return;
    resultsHistory.innerHTML = "";

    if (!state.history || !state.history.length) {
        resultsHistory.textContent = "История пуста.";
        return;
    }

    state.history
        .slice()
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .forEach(item => {
            const div = document.createElement("div");
            div.className = "history-item";
            const time = item.time ? ` • ${item.time}` : "";
            div.textContent =
                `${item.date} — ${item.user} — ${item.correct}/${questions.length}, оценка ${item.score}/10${time}`;
            resultsHistory.appendChild(div);
        });
}

// ---------- EXPORT CSV ----------
function exportCsv() {
    if (!state.history || !state.history.length) {
        alert("История пуста — нечего экспортировать.");
        return;
    }

    const header = ["Дата", "Имя", "Правильных", "Всего", "Оценка", "Время"];
    const rows = state.history.map(item => [
        item.date || "",
        item.user || "",
        item.correct ?? 0,
        questions.length,
        item.score ?? 0,
        item.time || ""
    ]);

    // CSV с BOM — чтобы Excel корректно открывал кириллицу
    const csv = "\uFEFF" + [header, ...rows]
        .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(";"))
        .join("\n");

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `test-history-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}

// ---------- BUTTON HANDLERS ----------
if (btnStartTest) {
    btnStartTest.addEventListener("click", openTestModal);
}
if (btnCloseTest) {
    btnCloseTest.addEventListener("click", closeTestModal);
}

if (btnNextQuestion) {
    btnNextQuestion.addEventListener("click", () => {
        if (testState.finished) return;

        if (!testState.answered) {
            const selected = getSelectedAnswer();
            if (selected === null) {
                alert("Выберите вариант ответа.");
                return;
            }

            testState.selected = selected;
            const q = questions[testState.currentIndex];
            if (selected === q.correct) testState.correctCount++;

            showAnswer();
            return;
        }

        if (testState.currentIndex === questions.length - 1) {
            finishTest();
        } else {
            testState.currentIndex++;
            renderQuestion();
        }
    });
}

if (btnSaveResult) {
    btnSaveResult.addEventListener("click", () => {
        if (!testState.finished) {
            alert("Сначала завершите тест.");
            return;
        }

        const name = testUserName ? testUserName.value.trim() : "";
        if (!name) {
            alert("Введите имя.");
            return;
        }

        const score10 = Math.round((testState.correctCount / questions.length) * 10);

        const item = {
            user: name,
            date: new Date().toLocaleString("ru-RU"),
            correct: testState.correctCount,
            score: score10,
            time: formatTime(testState.elapsed)
        };

        if (!state.history) state.history = [];
        state.history.push(item);
        saveState();
        renderHistory();

        if (testUserName) testUserName.value = "";
        testState.finished = false;

        alert("Результат сохранён.");
    });
}

if (btnExportCsv) {
    btnExportCsv.addEventListener("click", exportCsv);
}

if (btnClearHistory) {
    btnClearHistory.addEventListener("click", () => {
        if (!confirm("Очистить историю?")) return;

        state.history = [];
        saveState();
        renderHistory();
    });
}

// ============================================================
// ХОТКЕИ ТЕСТА (1–4, Enter)
// ============================================================
window.addEventListener("keydown", (e) => {
    if (!testModalBackdrop || testModalBackdrop.style.display !== "flex") return;
    if (testState.finished) return;

    if (!testState.answered && ["1", "2", "3", "4"].includes(e.key)) {
        const idx = parseInt(e.key, 10) - 1;
        const input = testAnswers.querySelector(`input[value="${idx}"]`);
        if (input) {
            input.checked = true;
            testState.selected = idx;
            if (btnNextQuestion) btnNextQuestion.disabled = false;
        }
    }

    if (e.key === "Enter") {
        if (btnNextQuestion && !btnNextQuestion.disabled) btnNextQuestion.click();
    }
});