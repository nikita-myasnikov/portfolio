#ifndef MODELS_H
#define MODELS_H

#include <QString>
#include <QStringList>

struct AccessibilityFilters
{
    bool ramp = false;
    bool elevator = false;
    bool accessibleToilet = false;
    bool quietPlace = false;
    bool visualSupport = false;
    bool trainedStaff = false;
    bool pictureMenu = false;
    bool assistantAllowed = false;
};

struct UserProfile
{
    int id = -1;
    QString name;
    QString login;
    QString email;
    bool isAdmin = false;

    bool needRamp = false;
    bool needElevator = false;
    bool needAccessibleToilet = false;
    bool needQuietPlace = false;
    bool needVisualSupport = false;
    bool needTrainedStaff = false;
    bool needPictureMenu = false;
    bool needAssistance = false;
};

struct Place
{
    int id = -1;
    int categoryId = -1;
    QString name;
    QString categoryName;
    QString address;
    QString phone;
    QString description;

    bool hasRamp = false;
    bool hasElevator = false;
    bool hasAccessibleToilet = false;
    bool hasQuietPlace = false;
    bool hasVisualSupport = false;
    bool hasTrainedStaff = false;
    bool hasPictureMenu = false;
    bool allowsAssistant = false;

    QStringList photoPaths;
};


struct NewsItem
{
    int id = -1;
    QString title;
    QString text;
    QString image1;
    QString image2;
    QString createdAt;
};

struct UserAccount
{
    int id = -1;
    QString name;
    QString login;
    QString email;
    bool isAdmin = false;
};

#endif // MODELS_H
