#ifndef REGISTERWINDOW_H
#define REGISTERWINDOW_H

#include <QDialog>

#include "models.h"

class QCheckBox;
class QLineEdit;

class RegisterWindow : public QDialog
{
    Q_OBJECT

public:
    explicit RegisterWindow(QWidget* parent = nullptr);

private:
    UserProfile collectNeeds() const;
    void handleRegister();

    QLineEdit* m_nameEdit = nullptr;
    QLineEdit* m_loginEdit = nullptr;
    QLineEdit* m_emailEdit = nullptr;
    QLineEdit* m_passwordEdit = nullptr;
    QLineEdit* m_repeatPasswordEdit = nullptr;

    QCheckBox* m_rampCheck = nullptr;
    QCheckBox* m_elevatorCheck = nullptr;
    QCheckBox* m_toiletCheck = nullptr;
    QCheckBox* m_quietCheck = nullptr;
    QCheckBox* m_visualCheck = nullptr;
    QCheckBox* m_staffCheck = nullptr;
    QCheckBox* m_pictureMenuCheck = nullptr;
    QCheckBox* m_assistantCheck = nullptr;
};

#endif // REGISTERWINDOW_H
