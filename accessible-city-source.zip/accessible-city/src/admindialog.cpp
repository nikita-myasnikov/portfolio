#include "admindialog.h"

#include "database.h"

#include <QAbstractItemView>
#include <QCheckBox>
#include <QColor>
#include <QComboBox>
#include <QCursor>
#include <QFileDialog>
#include <QFileInfo>
#include <QFormLayout>
#include <QFrame>
#include <QGraphicsDropShadowEffect>
#include <QGridLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QListWidgetItem>
#include <QMessageBox>
#include <QPushButton>
#include <QScrollArea>
#include <QTextEdit>
#include <QInputDialog>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QHeaderView>
#include <QtGlobal>
#include <QVBoxLayout>

namespace
{
void addSoftShadow(QWidget* widget)
{
    auto* shadow = new QGraphicsDropShadowEffect(widget);
    shadow->setBlurRadius(26);
    shadow->setOffset(0, 8);
    shadow->setColor(QColor(15, 23, 42, 28));
    widget->setGraphicsEffect(shadow);
}

void makePrimary(QPushButton* button)
{
    button->setProperty("class", "PrimaryButton");
    button->setCursor(Qt::PointingHandCursor);
}

void makeSecondary(QPushButton* button)
{
    button->setProperty("class", "SecondaryButton");
    button->setCursor(Qt::PointingHandCursor);
}

void makeGhost(QPushButton* button)
{
    button->setProperty("class", "GhostButton");
    button->setCursor(Qt::PointingHandCursor);
}

QString photoDisplayText(const QString& path)
{
    if (path.startsWith(":/")) {
        return path.mid(path.lastIndexOf('/') + 1) + "  ·  встроенное фото";
    }
    return QFileInfo(path).fileName();
}
}

AdminDialog::AdminDialog(const UserProfile& currentUser, QWidget* parent)
    : QDialog(parent)
    , m_currentUser(currentUser)
{
    setupUi();
    loadData();
}

void AdminDialog::setupUi()
{
    setWindowTitle("Админ-панель — управление заведениями");
    setObjectName("AdminDialog");
    resize(1180, 780);
    setMinimumSize(1040, 680);

    auto* rootLayout = new QHBoxLayout(this);
    rootLayout->setContentsMargins(22, 22, 22, 22);
    rootLayout->setSpacing(18);

    auto* leftCard = new QFrame(this);
    leftCard->setObjectName("SidePanel");
    leftCard->setMinimumWidth(315);
    leftCard->setMaximumWidth(380);
    addSoftShadow(leftCard);
    rootLayout->addWidget(leftCard);

    auto* leftLayout = new QVBoxLayout(leftCard);
    leftLayout->setContentsMargins(20, 20, 20, 20);
    leftLayout->setSpacing(14);

    auto* title = new QLabel("🏙️ Заведения", leftCard);
    title->setObjectName("BrandTitle");
    leftLayout->addWidget(title);

    auto* hint = new QLabel("Выберите запись для редактирования или создайте новое место.", leftCard);
    hint->setObjectName("HintLabel");
    hint->setWordWrap(true);
    leftLayout->addWidget(hint);

    m_placeList = new QListWidget(leftCard);
    m_placeList->setObjectName("CategoryList");
    m_placeList->setSelectionMode(QAbstractItemView::SingleSelection);
    m_placeList->setSpacing(3);
    leftLayout->addWidget(m_placeList, 1);

    auto* newButton = new QPushButton("➕ Новое заведение", leftCard);
    auto* deleteButton = new QPushButton("🗑️ Удалить выбранное", leftCard);
    auto* usersButton = new QPushButton("👥 Управление пользователями", leftCard);
    auto* addNewsButton = new QPushButton("📰 Добавить новость", leftCard);
    auto* deleteNewsButton = new QPushButton("🗑 Удалить новость", leftCard);
    makePrimary(newButton);
    makeSecondary(deleteButton);
    makeSecondary(usersButton);
    makeSecondary(addNewsButton);
    makeSecondary(deleteNewsButton);
    leftLayout->addWidget(newButton);
    leftLayout->addWidget(deleteButton);
    leftLayout->addWidget(usersButton);
    leftLayout->addWidget(addNewsButton);
    leftLayout->addWidget(deleteNewsButton);

    auto* rightCard = new QFrame(this);
    rightCard->setObjectName("ContentPanel");
    addSoftShadow(rightCard);
    rootLayout->addWidget(rightCard, 1);

    auto* rightLayout = new QVBoxLayout(rightCard);
    rightLayout->setContentsMargins(22, 22, 22, 22);
    rightLayout->setSpacing(16);

    auto* header = new QFrame(rightCard);
    header->setObjectName("HeroCard");
    auto* headerLayout = new QVBoxLayout(header);
    headerLayout->setContentsMargins(24, 18, 24, 18);
    headerLayout->setSpacing(4);

    m_formTitleLabel = new QLabel("✏️ Редактирование заведения", header);
    m_formTitleLabel->setObjectName("HeroTitle");
    auto* subtitle = new QLabel("Администратор может добавлять, удалять и редактировать данные, условия доступности и фотографии. Для одного заведения доступно до 10 фотографий.", header);
    subtitle->setObjectName("HeroSubtitle");
    subtitle->setWordWrap(true);
    headerLayout->addWidget(m_formTitleLabel);
    headerLayout->addWidget(subtitle);
    rightLayout->addWidget(header);

    auto* scroll = new QScrollArea(rightCard);
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    scroll->setObjectName("TransparentScroll");
    rightLayout->addWidget(scroll, 1);

    auto* formContainer = new QWidget(scroll);
    auto* formContainerLayout = new QVBoxLayout(formContainer);
    formContainerLayout->setContentsMargins(4, 4, 4, 4);
    formContainerLayout->setSpacing(16);
    scroll->setWidget(formContainer);

    auto* baseBox = new QGroupBox("📝 Основная информация", formContainer);
    auto* formLayout = new QFormLayout(baseBox);
    formLayout->setHorizontalSpacing(16);
    formLayout->setVerticalSpacing(12);

    m_nameEdit = new QLineEdit(baseBox);
    m_categoryCombo = new QComboBox(baseBox);
    m_addressEdit = new QLineEdit(baseBox);
    m_phoneEdit = new QLineEdit(baseBox);
    m_descriptionEdit = new QTextEdit(baseBox);
    m_descriptionEdit->setMinimumHeight(110);

    m_nameEdit->setPlaceholderText("Например: Кафе \"Уют\"");
    m_addressEdit->setPlaceholderText("Адрес заведения");
    m_phoneEdit->setPlaceholderText("Телефон для связи");
    m_descriptionEdit->setPlaceholderText("Краткое описание заведения и условий посещения");

    formLayout->addRow("Название", m_nameEdit);
    formLayout->addRow("Категория", m_categoryCombo);
    formLayout->addRow("Адрес", m_addressEdit);
    formLayout->addRow("Телефон", m_phoneEdit);
    formLayout->addRow("Описание", m_descriptionEdit);
    formContainerLayout->addWidget(baseBox);

    auto* accessBox = new QGroupBox("♿ Условия доступности", formContainer);
    auto* accessLayout = new QGridLayout(accessBox);
    accessLayout->setHorizontalSpacing(20);
    accessLayout->setVerticalSpacing(8);

    m_rampCheck = new QCheckBox("Пандус / безбарьерный вход", accessBox);
    m_elevatorCheck = new QCheckBox("Лифт", accessBox);
    m_toiletCheck = new QCheckBox("Доступный туалет", accessBox);
    m_quietCheck = new QCheckBox("Тихая зона", accessBox);
    m_visualCheck = new QCheckBox("Визуальные подсказки", accessBox);
    m_staffCheck = new QCheckBox("Обученный персонал", accessBox);
    m_pictureMenuCheck = new QCheckBox("Меню с картинками", accessBox);
    m_assistantCheck = new QCheckBox("Возможность сопровождения", accessBox);

    accessLayout->addWidget(m_rampCheck, 0, 0);
    accessLayout->addWidget(m_elevatorCheck, 0, 1);
    accessLayout->addWidget(m_toiletCheck, 1, 0);
    accessLayout->addWidget(m_quietCheck, 1, 1);
    accessLayout->addWidget(m_visualCheck, 2, 0);
    accessLayout->addWidget(m_staffCheck, 2, 1);
    accessLayout->addWidget(m_pictureMenuCheck, 3, 0);
    accessLayout->addWidget(m_assistantCheck, 3, 1);
    formContainerLayout->addWidget(accessBox);

    auto* photosBox = new QGroupBox("🖼️ Фотографии заведения", formContainer);
    auto* photosLayout = new QVBoxLayout(photosBox);
    photosLayout->setSpacing(10);

    m_photoInfoLabel = new QLabel("Фото: 0 / 10", photosBox);
    m_photoInfoLabel->setObjectName("HintLabel");
    photosLayout->addWidget(m_photoInfoLabel);

    m_photosList = new QListWidget(photosBox);
    m_photosList->setObjectName("PhotoList");
    m_photosList->setMinimumHeight(130);
    m_photosList->setSelectionMode(QAbstractItemView::SingleSelection);
    photosLayout->addWidget(m_photosList);

    auto* photoButtonsLayout = new QHBoxLayout();
    auto* addPhotoButton = new QPushButton("➕ Добавить фото", photosBox);
    m_removePhotoButton = new QPushButton("🗑️ Удалить фото", photosBox);
    m_photoUpButton = new QPushButton("⬆️ Вверх", photosBox);
    m_photoDownButton = new QPushButton("⬇️ Вниз", photosBox);
    makeSecondary(addPhotoButton);
    makeGhost(m_removePhotoButton);
    makeGhost(m_photoUpButton);
    makeGhost(m_photoDownButton);
    photoButtonsLayout->addWidget(addPhotoButton);
    photoButtonsLayout->addWidget(m_removePhotoButton);
    photoButtonsLayout->addStretch(1);
    photoButtonsLayout->addWidget(m_photoUpButton);
    photoButtonsLayout->addWidget(m_photoDownButton);
    photosLayout->addLayout(photoButtonsLayout);

    auto* photoHint = new QLabel("Можно добавить до 10 изображений. При выборе файла он копируется в папку данных программы.", photosBox);
    photoHint->setObjectName("HintLabel");
    photoHint->setWordWrap(true);
    photosLayout->addWidget(photoHint);
    formContainerLayout->addWidget(photosBox);

    auto* actionsLayout = new QHBoxLayout();
    actionsLayout->setContentsMargins(0, 4, 0, 0);
    auto* closeButton = new QPushButton("❌ Закрыть", rightCard);
    auto* saveButton = new QPushButton("💾 Сохранить", rightCard);
    makeGhost(closeButton);
    makePrimary(saveButton);
    actionsLayout->addWidget(closeButton);
    actionsLayout->addStretch(1);
    actionsLayout->addWidget(saveButton);
    rightLayout->addLayout(actionsLayout);

    connect(m_placeList, &QListWidget::itemSelectionChanged, this, &AdminDialog::loadSelectedPlace);
    connect(usersButton, &QPushButton::clicked, this, [this]() {
        QDialog dialog(this);
        dialog.setWindowTitle("👥 Управление пользователями");
        dialog.resize(760, 480);
        auto* layout = new QVBoxLayout(&dialog);
        auto* table = new QTableWidget(&dialog);
        table->setColumnCount(5);
        table->setHorizontalHeaderLabels({"ID", "Имя", "Логин", "Почта", "Роль"});
        table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        auto reload = [&]() {
            QString error;
            const QVector<UserAccount> users = Database::instance().users(&error);
            if (!error.isEmpty()) QMessageBox::warning(&dialog, "Ошибка", error);
            table->setRowCount(0);
            for (const UserAccount& user : users) {
                int row = table->rowCount();
                table->insertRow(row);
                table->setItem(row, 0, new QTableWidgetItem(QString::number(user.id)));
                table->setItem(row, 1, new QTableWidgetItem(user.name));
                table->setItem(row, 2, new QTableWidgetItem(user.login));
                table->setItem(row, 3, new QTableWidgetItem(user.email));
                table->setItem(row, 4, new QTableWidgetItem(user.isAdmin ? "Администратор" : "Пользователь"));
            }
        };
        reload();
        auto* buttons = new QHBoxLayout();
        const bool ownerMode = (m_currentUser.login == "admin");
        auto* makeAdminButton = new QPushButton("👑 Сделать администратором", &dialog);
        auto* revokeAdminButton = new QPushButton("🔒 Лишить администрирования", &dialog);
        auto* deleteUserButton = new QPushButton("🗑 Удалить пользователя", &dialog);
        auto* closeUsersButton = new QPushButton("❌ Закрыть", &dialog);
        makePrimary(makeAdminButton);
        makeSecondary(revokeAdminButton);
        makeSecondary(deleteUserButton);
        makeGhost(closeUsersButton);
        makeAdminButton->setEnabled(ownerMode);
        revokeAdminButton->setEnabled(ownerMode);
        makeAdminButton->setToolTip(ownerMode ? "Назначить права администратора" : "Назначать администраторов может только владелец");
        revokeAdminButton->setToolTip(ownerMode ? "Снять права администратора" : "Лишать администрирования может только владелец");
        buttons->addWidget(makeAdminButton);
        buttons->addWidget(revokeAdminButton);
        buttons->addWidget(deleteUserButton);
        buttons->addStretch(1);
        buttons->addWidget(closeUsersButton);
        layout->addWidget(table);
        layout->addLayout(buttons);
        connect(makeAdminButton, &QPushButton::clicked, &dialog, [&]() {
            if (!ownerMode) {
                QMessageBox::warning(&dialog, "Недостаточно прав", "Назначать администраторов может только владелец системы.");
                return;
            }
            if (table->currentRow() < 0) return;
            QString error;
            if (!Database::instance().setUserAdminStatus(table->item(table->currentRow(), 0)->text().toInt(), true, &error)) QMessageBox::warning(&dialog, "Ошибка", error);
            reload();
        });
        connect(revokeAdminButton, &QPushButton::clicked, &dialog, [&]() {
            if (!ownerMode) {
                QMessageBox::warning(&dialog, "Недостаточно прав", "Лишать администрирования может только владелец системы.");
                return;
            }
            if (table->currentRow() < 0) return;
            if (QMessageBox::question(&dialog, "Права администратора", "Лишить выбранного пользователя прав администратора?") != QMessageBox::Yes) return;
            QString error;
            if (!Database::instance().setUserAdminStatus(table->item(table->currentRow(), 0)->text().toInt(), false, &error)) QMessageBox::warning(&dialog, "Ошибка", error);
            reload();
        });
        connect(deleteUserButton, &QPushButton::clicked, &dialog, [&]() {
            if (table->currentRow() < 0) return;
            if (QMessageBox::question(&dialog, "Удаление", "Удалить выбранного пользователя?") != QMessageBox::Yes) return;
            QString error;
            if (!Database::instance().deleteUser(table->item(table->currentRow(), 0)->text().toInt(), &error)) QMessageBox::warning(&dialog, "Ошибка", error);
            reload();
        });
        connect(closeUsersButton, &QPushButton::clicked, &dialog, &QDialog::accept);
        dialog.exec();
    });

    connect(deleteNewsButton, &QPushButton::clicked, this, [this]() {
        QDialog dialog(this);
        dialog.setObjectName("AdminDialog");
        dialog.setWindowTitle("Удаление новостей");
        dialog.resize(760, 520);

        auto* layout = new QVBoxLayout(&dialog);
        layout->setContentsMargins(22, 22, 22, 22);
        layout->setSpacing(14);

        auto* header = new QFrame(&dialog);
        header->setObjectName("HeroCard");
        auto* headerLayout = new QVBoxLayout(header);
        headerLayout->setContentsMargins(22, 16, 22, 16);
        auto* titleLabel = new QLabel("🗑 Удаление новостей", header);
        titleLabel->setObjectName("HeroTitle");
        auto* subtitleLabel = new QLabel("Выберите новость из списка и удалите её из вкладки новостей.", header);
        subtitleLabel->setObjectName("HeroSubtitle");
        subtitleLabel->setWordWrap(true);
        headerLayout->addWidget(titleLabel);
        headerLayout->addWidget(subtitleLabel);
        layout->addWidget(header);

        auto* list = new QListWidget(&dialog);
        list->setObjectName("PhotoList");
        layout->addWidget(list, 1);

        auto reloadNews = [&]() {
            list->clear();
            QString error;
            const QVector<NewsItem> items = Database::instance().news(&error);
            if (!error.isEmpty()) {
                QMessageBox::warning(&dialog, "Ошибка", error);
                return;
            }
            for (const NewsItem& item : items) {
                auto* row = new QListWidgetItem("📰 " + item.title + "  ·  " + item.createdAt, list);
                row->setData(Qt::UserRole, item.id);
                row->setToolTip(item.text);
            }
        };
        reloadNews();

        auto* actions = new QHBoxLayout();
        auto* deleteButton = new QPushButton("🗑️ Удалить выбранную новость", &dialog);
        auto* closeButton = new QPushButton("❌ Закрыть", &dialog);
        makeSecondary(deleteButton);
        makeGhost(closeButton);
        actions->addWidget(deleteButton);
        actions->addStretch(1);
        actions->addWidget(closeButton);
        layout->addLayout(actions);

        connect(deleteButton, &QPushButton::clicked, &dialog, [&]() {
            if (list->currentRow() < 0) {
                QMessageBox::information(&dialog, "Новости", "Выберите новость для удаления.");
                return;
            }
            if (QMessageBox::question(&dialog, "Удаление", "Удалить выбранную новость?") != QMessageBox::Yes) return;
            QString error;
            if (!Database::instance().deleteNews(list->currentItem()->data(Qt::UserRole).toInt(), &error)) {
                QMessageBox::warning(&dialog, "Ошибка", error);
                return;
            }
            reloadNews();
        });
        connect(closeButton, &QPushButton::clicked, &dialog, &QDialog::accept);
        dialog.exec();
    });

    connect(addNewsButton, &QPushButton::clicked, this, [this]() {
        QDialog dialog(this);
        dialog.setObjectName("AdminDialog");
        dialog.setWindowTitle("Добавление новости");
        dialog.resize(760, 620);

        QStringList newsPhotos;

        auto* layout = new QVBoxLayout(&dialog);
        layout->setContentsMargins(22, 22, 22, 22);
        layout->setSpacing(14);

        auto* header = new QFrame(&dialog);
        header->setObjectName("HeroCard");
        auto* headerLayout = new QVBoxLayout(header);
        headerLayout->setContentsMargins(22, 16, 22, 16);
        auto* titleLabel = new QLabel("📰 Новая новость", header);
        titleLabel->setObjectName("HeroTitle");
        auto* subtitleLabel = new QLabel("Заполните заголовок, текст новости и добавьте до двух изображений. Логика похожа на добавление фотографий у заведений.", header);
        subtitleLabel->setObjectName("HeroSubtitle");
        subtitleLabel->setWordWrap(true);
        headerLayout->addWidget(titleLabel);
        headerLayout->addWidget(subtitleLabel);
        layout->addWidget(header);

        auto* formBox = new QGroupBox("📝 Содержание новости", &dialog);
        auto* form = new QFormLayout(formBox);
        auto* titleEdit = new QLineEdit(formBox);
        auto* textEdit = new QTextEdit(formBox);
        titleEdit->setPlaceholderText("Например: Новая доступная зона отдыха");
        textEdit->setPlaceholderText("Введите подробный текст новости");
        textEdit->setMinimumHeight(150);
        form->addRow("Заголовок", titleEdit);
        form->addRow("Текст", textEdit);
        layout->addWidget(formBox);

        auto* photosBox = new QGroupBox("🖼️ Картинки новости", &dialog);
        auto* photosLayout = new QVBoxLayout(photosBox);
        auto* infoLabel = new QLabel("Картинки: 0 / 2", photosBox);
        infoLabel->setObjectName("HintLabel");
        auto* photosList = new QListWidget(photosBox);
        photosList->setObjectName("PhotoList");
        photosList->setMinimumHeight(100);
        auto* photoButtons = new QHBoxLayout();
        auto* addPhoto = new QPushButton("➕ Добавить картинку", photosBox);
        auto* removePhoto = new QPushButton("🗑️ Удалить картинку", photosBox);
        makeSecondary(addPhoto);
        makeGhost(removePhoto);
        removePhoto->setEnabled(false);
        photoButtons->addWidget(addPhoto);
        photoButtons->addWidget(removePhoto);
        photoButtons->addStretch(1);
        photosLayout->addWidget(infoLabel);
        photosLayout->addWidget(photosList);
        photosLayout->addLayout(photoButtons);
        layout->addWidget(photosBox);

        auto updateNewsPhotos = [&]() {
            infoLabel->setText("Картинки: " + QString::number(photosList->count()) + " / 2");
            removePhoto->setEnabled(photosList->currentRow() >= 0);
            addPhoto->setEnabled(photosList->count() < 2);
        };

        connect(photosList, &QListWidget::itemSelectionChanged, &dialog, updateNewsPhotos);
        connect(addPhoto, &QPushButton::clicked, &dialog, [&]() {
            const int remaining = 2 - photosList->count();
            if (remaining <= 0) {
                QMessageBox::information(&dialog, "Картинки", "Для одной новости можно добавить не больше двух картинок.");
                return;
            }
            const QStringList files = QFileDialog::getOpenFileNames(&dialog, "Выберите картинки новости", QString(), "Изображения (*.png *.jpg *.jpeg *.bmp *.gif *.webp)");
            int added = 0;
            for (const QString& file : files) {
                if (added >= remaining) break;
                QString error;
                const QString importedPath = Database::instance().importPhotoToStorage(file, &error);
                if (importedPath.isEmpty()) {
                    QMessageBox::warning(&dialog, "Ошибка добавления картинки", error);
                    continue;
                }
                auto* item = new QListWidgetItem(photoDisplayText(importedPath), photosList);
                item->setData(Qt::UserRole, importedPath);
                item->setToolTip(importedPath);
                ++added;
            }
            updateNewsPhotos();
        });
        connect(removePhoto, &QPushButton::clicked, &dialog, [&]() {
            const int row = photosList->currentRow();
            if (row >= 0) {
                delete photosList->takeItem(row);
            }
            updateNewsPhotos();
        });

        auto* actions = new QHBoxLayout();
        auto* cancelButton = new QPushButton("↩️ Отмена", &dialog);
        auto* saveNewsButton = new QPushButton("💾 Сохранить новость", &dialog);
        makeGhost(cancelButton);
        makePrimary(saveNewsButton);
        actions->addWidget(cancelButton);
        actions->addStretch(1);
        actions->addWidget(saveNewsButton);
        layout->addLayout(actions);

        connect(cancelButton, &QPushButton::clicked, &dialog, &QDialog::reject);
        connect(saveNewsButton, &QPushButton::clicked, &dialog, [&]() {
            const QString newsTitle = titleEdit->text().trimmed();
            const QString newsText = textEdit->toPlainText().trimmed();
            if (newsTitle.isEmpty() || newsText.isEmpty()) {
                QMessageBox::warning(&dialog, "Новости", "Заполните заголовок и текст новости.");
                return;
            }

            QStringList paths;
            for (int i = 0; i < photosList->count(); ++i) {
                paths << photosList->item(i)->data(Qt::UserRole).toString();
            }

            QString error;
            if (!Database::instance().addNews(newsTitle, newsText, paths.value(0), paths.value(1), &error)) {
                QMessageBox::warning(&dialog, "Ошибка", error);
                return;
            }
            QMessageBox::information(&dialog, "Новости", "Новость сохранена.");
            dialog.accept();
        });

        dialog.exec();
    });
    connect(newButton, &QPushButton::clicked, this, &AdminDialog::clearForm);
    connect(deleteButton, &QPushButton::clicked, this, &AdminDialog::deletePlace);
    connect(addPhotoButton, &QPushButton::clicked, this, &AdminDialog::addPhoto);
    connect(m_removePhotoButton, &QPushButton::clicked, this, &AdminDialog::removePhoto);
    connect(m_photoUpButton, &QPushButton::clicked, this, &AdminDialog::movePhotoUp);
    connect(m_photoDownButton, &QPushButton::clicked, this, &AdminDialog::movePhotoDown);
    connect(saveButton, &QPushButton::clicked, this, &AdminDialog::savePlace);
    connect(closeButton, &QPushButton::clicked, this, &AdminDialog::accept);
    connect(m_photosList, &QListWidget::itemSelectionChanged, this, &AdminDialog::updatePhotoInfo);
}

void AdminDialog::loadData()
{
    m_loading = true;

    QString error;
    m_categories = Database::instance().categories(&error);
    if (!error.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", error);
    }

    m_categoryCombo->clear();
    for (const auto& category : m_categories) {
        m_categoryCombo->addItem(category.second, category.first);
    }

    AccessibilityFilters emptyFilters;
    m_places = Database::instance().places(emptyFilters, 0, QString(), &error);
    if (!error.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", error);
    }

    m_placeList->clear();
    for (const Place& place : m_places) {
        auto* item = new QListWidgetItem(place.name + "  ·  " + place.categoryName, m_placeList);
        item->setData(Qt::UserRole, place.id);
    }

    m_loading = false;

    if (m_placeList->count() > 0) {
        m_placeList->setCurrentRow(0);
    } else {
        clearForm();
    }
}

void AdminDialog::loadSelectedPlace()
{
    if (m_loading) {
        return;
    }

    if (m_placeList->selectedItems().isEmpty()) {
        return;
    }

    QListWidgetItem* item = m_placeList->currentItem();
    if (item == nullptr) {
        return;
    }

    const int placeId = item->data(Qt::UserRole).toInt();
    Place place;
    QString error;
    if (!Database::instance().placeById(placeId, &place, &error)) {
        QMessageBox::warning(this, "Ошибка", error);
        return;
    }

    m_currentPlaceId = place.id;
    m_formTitleLabel->setText("Редактирование: " + place.name);
    m_nameEdit->setText(place.name);
    setCategoryById(place.categoryId);
    m_addressEdit->setText(place.address);
    m_phoneEdit->setText(place.phone);
    m_descriptionEdit->setPlainText(place.description);

    m_rampCheck->setChecked(place.hasRamp);
    m_elevatorCheck->setChecked(place.hasElevator);
    m_toiletCheck->setChecked(place.hasAccessibleToilet);
    m_quietCheck->setChecked(place.hasQuietPlace);
    m_visualCheck->setChecked(place.hasVisualSupport);
    m_staffCheck->setChecked(place.hasTrainedStaff);
    m_pictureMenuCheck->setChecked(place.hasPictureMenu);
    m_assistantCheck->setChecked(place.allowsAssistant);

    m_photosList->clear();
    const QStringList photos = Database::instance().placePhotos(place.id, &error);
    if (!error.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", error);
    }
    for (const QString& photo : photos) {
        auto* photoItem = new QListWidgetItem(photoDisplayText(photo), m_photosList);
        photoItem->setData(Qt::UserRole, photo);
        photoItem->setToolTip(photo);
    }
    updatePhotoInfo();
}

void AdminDialog::clearForm()
{
    m_currentPlaceId = -1;
    const bool oldLoading = m_loading;
    m_loading = true;
    m_placeList->clearSelection();
    m_placeList->setCurrentRow(-1);
    m_loading = oldLoading;

    m_formTitleLabel->setText("➕ Новое заведение");
    m_nameEdit->clear();
    if (m_categoryCombo->count() > 0) {
        m_categoryCombo->setCurrentIndex(0);
    }
    m_addressEdit->clear();
    m_phoneEdit->clear();
    m_descriptionEdit->clear();

    m_rampCheck->setChecked(false);
    m_elevatorCheck->setChecked(false);
    m_toiletCheck->setChecked(false);
    m_quietCheck->setChecked(false);
    m_visualCheck->setChecked(false);
    m_staffCheck->setChecked(false);
    m_pictureMenuCheck->setChecked(false);
    m_assistantCheck->setChecked(false);

    m_photosList->clear();
    updatePhotoInfo();
}

void AdminDialog::selectPlaceById(int placeId)
{
    for (int row = 0; row < m_placeList->count(); ++row) {
        QListWidgetItem* item = m_placeList->item(row);
        if (item != nullptr && item->data(Qt::UserRole).toInt() == placeId) {
            m_placeList->setCurrentRow(row);
            return;
        }
    }
}

Place AdminDialog::collectPlace() const
{
    Place place;
    place.id = m_currentPlaceId;
    place.name = m_nameEdit->text().trimmed();
    place.categoryId = m_categoryCombo->currentData().toInt();
    place.address = m_addressEdit->text().trimmed();
    place.phone = m_phoneEdit->text().trimmed();
    place.description = m_descriptionEdit->toPlainText().trimmed();
    place.hasRamp = m_rampCheck->isChecked();
    place.hasElevator = m_elevatorCheck->isChecked();
    place.hasAccessibleToilet = m_toiletCheck->isChecked();
    place.hasQuietPlace = m_quietCheck->isChecked();
    place.hasVisualSupport = m_visualCheck->isChecked();
    place.hasTrainedStaff = m_staffCheck->isChecked();
    place.hasPictureMenu = m_pictureMenuCheck->isChecked();
    place.allowsAssistant = m_assistantCheck->isChecked();
    return place;
}

QStringList AdminDialog::collectPhotoPaths() const
{
    QStringList result;
    for (int i = 0; i < m_photosList->count(); ++i) {
        const QListWidgetItem* item = m_photosList->item(i);
        if (item != nullptr) {
            result << item->data(Qt::UserRole).toString();
        }
    }
    return result;
}

void AdminDialog::setCategoryById(int categoryId)
{
    const int index = m_categoryCombo->findData(categoryId);
    if (index >= 0) {
        m_categoryCombo->setCurrentIndex(index);
    }
}

void AdminDialog::updatePhotoInfo()
{
    const int count = m_photosList->count();
    m_photoInfoLabel->setText("Фото: " + QString::number(count) + " / 10");

    const bool hasSelection = m_photosList->currentRow() >= 0;
    m_removePhotoButton->setEnabled(hasSelection);
    m_photoUpButton->setEnabled(hasSelection && m_photosList->currentRow() > 0);
    m_photoDownButton->setEnabled(hasSelection && m_photosList->currentRow() < count - 1);
}

void AdminDialog::addPhoto()
{
    const int remaining = 10 - m_photosList->count();
    if (remaining <= 0) {
        QMessageBox::information(this, "Фотографии", "Для одного заведения можно добавить не больше 10 фотографий.");
        return;
    }

    const QStringList files = QFileDialog::getOpenFileNames(
        this,
        "Выберите фотографии заведения",
        QString(),
        "Изображения (*.png *.jpg *.jpeg *.bmp *.gif *.webp)"
    );
    if (files.isEmpty()) {
        return;
    }

    int added = 0;
    for (const QString& file : files) {
        if (added >= remaining) {
            break;
        }

        QString error;
        const QString importedPath = Database::instance().importPhotoToStorage(file, &error);
        if (importedPath.isEmpty()) {
            QMessageBox::warning(this, "Ошибка добавления фото", error);
            continue;
        }

        auto* item = new QListWidgetItem(photoDisplayText(importedPath), m_photosList);
        item->setData(Qt::UserRole, importedPath);
        item->setToolTip(importedPath);
        ++added;
    }

    if (files.size() > remaining) {
        QMessageBox::information(this, "Фотографии", "Часть файлов не добавлена, потому что лимит составляет 10 фотографий.");
    }

    updatePhotoInfo();
}

void AdminDialog::removePhoto()
{
    const int row = m_photosList->currentRow();
    if (row < 0) {
        return;
    }

    delete m_photosList->takeItem(row);
    if (m_photosList->count() > 0) {
        m_photosList->setCurrentRow(qMin(row, m_photosList->count() - 1));
    }
    updatePhotoInfo();
}

void AdminDialog::movePhotoUp()
{
    const int row = m_photosList->currentRow();
    if (row <= 0) {
        return;
    }

    QListWidgetItem* item = m_photosList->takeItem(row);
    m_photosList->insertItem(row - 1, item);
    m_photosList->setCurrentRow(row - 1);
    updatePhotoInfo();
}

void AdminDialog::movePhotoDown()
{
    const int row = m_photosList->currentRow();
    if (row < 0 || row >= m_photosList->count() - 1) {
        return;
    }

    QListWidgetItem* item = m_photosList->takeItem(row);
    m_photosList->insertItem(row + 1, item);
    m_photosList->setCurrentRow(row + 1);
    updatePhotoInfo();
}

void AdminDialog::savePlace()
{
    Place place = collectPlace();
    QString error;
    int savedPlaceId = place.id;

    bool ok = false;
    if (place.id <= 0) {
        ok = Database::instance().addPlace(place, collectPhotoPaths(), &savedPlaceId, &error);
    } else {
        ok = Database::instance().updatePlace(place, collectPhotoPaths(), &error);
    }

    if (!ok) {
        QMessageBox::warning(this, "Ошибка сохранения", error);
        return;
    }

    QMessageBox::information(this, "Готово", "Информация о заведении сохранена.");
    loadData();
    selectPlaceById(savedPlaceId);
}

void AdminDialog::deletePlace()
{
    if (m_currentPlaceId <= 0) {
        QMessageBox::information(this, "Удаление", "Выберите заведение для удаления.");
        return;
    }

    const QString placeName = m_nameEdit->text().trimmed();
    const auto answer = QMessageBox::question(
        this,
        "Удаление заведения",
        "Удалить заведение \"" + placeName + "\"? Это действие нельзя отменить."
    );
    if (answer != QMessageBox::Yes) {
        return;
    }

    QString error;
    if (!Database::instance().deletePlace(m_currentPlaceId, &error)) {
        QMessageBox::warning(this, "Ошибка удаления", error);
        return;
    }

    QMessageBox::information(this, "Готово", "Заведение удалено.");
    loadData();
}
