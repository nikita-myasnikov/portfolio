#include "placedetailsdialog.h"

#include "database.h"

#include <QColor>
#include <QCursor>
#include <QDialogButtonBox>
#include <QFrame>
#include <QGraphicsDropShadowEffect>
#include <QHBoxLayout>
#include <QLabel>
#include <QPixmap>
#include <QPushButton>
#include <QResizeEvent>
#include <QTextBrowser>
#include <QTimer>
#include <QVBoxLayout>

namespace
{
void addSoftShadow(QWidget* widget)
{
    auto* shadow = new QGraphicsDropShadowEffect(widget);
    shadow->setBlurRadius(24);
    shadow->setOffset(0, 8);
    shadow->setColor(QColor(15, 23, 42, 28));
    widget->setGraphicsEffect(shadow);
}

QString statusBadge(bool value)
{
    if (value) {
        return "<span class='badge badge-yes'>Да</span>";
    }
    return "<span class='badge badge-no'>Нет</span>";
}

QString featureRow(const QString& title, bool value)
{
    const QString icon = value ? "✓" : "—";
    const QString iconClass = value ? "icon icon-yes" : "icon icon-no";
    return QString(
        "<tr>"
        "<td class='%1'>%2</td>"
        "<td>%3</td>"
        "<td class='status'>%4</td>"
        "</tr>"
    ).arg(iconClass, icon, title.toHtmlEscaped(), statusBadge(value));
}
}

PlaceDetailsDialog::PlaceDetailsDialog(const Place& place, QWidget* parent)
    : QDialog(parent)
    , m_photoPaths(place.photoPaths)
{
    setWindowTitle("Карточка места");
    setObjectName("DetailsDialog");
    resize(860, 780);
    setMinimumSize(720, 640);

    if (m_photoPaths.isEmpty() && place.id > 0) {
        m_photoPaths = Database::instance().placePhotos(place.id, nullptr);
    }

    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(26, 26, 26, 26);
    layout->setSpacing(14);

    auto* card = new QFrame(this);
    card->setObjectName("AuthCard");
    addSoftShadow(card);
    layout->addWidget(card, 1);

    auto* cardLayout = new QVBoxLayout(card);
    cardLayout->setContentsMargins(18, 18, 18, 18);
    cardLayout->setSpacing(12);

    auto* galleryCard = new QFrame(card);
    galleryCard->setObjectName("PhotoGalleryCard");
    auto* galleryLayout = new QVBoxLayout(galleryCard);
    galleryLayout->setContentsMargins(14, 14, 14, 14);
    galleryLayout->setSpacing(10);

    m_photoLabel = new QLabel(galleryCard);
    m_photoLabel->setObjectName("GalleryPhoto");
    m_photoLabel->setAlignment(Qt::AlignCenter);
    m_photoLabel->setMinimumHeight(260);
    m_photoLabel->setWordWrap(true);
    galleryLayout->addWidget(m_photoLabel, 1);

    auto* galleryControls = new QHBoxLayout();
    galleryControls->setContentsMargins(0, 0, 0, 0);
    m_prevPhotoButton = new QPushButton("⬅️ Предыдущее", galleryCard);
    m_nextPhotoButton = new QPushButton("Следующее ➡️", galleryCard);
    m_photoCounterLabel = new QLabel(galleryCard);
    m_photoCounterLabel->setObjectName("PhotoCounter");
    m_photoCounterLabel->setAlignment(Qt::AlignCenter);
    m_prevPhotoButton->setProperty("class", "SecondaryButton");
    m_nextPhotoButton->setProperty("class", "SecondaryButton");
    m_prevPhotoButton->setCursor(Qt::PointingHandCursor);
    m_nextPhotoButton->setCursor(Qt::PointingHandCursor);
    galleryControls->addWidget(m_prevPhotoButton);
    galleryControls->addStretch(1);
    galleryControls->addWidget(m_photoCounterLabel);
    galleryControls->addStretch(1);
    galleryControls->addWidget(m_nextPhotoButton);
    galleryLayout->addLayout(galleryControls);
    cardLayout->addWidget(galleryCard, 0);

    auto* browser = new QTextBrowser(card);
    browser->setOpenExternalLinks(false);
    browser->setFrameShape(QFrame::NoFrame);

    QString description = place.description.toHtmlEscaped();
    description.replace("\n", "<br>");

    QString html;
    html += "<html><head><meta charset='UTF-8'><style>";
    html += "body{font-family:'Segoe UI',Arial,sans-serif;margin:0;background:#ffffff;color:#102033;}";
    html += ".hero{background-color:#0f766e;border-radius:18px;padding:22px 24px;color:white;}";
    html += "h1{margin:0 0 8px 0;font-size:28px;color:white;}";
    html += ".category{display:inline-block;background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.34);border-radius:999px;padding:7px 12px;font-weight:700;color:white;}";
    html += ".section{background:#f8fafc;border:1px solid #dbe7f3;border-radius:16px;padding:16px 18px;margin-top:14px;}";
    html += "h2{font-size:18px;margin:0 0 10px 0;color:#0f172a;}";
    html += "p{font-size:14px;line-height:1.55;margin:6px 0;color:#334155;}";
    html += "table{border-collapse:separate;border-spacing:0;width:100%;font-size:14px;background:white;border:1px solid #dbe7f3;border-radius:14px;overflow:hidden;}";
    html += "td{padding:11px 12px;border-bottom:1px solid #edf2f7;color:#334155;}";
    html += "tr:last-child td{border-bottom:none;}";
    html += ".status{text-align:right;width:90px;}";
    html += ".icon{width:28px;text-align:center;font-weight:900;font-size:16px;}";
    html += ".icon-yes{color:#047857;} .icon-no{color:#94a3b8;}";
    html += ".badge{display:inline-block;border-radius:999px;padding:5px 10px;font-weight:800;}";
    html += ".badge-yes{background:#dcfce7;color:#166534;} .badge-no{background:#fee2e2;color:#991b1b;}";
    html += "</style></head><body>";

    html += QString(
        "<div class='hero'>"
        "<h1>%1</h1>"
        "<span class='category'>%2</span>"
        "</div>"
    ).arg(place.name.toHtmlEscaped(), place.categoryName.toHtmlEscaped());

    html += "<div class='section'>";
    html += "<h2>Основная информация</h2>";
    html += QString("<p><b>Адрес:</b> %1</p>").arg(place.address.toHtmlEscaped());
    html += QString("<p><b>Телефон:</b> %1</p>").arg(place.phone.toHtmlEscaped());
    html += QString("<p><b>Описание:</b><br>%1</p>").arg(description);
    html += "</div>";

    html += "<div class='section'>";
    html += "<h2>Условия доступности</h2>";
    html += "<table>";
    html += featureRow("Пандус / безбарьерный вход", place.hasRamp);
    html += featureRow("Лифт", place.hasElevator);
    html += featureRow("Доступный туалет", place.hasAccessibleToilet);
    html += featureRow("Тихая зона", place.hasQuietPlace);
    html += featureRow("Визуальные подсказки", place.hasVisualSupport);
    html += featureRow("Обученный персонал", place.hasTrainedStaff);
    html += featureRow("Меню с картинками", place.hasPictureMenu);
    html += featureRow("Возможность сопровождения", place.allowsAssistant);
    html += "</table>";
    html += "</div>";
    html += "</body></html>";

    browser->setHtml(html);
    cardLayout->addWidget(browser, 1);

    auto* buttons = new QDialogButtonBox(this);
    auto* closeButton = buttons->addButton("Закрыть", QDialogButtonBox::AcceptRole);
    closeButton->setProperty("class", "PrimaryButton");
    closeButton->setCursor(Qt::PointingHandCursor);
    connect(closeButton, &QPushButton::clicked, this, &PlaceDetailsDialog::accept);
    layout->addWidget(buttons);

    connect(m_prevPhotoButton, &QPushButton::clicked, this, &PlaceDetailsDialog::showPreviousPhoto);
    connect(m_nextPhotoButton, &QPushButton::clicked, this, &PlaceDetailsDialog::showNextPhoto);

    QTimer::singleShot(0, this, [this]() { showCurrentPhoto(); });
}

void PlaceDetailsDialog::resizeEvent(QResizeEvent* event)
{
    QDialog::resizeEvent(event);
    showCurrentPhoto();
}

void PlaceDetailsDialog::showCurrentPhoto()
{
    if (m_photoLabel == nullptr || m_photoCounterLabel == nullptr) {
        return;
    }

    const int count = m_photoPaths.size();
    if (count == 0) {
        m_photoLabel->setPixmap(QPixmap());
        m_photoLabel->setText("Фотографии для этого заведения пока не добавлены");
        m_photoCounterLabel->setText("0 / 0");
        m_prevPhotoButton->setEnabled(false);
        m_nextPhotoButton->setEnabled(false);
        return;
    }

    if (m_currentPhotoIndex < 0 || m_currentPhotoIndex >= count) {
        m_currentPhotoIndex = 0;
    }

    const QString path = m_photoPaths.at(m_currentPhotoIndex);
    QPixmap photo(path);
    if (photo.isNull()) {
        m_photoLabel->setPixmap(QPixmap());
        m_photoLabel->setText("Не удалось загрузить фото:\n" + path);
    } else {
        QSize targetSize = m_photoLabel->size() - QSize(8, 8);
        if (targetSize.width() < 20 || targetSize.height() < 20) {
            targetSize = QSize(640, 260);
        }
        m_photoLabel->setText(QString());
        m_photoLabel->setPixmap(photo.scaled(targetSize, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    }

    m_photoCounterLabel->setText(QString::number(m_currentPhotoIndex + 1) + " / " + QString::number(count));
    m_prevPhotoButton->setEnabled(count > 1);
    m_nextPhotoButton->setEnabled(count > 1);
}

void PlaceDetailsDialog::showPreviousPhoto()
{
    if (m_photoPaths.isEmpty()) {
        return;
    }

    m_currentPhotoIndex = (m_currentPhotoIndex - 1 + m_photoPaths.size()) % m_photoPaths.size();
    showCurrentPhoto();
}

void PlaceDetailsDialog::showNextPhoto()
{
    if (m_photoPaths.isEmpty()) {
        return;
    }

    m_currentPhotoIndex = (m_currentPhotoIndex + 1) % m_photoPaths.size();
    showCurrentPhoto();
}
