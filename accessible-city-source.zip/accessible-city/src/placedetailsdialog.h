#ifndef PLACEDETAILSDIALOG_H
#define PLACEDETAILSDIALOG_H

#include <QDialog>
#include <QStringList>

#include "models.h"

class QLabel;
class QPushButton;
class QResizeEvent;

class PlaceDetailsDialog : public QDialog
{
    Q_OBJECT

public:
    explicit PlaceDetailsDialog(const Place& place, QWidget* parent = nullptr);

protected:
    void resizeEvent(QResizeEvent* event) override;

private:
    void showCurrentPhoto();
    void showPreviousPhoto();
    void showNextPhoto();

    QStringList m_photoPaths;
    int m_currentPhotoIndex = 0;
    QLabel* m_photoLabel = nullptr;
    QLabel* m_photoCounterLabel = nullptr;
    QPushButton* m_prevPhotoButton = nullptr;
    QPushButton* m_nextPhotoButton = nullptr;
};

#endif // PLACEDETAILSDIALOG_H
