#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVector>
#include <QString>

#include "models.h"

class QCheckBox;
class QLabel;
class QLineEdit;
class QListWidget;
class QPushButton;
class QTableWidget;
class QTabWidget;
class QTextEdit;
class QProcess;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(const UserProfile& user, QWidget* parent = nullptr);

private:
    void setupUi();
    void loadCategories();
    void refreshPlaces();
    void applyUserNeeds();
    void resetFilters();
    void openSelectedPlace();
    void openAdminPanel();
    void refreshNews();
    void saveProfile();
    void logout();
    void speakCurrentText();
    QString textForSpeech() const;
    void applyAccessibilityStyle(const QString& colorMode = QString());

    AccessibilityFilters currentFilters() const;
    int currentCategoryId() const;
    int calculateMatchPercent(const Place& place) const;
    QString featuresSummary(const Place& place) const;
    QVector<QCheckBox*> filterBoxes() const;
    void setItemReadOnly(int row, int column, const QString& text);

    UserProfile m_user;
    QVector<Place> m_places;

    QLabel* m_userLabel = nullptr;
    QLabel* m_resultLabel = nullptr;
    QListWidget* m_categoryList = nullptr;
    QLineEdit* m_searchEdit = nullptr;
    QTableWidget* m_table = nullptr;
    QPushButton* m_detailsButton = nullptr;
    QPushButton* m_adminButton = nullptr;
    QTabWidget* m_tabs = nullptr;
    QTextEdit* m_newsView = nullptr;
    QLineEdit* m_profileNameEdit = nullptr;
    QLineEdit* m_profilePasswordEdit = nullptr;
    QString m_colorMode = "Обычный режим";
    int m_accessFontSize = 15;
    bool m_voiceEnabled = false;
    QPushButton* m_speakButton = nullptr;
    QPushButton* m_quickSpeakButton = nullptr;
    QProcess* m_speechProcess = nullptr;

    QCheckBox* m_profileRampCheck = nullptr;
    QCheckBox* m_profileElevatorCheck = nullptr;
    QCheckBox* m_profileToiletCheck = nullptr;
    QCheckBox* m_profileQuietCheck = nullptr;
    QCheckBox* m_profileVisualCheck = nullptr;
    QCheckBox* m_profileStaffCheck = nullptr;
    QCheckBox* m_profilePictureMenuCheck = nullptr;
    QCheckBox* m_profileAssistantCheck = nullptr;

    QCheckBox* m_rampCheck = nullptr;
    QCheckBox* m_elevatorCheck = nullptr;
    QCheckBox* m_toiletCheck = nullptr;
    QCheckBox* m_quietCheck = nullptr;
    QCheckBox* m_visualCheck = nullptr;
    QCheckBox* m_staffCheck = nullptr;
    QCheckBox* m_pictureMenuCheck = nullptr;
    QCheckBox* m_assistantCheck = nullptr;
};

#endif // MAINWINDOW_H
