#ifndef ADMINDIALOG_H
#define ADMINDIALOG_H

#include <QDialog>
#include <QVector>

#include "models.h"

class QCheckBox;
class QComboBox;
class QLabel;
class QLineEdit;
class QListWidget;
class QPushButton;
class QTextEdit;

class AdminDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AdminDialog(const UserProfile& currentUser, QWidget* parent = nullptr);

private:
    void setupUi();
    void loadData();
    void loadSelectedPlace();
    void clearForm();
    void selectPlaceById(int placeId);

    Place collectPlace() const;
    QStringList collectPhotoPaths() const;
    void setCategoryById(int categoryId);
    void updatePhotoInfo();

    void addPhoto();
    void removePhoto();
    void movePhotoUp();
    void movePhotoDown();
    void savePlace();
    void deletePlace();

    UserProfile m_currentUser;
    QVector<Place> m_places;
    QVector<QPair<int, QString>> m_categories;
    bool m_loading = false;
    int m_currentPlaceId = -1;

    QListWidget* m_placeList = nullptr;
    QLabel* m_formTitleLabel = nullptr;
    QLabel* m_photoInfoLabel = nullptr;

    QLineEdit* m_nameEdit = nullptr;
    QComboBox* m_categoryCombo = nullptr;
    QLineEdit* m_addressEdit = nullptr;
    QLineEdit* m_phoneEdit = nullptr;
    QTextEdit* m_descriptionEdit = nullptr;

    QCheckBox* m_rampCheck = nullptr;
    QCheckBox* m_elevatorCheck = nullptr;
    QCheckBox* m_toiletCheck = nullptr;
    QCheckBox* m_quietCheck = nullptr;
    QCheckBox* m_visualCheck = nullptr;
    QCheckBox* m_staffCheck = nullptr;
    QCheckBox* m_pictureMenuCheck = nullptr;
    QCheckBox* m_assistantCheck = nullptr;

    QListWidget* m_photosList = nullptr;
    QPushButton* m_removePhotoButton = nullptr;
    QPushButton* m_photoUpButton = nullptr;
    QPushButton* m_photoDownButton = nullptr;
};

#endif // ADMINDIALOG_H
