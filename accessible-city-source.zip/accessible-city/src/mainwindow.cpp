#include "mainwindow.h"

#include "admindialog.h"
#include "database.h"
#include "placedetailsdialog.h"
#include "loginwindow.h"

#include <QAbstractItemView>
#include <QApplication>
#include <QBrush>
#include <QCheckBox>
#include <QColor>
#include <QCursor>
#include <QDialog>
#include <QFont>
#include <QFrame>
#include <QGraphicsDropShadowEffect>
#include <QGridLayout>
#include <QGroupBox>
#include <QHeaderView>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMessageBox>
#include <QPushButton>
#include <QProcess>
#include <QSignalBlocker>
#include <QSplitter>
#include <QStatusBar>
#include <QStringList>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QTabWidget>
#include <QTextEdit>
#include <QScrollArea>
#include <QFormLayout>
#include <QSlider>
#include <QComboBox>
#include <QtAlgorithms>
#include <QVBoxLayout>
#include <algorithm>

namespace
{
void addSoftShadow(QWidget* widget)
{
    auto* shadow = new QGraphicsDropShadowEffect(widget);
    shadow->setBlurRadius(26);
    shadow->setOffset(0, 8);
    shadow->setColor(QColor(15, 23, 42, 24));
    widget->setGraphicsEffect(shadow);
}

QLabel* sectionLabel(const QString& text, QWidget* parent)
{
    auto* label = new QLabel(text, parent);
    label->setObjectName("SectionTitle");
    return label;
}

void makeButtonPrimary(QPushButton* button)
{
    button->setProperty("class", "PrimaryButton");
    button->setCursor(Qt::PointingHandCursor);
}

void makeButtonSecondary(QPushButton* button)
{
    button->setProperty("class", "SecondaryButton");
    button->setCursor(Qt::PointingHandCursor);
}
}

MainWindow::MainWindow(const UserProfile& user, QWidget* parent)
    : QMainWindow(parent)
    , m_user(user)
{
    setupUi();
    loadCategories();
    refreshPlaces();
    refreshNews();
    statusBar()->hide();
}

void MainWindow::setupUi()
{
    setWindowTitle("Мы разам! — каталог доступных мест");
    resize(1180, 760);
    setMinimumSize(980, 650);

    auto* central = new QWidget(this);
    central->setObjectName("MainRoot");
    auto* rootLayout = new QHBoxLayout(central);
    rootLayout->setContentsMargins(18, 18, 18, 18);
    rootLayout->setSpacing(0);

    auto* splitter = new QSplitter(Qt::Horizontal, central);
    splitter->setChildrenCollapsible(false);
    splitter->setHandleWidth(10);
    rootLayout->addWidget(splitter);
    setCentralWidget(central);

    auto* leftPanel = new QFrame(splitter);
    leftPanel->setObjectName("SidePanel");
    leftPanel->setMinimumWidth(270);
    leftPanel->setMaximumWidth(340);
    addSoftShadow(leftPanel);

    auto* leftLayout = new QVBoxLayout(leftPanel);
    leftLayout->setContentsMargins(20, 22, 20, 22);
    leftLayout->setSpacing(16);

    auto* brandLayout = new QHBoxLayout();
    brandLayout->setSpacing(12);

    auto* logo = new QLabel("🏙️", leftPanel);
    logo->setObjectName("LogoSmall");
    logo->setFixedSize(44, 44);
    logo->setAlignment(Qt::AlignCenter);
    brandLayout->addWidget(logo);

    auto* brandTextLayout = new QVBoxLayout();
    brandTextLayout->setContentsMargins(0, 0, 0, 0);
    brandTextLayout->setSpacing(0);
    auto* brandTitle = new QLabel("Мы разам!", leftPanel);
    brandTitle->setObjectName("BrandTitle");
    auto* brandSub = new QLabel("✨ инклюзивный справочник", leftPanel);
    brandSub->setObjectName("HintLabel");
    brandTextLayout->addWidget(brandTitle);
    brandTextLayout->addWidget(brandSub);
    brandLayout->addLayout(brandTextLayout, 1);
    leftLayout->addLayout(brandLayout);

    m_userLabel = new QLabel(leftPanel);
    m_userLabel->setObjectName("UserBadge");
    m_userLabel->setWordWrap(true);
    const QString roleText = m_user.isAdmin ? "Администратор системы" : "Профиль потребностей активен";
    m_userLabel->setText(
        "Здравствуйте, <b>" + m_user.name.toHtmlEscaped() + "</b><br>"
        "<span style='color:#64748b; font-weight:400;'>" + roleText + "</span>"
    );
    leftLayout->addWidget(m_userLabel);

    leftLayout->addWidget(sectionLabel("📌 Разделы", leftPanel));

    m_categoryList = new QListWidget(leftPanel);
    m_categoryList->setObjectName("CategoryList");
    m_categoryList->setSpacing(3);
    m_categoryList->setSelectionMode(QAbstractItemView::SingleSelection);
    leftLayout->addWidget(m_categoryList, 1);

    auto* needsButton = new QPushButton("🎯 Подобрать под мои потребности", leftPanel);
    auto* resetButton = new QPushButton("🔄 Сбросить фильтры", leftPanel);
    makeButtonPrimary(needsButton);
    makeButtonSecondary(resetButton);
    leftLayout->addWidget(needsButton);
    leftLayout->addWidget(resetButton);

    m_quickSpeakButton = new QPushButton("🔊 Озвучить экран", leftPanel);
    makeButtonSecondary(m_quickSpeakButton);
    m_quickSpeakButton->setVisible(false);
    leftLayout->addWidget(m_quickSpeakButton);

    if (m_user.isAdmin) {
        m_adminButton = new QPushButton("⚙️ Админ-панель", leftPanel);
        makeButtonSecondary(m_adminButton);
        leftLayout->addWidget(m_adminButton);
    }

    auto* rightPanel = new QFrame(splitter);
    rightPanel->setObjectName("ContentPanel");
    addSoftShadow(rightPanel);

    auto* rightLayout = new QVBoxLayout(rightPanel);
    rightLayout->setContentsMargins(18, 18, 18, 18);
    rightLayout->setSpacing(12);

    m_tabs = new QTabWidget(rightPanel);
    m_tabs->setObjectName("MainTabs");
    rightLayout->addWidget(m_tabs, 1);

    auto* catalogTab = new QWidget(m_tabs);
    auto* catalogLayout = new QVBoxLayout(catalogTab);
    catalogLayout->setContentsMargins(4, 4, 4, 4);
    catalogLayout->setSpacing(16);
    m_tabs->addTab(catalogTab, "🏙️ Каталог");

    auto* hero = new QFrame(catalogTab);
    hero->setObjectName("HeroCard");
    auto* heroLayout = new QHBoxLayout(hero);
    heroLayout->setContentsMargins(28, 22, 28, 22);
    heroLayout->setSpacing(18);

    auto* heroTextLayout = new QVBoxLayout();
    heroTextLayout->setSpacing(6);
    auto* title = new QLabel("🏙️ Каталог доступных мест", hero);
    title->setObjectName("HeroTitle");
    auto* subtitle = new QLabel(
        "Выберите категорию, отметьте нужные условия доступности и откройте карточку подходящего заведения с фотографиями.",
        hero
    );
    subtitle->setObjectName("HeroSubtitle");
    subtitle->setWordWrap(true);
    heroTextLayout->addWidget(title);
    heroTextLayout->addWidget(subtitle);
    heroLayout->addLayout(heroTextLayout, 1);

    auto* heroStat = new QLabel("📂 3 категории\n✅ 8 фильтров\n🖼️ до 10 фото", hero);
    heroStat->setObjectName("HeroStat");
    heroStat->setAlignment(Qt::AlignCenter);
    heroLayout->addWidget(heroStat);
    catalogLayout->addWidget(hero);

    auto* searchCard = new QFrame(rightPanel);
    searchCard->setObjectName("SearchCard");
    auto* searchLayout = new QHBoxLayout(searchCard);
    searchLayout->setContentsMargins(18, 15, 18, 15);
    searchLayout->setSpacing(12);

    auto* searchLabel = sectionLabel("🔎 Поиск", searchCard);
    searchLayout->addWidget(searchLabel);
    m_searchEdit = new QLineEdit(searchCard);
    m_searchEdit->setPlaceholderText("Введите название, адрес или часть описания");
    m_searchEdit->setClearButtonEnabled(true);
    searchLayout->addWidget(m_searchEdit, 1);
    catalogLayout->addWidget(searchCard);

    auto* filtersBox = new QGroupBox("♿ Фильтрация по условиям доступности", rightPanel);
    auto* filtersLayout = new QGridLayout(filtersBox);
    filtersLayout->setHorizontalSpacing(18);
    filtersLayout->setVerticalSpacing(6);

    m_rampCheck = new QCheckBox("♿ Пандус", filtersBox);
    m_elevatorCheck = new QCheckBox("🛗 Лифт", filtersBox);
    m_toiletCheck = new QCheckBox("🚻 Доступный туалет", filtersBox);
    m_quietCheck = new QCheckBox("🤫 Тихая зона", filtersBox);
    m_visualCheck = new QCheckBox("👁️ Визуальные подсказки", filtersBox);
    m_staffCheck = new QCheckBox("🤝 Обученный персонал", filtersBox);
    m_pictureMenuCheck = new QCheckBox("🖼️ Меню с картинками", filtersBox);
    m_assistantCheck = new QCheckBox("🧑‍🦽 Сопровождение", filtersBox);

    filtersLayout->addWidget(m_rampCheck, 0, 0);
    filtersLayout->addWidget(m_elevatorCheck, 0, 1);
    filtersLayout->addWidget(m_toiletCheck, 0, 2);
    filtersLayout->addWidget(m_quietCheck, 0, 3);
    filtersLayout->addWidget(m_visualCheck, 1, 0);
    filtersLayout->addWidget(m_staffCheck, 1, 1);
    filtersLayout->addWidget(m_pictureMenuCheck, 1, 2);
    filtersLayout->addWidget(m_assistantCheck, 1, 3);
    catalogLayout->addWidget(filtersBox);

    m_table = new QTableWidget(rightPanel);
    m_table->setObjectName("PlacesTable");
    m_table->setColumnCount(6);
    m_table->setHorizontalHeaderLabels({"ID", "Название", "Категория", "Адрес", "Возможности", "Совпадение"});
    m_table->setMinimumHeight(260);
    m_table->hideColumn(0);
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::SingleSelection);
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->setAlternatingRowColors(true);
    m_table->setShowGrid(false);
    m_table->setWordWrap(false);
    m_table->setTextElideMode(Qt::ElideRight);
    m_table->verticalHeader()->setVisible(false);
    m_table->verticalHeader()->setDefaultSectionSize(48);
    m_table->horizontalHeader()->setStretchLastSection(false);
    m_table->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
    m_table->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(3, QHeaderView::Stretch);
    m_table->horizontalHeader()->setSectionResizeMode(4, QHeaderView::Stretch);
    m_table->horizontalHeader()->setSectionResizeMode(5, QHeaderView::ResizeToContents);
    catalogLayout->addWidget(m_table, 1);

    auto* bottomLayout = new QHBoxLayout();
    bottomLayout->setContentsMargins(0, 0, 0, 0);
    m_resultLabel = new QLabel("✨ Найдено мест: 0", rightPanel);
    m_resultLabel->setObjectName("SectionTitle");
    m_detailsButton = new QPushButton("📖 Открыть карточку", rightPanel);
    makeButtonPrimary(m_detailsButton);
    bottomLayout->addWidget(m_resultLabel);
    bottomLayout->addStretch();
    bottomLayout->addWidget(m_detailsButton);
    catalogLayout->addLayout(bottomLayout);


    auto* newsTab = new QWidget(m_tabs);
    auto* newsLayout = new QVBoxLayout(newsTab);
    newsLayout->setContentsMargins(12, 12, 12, 12);
    newsLayout->setSpacing(12);
    auto* newsTitle = new QLabel("📰 Новости", newsTab);
    newsTitle->setObjectName("HeroTitle");
    auto* newsHint = new QLabel("📰 Здесь отображаются новости проекта. Администратор добавляет новости через админ-панель.", newsTab);
    newsHint->setObjectName("HeroSubtitle");
    newsHint->setWordWrap(true);
    m_newsView = new QTextEdit(newsTab);
    m_newsView->setObjectName("NewsView");
    m_newsView->setReadOnly(true);
    m_newsView->setMinimumHeight(420);
    newsLayout->addWidget(newsTitle);
    newsLayout->addWidget(newsHint);
    newsLayout->addWidget(m_newsView, 1);
    m_tabs->addTab(newsTab, "📰 Новости");

    auto* profileTab = new QWidget(m_tabs);
    auto* profileLayout = new QVBoxLayout(profileTab);
    profileLayout->setContentsMargins(12, 12, 12, 12);
    profileLayout->setSpacing(16);

    auto* profileHero = new QFrame(profileTab);
    profileHero->setObjectName("ProfileHeroCard");
    auto* profileHeroLayout = new QHBoxLayout(profileHero);
    profileHeroLayout->setContentsMargins(26, 22, 26, 22);
    profileHeroLayout->setSpacing(18);

    auto* avatar = new QLabel(m_user.name.left(1).toUpper(), profileHero);
    avatar->setObjectName("ProfileAvatar");
    avatar->setFixedSize(76, 76);
    avatar->setAlignment(Qt::AlignCenter);
    profileHeroLayout->addWidget(avatar);

    auto* profileHeroText = new QVBoxLayout();
    profileHeroText->setSpacing(4);
    auto* profileTitle = new QLabel("👤 Мой профиль", profileHero);
    profileTitle->setObjectName("ProfileHeroTitle");
    auto* profileSubtitle = new QLabel("Редактируйте имя, пароль и индивидуальные потребности для подбора доступных мест.", profileHero);
    profileSubtitle->setObjectName("ProfileHeroSubtitle");
    profileSubtitle->setWordWrap(true);
    profileHeroText->addWidget(profileTitle);
    profileHeroText->addWidget(profileSubtitle);
    profileHeroLayout->addLayout(profileHeroText, 1);
    profileLayout->addWidget(profileHero);

    auto* profileCardsLayout = new QHBoxLayout();
    profileCardsLayout->setSpacing(16);

    auto* profileBox = new QGroupBox("📝 Личные данные", profileTab);
    profileBox->setObjectName("ProfileCard");
    auto* profileForm = new QFormLayout(profileBox);
    profileForm->setLabelAlignment(Qt::AlignLeft);
    profileForm->setFormAlignment(Qt::AlignTop);
    profileForm->setHorizontalSpacing(18);
    profileForm->setVerticalSpacing(14);
    m_profileNameEdit = new QLineEdit(m_user.name, profileBox);
    m_profilePasswordEdit = new QLineEdit(profileBox);
    m_profilePasswordEdit->setEchoMode(QLineEdit::Password);
    m_profilePasswordEdit->setPlaceholderText("Оставьте пустым, если пароль менять не нужно");
    auto* loginValue = new QLabel(m_user.login, profileBox);
    loginValue->setObjectName("ReadonlyValue");
    profileForm->addRow("Имя", m_profileNameEdit);
    profileForm->addRow("Логин", loginValue);
    profileForm->addRow("Новый пароль", m_profilePasswordEdit);
    profileCardsLayout->addWidget(profileBox, 1);

    auto* needsBox = new QGroupBox("♿ Индивидуальные потребности", profileTab);
    needsBox->setObjectName("ProfileCard");
    auto* needsLayout = new QGridLayout(needsBox);
    needsLayout->setHorizontalSpacing(20);
    needsLayout->setVerticalSpacing(8);
    m_profileRampCheck = new QCheckBox("Безбарьерный вход / пандус", needsBox);
    m_profileElevatorCheck = new QCheckBox("🛗 Лифт", needsBox);
    m_profileToiletCheck = new QCheckBox("🚻 Доступный туалет", needsBox);
    m_profileQuietCheck = new QCheckBox("🤫 Тихая зона", needsBox);
    m_profileVisualCheck = new QCheckBox("👁️ Визуальные подсказки", needsBox);
    m_profileStaffCheck = new QCheckBox("🤝 Обученный персонал", needsBox);
    m_profilePictureMenuCheck = new QCheckBox("🖼️ Меню с картинками", needsBox);
    m_profileAssistantCheck = new QCheckBox("Возможность сопровождения", needsBox);
    m_profileRampCheck->setChecked(m_user.needRamp);
    m_profileElevatorCheck->setChecked(m_user.needElevator);
    m_profileToiletCheck->setChecked(m_user.needAccessibleToilet);
    m_profileQuietCheck->setChecked(m_user.needQuietPlace);
    m_profileVisualCheck->setChecked(m_user.needVisualSupport);
    m_profileStaffCheck->setChecked(m_user.needTrainedStaff);
    m_profilePictureMenuCheck->setChecked(m_user.needPictureMenu);
    m_profileAssistantCheck->setChecked(m_user.needAssistance);
    needsLayout->addWidget(m_profileRampCheck, 0, 0);
    needsLayout->addWidget(m_profileElevatorCheck, 0, 1);
    needsLayout->addWidget(m_profileToiletCheck, 1, 0);
    needsLayout->addWidget(m_profileQuietCheck, 1, 1);
    needsLayout->addWidget(m_profileVisualCheck, 2, 0);
    needsLayout->addWidget(m_profileStaffCheck, 2, 1);
    needsLayout->addWidget(m_profilePictureMenuCheck, 3, 0);
    needsLayout->addWidget(m_profileAssistantCheck, 3, 1);
    profileCardsLayout->addWidget(needsBox, 1);
    profileLayout->addLayout(profileCardsLayout, 1);

    auto* actionsCard = new QFrame(profileTab);
    actionsCard->setObjectName("ProfileActionsCard");
    auto* actionsLayout = new QHBoxLayout(actionsCard);
    actionsLayout->setContentsMargins(18, 14, 18, 14);
    auto* saveProfileButton = new QPushButton("💾 Сохранить профиль", actionsCard);
    auto* logoutButton = new QPushButton("🚪 Выйти из профиля", actionsCard);
    makeButtonPrimary(saveProfileButton);
    makeButtonSecondary(logoutButton);
    actionsLayout->addWidget(saveProfileButton);
    actionsLayout->addWidget(logoutButton);
    actionsLayout->addStretch(1);
    profileLayout->addWidget(actionsCard);
    m_tabs->addTab(profileTab, "👤 Профиль");
    connect(saveProfileButton, &QPushButton::clicked, this, &MainWindow::saveProfile);
    connect(logoutButton, &QPushButton::clicked, this, &MainWindow::logout);

    auto* accessTab = new QWidget(m_tabs);
    auto* accessLayout2 = new QVBoxLayout(accessTab);
    accessLayout2->setContentsMargins(18, 18, 18, 18);
    accessLayout2->setSpacing(14);
    auto* accessTitle = new QLabel("🛠️ Специальные возможности", accessTab);
    accessTitle->setObjectName("HeroTitle");
    auto* accessHint = new QLabel("Все уведомления, переключения и настройки доступности собраны в одной вкладке.", accessTab);
    accessHint->setObjectName("HeroSubtitle");
    accessHint->setWordWrap(true);
    auto* sizeSlider = new QSlider(Qt::Horizontal, accessTab);
    sizeSlider->setRange(12, 22);
    sizeSlider->setValue(15);
    auto* voiceBox = new QCheckBox("Включить озвучку текста", accessTab);
    m_speakButton = new QPushButton("🔊 Озвучить текущий экран", accessTab);
    makeButtonSecondary(m_speakButton);
    m_speakButton->setEnabled(false);
    auto* filterBox = new QComboBox(accessTab);
    filterBox->addItems({"Обычный режим", "Высокая контрастность", "Тёплый фильтр", "Холодный фильтр"});
    accessLayout2->addWidget(accessTitle);
    accessLayout2->addWidget(accessHint);
    accessLayout2->addWidget(new QLabel("🔠 Размер текста", accessTab));
    accessLayout2->addWidget(sizeSlider);
    accessLayout2->addWidget(voiceBox);
    accessLayout2->addWidget(m_speakButton);
    accessLayout2->addWidget(new QLabel("🎨 Цветовой фильтр", accessTab));
    accessLayout2->addWidget(filterBox);
    accessLayout2->addStretch(1);
    m_tabs->addTab(accessTab, "🛠️ Спец. возможности");
    connect(sizeSlider, &QSlider::valueChanged, this, [this](int value) {
        m_accessFontSize = value;
        applyAccessibilityStyle();
        statusBar()->hide();
    });
    connect(voiceBox, &QCheckBox::toggled, this, [this](bool enabled) {
        m_voiceEnabled = enabled;
        if (m_speakButton != nullptr) {
            m_speakButton->setEnabled(enabled);
        }
        if (m_quickSpeakButton != nullptr) {
            m_quickSpeakButton->setVisible(enabled);
        }
        statusBar()->hide();
        if (enabled) {
            speakCurrentText();
        }
    });
    connect(m_speakButton, &QPushButton::clicked, this, &MainWindow::speakCurrentText);
    if (m_quickSpeakButton != nullptr) {
        connect(m_quickSpeakButton, &QPushButton::clicked, this, &MainWindow::speakCurrentText);
    }
    connect(filterBox, &QComboBox::currentTextChanged, this, [this](const QString& mode) {
        applyAccessibilityStyle(mode);
        statusBar()->hide();
    });

    splitter->addWidget(leftPanel);
    splitter->addWidget(rightPanel);
    splitter->setStretchFactor(0, 0);
    splitter->setStretchFactor(1, 1);

    statusBar()->setObjectName("StatusBar");
    statusBar()->hide();

    connect(m_categoryList, &QListWidget::itemSelectionChanged, this, &MainWindow::refreshPlaces);
    connect(m_searchEdit, &QLineEdit::textChanged, this, &MainWindow::refreshPlaces);
    connect(needsButton, &QPushButton::clicked, this, &MainWindow::applyUserNeeds);
    connect(resetButton, &QPushButton::clicked, this, &MainWindow::resetFilters);
    connect(m_detailsButton, &QPushButton::clicked, this, &MainWindow::openSelectedPlace);
    if (m_adminButton != nullptr) {
        connect(m_adminButton, &QPushButton::clicked, this, &MainWindow::openAdminPanel);
    }
    connect(m_table, &QTableWidget::cellDoubleClicked, this, [this](int, int) { openSelectedPlace(); });

    for (QCheckBox* box : filterBoxes()) {
        connect(box, &QCheckBox::toggled, this, &MainWindow::refreshPlaces);
    }
}

void MainWindow::loadCategories()
{
    QString error;
    const QVector<QPair<int, QString>> categories = Database::instance().categories(&error);
    if (!error.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", error);
    }

    m_categoryList->clear();
    auto* allItem = new QListWidgetItem("Все категории", m_categoryList);
    allItem->setData(Qt::UserRole, 0);

    for (const auto& category : categories) {
        auto* item = new QListWidgetItem(category.second, m_categoryList);
        item->setData(Qt::UserRole, category.first);
    }

    m_categoryList->setCurrentRow(0);
}

AccessibilityFilters MainWindow::currentFilters() const
{
    AccessibilityFilters filters;
    filters.ramp = m_rampCheck->isChecked();
    filters.elevator = m_elevatorCheck->isChecked();
    filters.accessibleToilet = m_toiletCheck->isChecked();
    filters.quietPlace = m_quietCheck->isChecked();
    filters.visualSupport = m_visualCheck->isChecked();
    filters.trainedStaff = m_staffCheck->isChecked();
    filters.pictureMenu = m_pictureMenuCheck->isChecked();
    filters.assistantAllowed = m_assistantCheck->isChecked();
    return filters;
}

int MainWindow::currentCategoryId() const
{
    const QListWidgetItem* item = m_categoryList->currentItem();
    if (item == nullptr) {
        return 0;
    }
    return item->data(Qt::UserRole).toInt();
}

void MainWindow::refreshPlaces()
{
    QString error;
    m_places = Database::instance().places(currentFilters(), currentCategoryId(), m_searchEdit->text(), &error);
    if (!error.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", error);
        return;
    }

    const AccessibilityFilters activeFilters = currentFilters();
    const bool hasAnyFilterForSort = activeFilters.ramp || activeFilters.elevator || activeFilters.accessibleToilet ||
        activeFilters.quietPlace || activeFilters.visualSupport || activeFilters.trainedStaff ||
        activeFilters.pictureMenu || activeFilters.assistantAllowed;
    if (hasAnyFilterForSort) {
        std::sort(m_places.begin(), m_places.end(), [this](const Place& left, const Place& right) {
            const int leftMatch = calculateMatchPercent(left);
            const int rightMatch = calculateMatchPercent(right);
            if (leftMatch == rightMatch) {
                return left.name.localeAwareCompare(right.name) < 0;
            }
            return leftMatch > rightMatch;
        });
    }

    const bool hasActiveFilter = activeFilters.ramp || activeFilters.elevator || activeFilters.accessibleToilet ||
        activeFilters.quietPlace || activeFilters.visualSupport || activeFilters.trainedStaff ||
        activeFilters.pictureMenu || activeFilters.assistantAllowed;
    m_table->setColumnHidden(5, !hasActiveFilter);

    m_table->setRowCount(0);
    for (const Place& place : m_places) {
        const int row = m_table->rowCount();
        m_table->insertRow(row);
        m_table->setRowHeight(row, 48);

        setItemReadOnly(row, 0, QString::number(place.id));
        setItemReadOnly(row, 1, place.name);
        setItemReadOnly(row, 2, place.categoryName);
        setItemReadOnly(row, 3, place.address);
        setItemReadOnly(row, 4, featuresSummary(place));

        const int match = calculateMatchPercent(place);
        const QString matchText = match < 0 ? QString() : QString::number(match) + "%";
        setItemReadOnly(row, 5, matchText);

        auto* nameItem = m_table->item(row, 1);
        if (nameItem != nullptr) {
            QFont font = nameItem->font();
            font.setBold(true);
            nameItem->setFont(font);
            nameItem->setForeground(QBrush(QColor("#0f172a")));
        }

        auto* matchItem = m_table->item(row, 5);
        if (matchItem != nullptr) {
            QFont font = matchItem->font();
            font.setBold(true);
            matchItem->setFont(font);
            matchItem->setTextAlignment(Qt::AlignCenter);

            if (match < 0) {
                matchItem->setForeground(QBrush(QColor("#64748b")));
                matchItem->setBackground(QBrush(QColor("#ffffff")));
            } else if (match >= 80) {
                matchItem->setForeground(QBrush(QColor("#047857")));
                matchItem->setBackground(QBrush(QColor("#ecfdf5")));
            } else if (match >= 50) {
                matchItem->setForeground(QBrush(QColor("#a16207")));
                matchItem->setBackground(QBrush(QColor("#fef9c3")));
            } else {
                matchItem->setForeground(QBrush(QColor("#b91c1c")));
                matchItem->setBackground(QBrush(QColor("#fee2e2")));
            }
        }
    }

    if (m_table->rowCount() > 0) {
        m_table->selectRow(0);
    }

    m_resultLabel->setText("Найдено мест: " + QString::number(m_places.size()));
}

void MainWindow::setItemReadOnly(int row, int column, const QString& text)
{
    auto* item = new QTableWidgetItem(text);
    item->setFlags(item->flags() & ~Qt::ItemIsEditable);
    item->setToolTip(text);
    m_table->setItem(row, column, item);
}

QString MainWindow::featuresSummary(const Place& place) const
{
    QStringList features;
    if (place.hasRamp) {
        features << "пандус";
    }
    if (place.hasElevator) {
        features << "лифт";
    }
    if (place.hasAccessibleToilet) {
        features << "доступный туалет";
    }
    if (place.hasQuietPlace) {
        features << "тихая зона";
    }
    if (place.hasVisualSupport) {
        features << "визуальные подсказки";
    }
    if (place.hasTrainedStaff) {
        features << "обученный персонал";
    }
    if (place.hasPictureMenu) {
        features << "меню с картинками";
    }
    if (place.allowsAssistant) {
        features << "сопровождение";
    }

    return features.isEmpty() ? "условия не отмечены" : features.join("  ·  ");
}

int MainWindow::calculateMatchPercent(const Place& place) const
{
    int required = 0;
    int matched = 0;

    auto check = [&required, &matched](bool need, bool has) {
        if (!need) {
            return;
        }
        ++required;
        if (has) {
            ++matched;
        }
    };

    const AccessibilityFilters filters = currentFilters();
    check(filters.ramp, place.hasRamp);
    check(filters.elevator, place.hasElevator);
    check(filters.accessibleToilet, place.hasAccessibleToilet);
    check(filters.quietPlace, place.hasQuietPlace);
    check(filters.visualSupport, place.hasVisualSupport);
    check(filters.trainedStaff, place.hasTrainedStaff);
    check(filters.pictureMenu, place.hasPictureMenu);
    check(filters.assistantAllowed, place.allowsAssistant);

    if (required == 0) {
        return -1;
    }
    return matched * 100 / required;
}

QVector<QCheckBox*> MainWindow::filterBoxes() const
{
    return {
        m_rampCheck,
        m_elevatorCheck,
        m_toiletCheck,
        m_quietCheck,
        m_visualCheck,
        m_staffCheck,
        m_pictureMenuCheck,
        m_assistantCheck
    };
}

void MainWindow::applyUserNeeds()
{
    const QVector<QCheckBox*> boxes = filterBoxes();
    QVector<QSignalBlocker*> blockers;
    blockers.reserve(boxes.size());
    for (QCheckBox* box : boxes) {
        blockers.push_back(new QSignalBlocker(box));
    }

    m_rampCheck->setChecked(m_user.needRamp);
    m_elevatorCheck->setChecked(m_user.needElevator);
    m_toiletCheck->setChecked(m_user.needAccessibleToilet);
    m_quietCheck->setChecked(m_user.needQuietPlace);
    m_visualCheck->setChecked(m_user.needVisualSupport);
    m_staffCheck->setChecked(m_user.needTrainedStaff);
    m_pictureMenuCheck->setChecked(m_user.needPictureMenu);
    m_assistantCheck->setChecked(m_user.needAssistance);

    qDeleteAll(blockers);
    refreshPlaces();
}

void MainWindow::resetFilters()
{
    const QVector<QCheckBox*> boxes = filterBoxes();
    QVector<QSignalBlocker*> blockers;
    blockers.reserve(boxes.size() + 2);
    for (QCheckBox* box : boxes) {
        blockers.push_back(new QSignalBlocker(box));
        box->setChecked(false);
    }

    QSignalBlocker searchBlocker(m_searchEdit);
    QSignalBlocker categoryBlocker(m_categoryList);
    m_searchEdit->clear();
    m_categoryList->setCurrentRow(0);

    qDeleteAll(blockers);
    refreshPlaces();
}

void MainWindow::openSelectedPlace()
{
    const int row = m_table->currentRow();
    if (row < 0 || m_table->item(row, 0) == nullptr) {
        QMessageBox::information(this, "Карточка места", "Выберите место в таблице.");
        return;
    }

    const int placeId = m_table->item(row, 0)->text().toInt();
    Place place;
    QString error;
    if (!Database::instance().placeById(placeId, &place, &error)) {
        QMessageBox::warning(this, "Ошибка", error);
        return;
    }

    PlaceDetailsDialog dialog(place, this);
    dialog.exec();
}

void MainWindow::openAdminPanel()
{
    if (!m_user.isAdmin) {
        QMessageBox::warning(this, "Доступ запрещён", "Админ-панель доступна только администратору.");
        return;
    }

    AdminDialog dialog(m_user, this);
    dialog.exec();
    loadCategories();
    refreshPlaces();
    refreshNews();
}

void MainWindow::refreshNews()
{
    if (m_newsView == nullptr) {
        return;
    }
    QString error;
    const QVector<NewsItem> items = Database::instance().news(&error);
    if (!error.isEmpty()) {
        m_newsView->setHtml("<div style=\"background:#ffffff;color:#0f172a;padding:20px;border-radius:18px;\"><h2 style=\"color:#075985;\">⚠ Новости временно недоступны</h2><p style=\"color:#0f172a;\">" + error.toHtmlEscaped() + "</p></div>");
        return;
    }

    QString html = "<body style='background:#ffffff; color:#0f172a; font-family:Segoe UI, Arial; margin:0;'>";
    html += "<div style='padding:4px 2px 14px 2px;'>";
    html += "<h1 style='color:#075985; margin:0 0 6px 0;'>📰 Новости проекта</h1>";
    html += "<p style='color:#0f172a; font-size:15px;'>Здесь собраны важные обновления о доступных местах и возможностях приложения.</p>";
    html += "</div>";

    if (items.isEmpty()) {
        html += "<div style='background:#eff6ff;border:1px solid #bfdbfe;border-radius:20px;padding:22px;'>";
        html += "<h2 style='color:#075985;'>📭 Пока новостей нет</h2>";
        html += "<p style='color:#0f172a;'>Администратор сможет добавить новости через админ-панель.</p></div>";
    }

    for (const NewsItem& item : items) {
        html += "<div style='margin-bottom:20px; padding:20px; border-radius:22px; background:#ffffff; border:1px solid #bfdbfe;'>";
        html += "<h2 style='color:#075985; margin:0 0 6px 0;'>📌 " + item.title.toHtmlEscaped() + "</h2>";
        html += "<p style='color:#2563eb; font-weight:700; margin:0 0 12px 0;'>🗓 " + item.createdAt.toHtmlEscaped() + "</p>";
        html += "<p style='color:#0f172a; font-size:16px; line-height:1.55; margin-bottom:14px;'>" + item.text.toHtmlEscaped().replace("\n", "<br>") + "</p>";
        if (!item.image1.isEmpty() || !item.image2.isEmpty()) {
            html += "<div style='margin-top:10px;'>";
            if (!item.image1.isEmpty()) html += "<img src='" + item.image1.toHtmlEscaped() + "' width='300' style='border-radius:16px; margin:0 10px 10px 0; border:1px solid #dbeafe;'>";
            if (!item.image2.isEmpty()) html += "<img src='" + item.image2.toHtmlEscaped() + "' width='300' style='border-radius:16px; margin:0 10px 10px 0; border:1px solid #dbeafe;'>";
            html += "</div>";
        }
        html += "</div>";
    }
    html += "</body>";
    m_newsView->setHtml(html);
}

void MainWindow::applyAccessibilityStyle(const QString& colorMode)
{
    if (!colorMode.isEmpty()) {
        m_colorMode = colorMode;
    }

    QString css = QString("QWidget{font-size:%1px;} QLineEdit,QTextEdit,QTableWidget,QListWidget{font-size:%2px;} ")
        .arg(m_accessFontSize)
        .arg(m_accessFontSize + 1);

    if (m_colorMode == "Высокая контрастность") {
        css += "QWidget{background:#000;color:#fff;} QPushButton{background:#fff;color:#000;} QLineEdit,QTextEdit,QTableWidget,QListWidget{background:#111;color:#fff;border:1px solid #fff;} ";
    } else if (m_colorMode == "Тёплый фильтр") {
        css += "QWidget{background:#fff7ed;color:#1f2937;} QLineEdit,QTextEdit,QTableWidget,QListWidget{background:#fffbeb;color:#1f2937;} ";
    } else if (m_colorMode == "Холодный фильтр") {
        css += "QWidget{background:#eff6ff;color:#0f172a;} QLineEdit,QTextEdit,QTableWidget,QListWidget{background:#f8fafc;color:#0f172a;} ";
    }

    // Для обычного режима полностью убираем цветовые фильтры и оставляем только масштаб текста.
    setStyleSheet(css);
}

void MainWindow::logout()
{
    const auto answer = QMessageBox::question(this, "Выход", "Выйти из текущего профиля?");
    if (answer != QMessageBox::Yes) {
        return;
    }

    hide();
    LoginWindow loginWindow;
    if (loginWindow.exec() == QDialog::Accepted) {
        auto* newWindow = new MainWindow(loginWindow.loggedUser());
        newWindow->setAttribute(Qt::WA_DeleteOnClose);
        newWindow->show();
        close();
        return;
    }

    show();
}


QString MainWindow::textForSpeech() const
{
    QString text;
    if (m_tabs != nullptr) {
        text += "Открыта вкладка: " + m_tabs->tabText(m_tabs->currentIndex()) + ". ";
    }

    if (m_tabs != nullptr && m_tabs->currentIndex() == 0) {
        text += "Каталог доступных мест. " + m_resultLabel->text() + ". ";
        const int row = m_table != nullptr ? m_table->currentRow() : -1;
        if (row >= 0 && m_table->item(row, 1) != nullptr) {
            text += "Выбрано место: " + m_table->item(row, 1)->text() + ". Адрес: " + m_table->item(row, 3)->text() + ". ";
            text += "Возможности: " + m_table->item(row, 4)->text() + ".";
        }
    } else if (m_tabs != nullptr && m_tabs->currentIndex() == 1) {
        text += "Новости проекта. " + m_newsView->toPlainText().left(900);
    } else if (m_tabs != nullptr && m_tabs->currentIndex() == 2) {
        text += "Мой профиль. Здесь можно изменить имя, пароль и индивидуальные потребности.";
    } else {
        text += "Специальные возможности. Здесь можно изменить размер текста, включить озвучку и выбрать цветовой фильтр.";
    }
    return text.simplified();
}

void MainWindow::speakCurrentText()
{
    if (!m_voiceEnabled) {
        return;
    }

    const QString text = textForSpeech();
    if (text.isEmpty()) {
        return;
    }

    if (m_speechProcess != nullptr && m_speechProcess->state() != QProcess::NotRunning) {
        m_speechProcess->kill();
        m_speechProcess->waitForFinished(300);
    }
    if (m_speechProcess == nullptr) {
        m_speechProcess = new QProcess(this);
    }

#if defined(Q_OS_WIN)
    QString escaped = text;
    escaped.replace("'", "''");
    const QString script = "Add-Type -AssemblyName System.Speech; "
                           "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                           "$s.Rate = -1; $s.Speak('" + escaped + "');";
    m_speechProcess->start("powershell", {"-NoProfile", "-Command", script});
#elif defined(Q_OS_MACOS)
    m_speechProcess->start("say", {text});
#else
    m_speechProcess->start("spd-say", {text});
    if (!m_speechProcess->waitForStarted(300)) {
        m_speechProcess->start("espeak", {text});
    }
#endif
}

void MainWindow::saveProfile()
{
    if (m_profileNameEdit == nullptr || m_profilePasswordEdit == nullptr) {
        return;
    }
    UserProfile updated = m_user;
    updated.name = m_profileNameEdit->text().trimmed();
    updated.needRamp = m_profileRampCheck->isChecked();
    updated.needElevator = m_profileElevatorCheck->isChecked();
    updated.needAccessibleToilet = m_profileToiletCheck->isChecked();
    updated.needQuietPlace = m_profileQuietCheck->isChecked();
    updated.needVisualSupport = m_profileVisualCheck->isChecked();
    updated.needTrainedStaff = m_profileStaffCheck->isChecked();
    updated.needPictureMenu = m_profilePictureMenuCheck->isChecked();
    updated.needAssistance = m_profileAssistantCheck->isChecked();

    QString error;
    if (!Database::instance().updateUserProfile(m_user.id, updated.name, updated, m_profilePasswordEdit->text(), &error)) {
        QMessageBox::warning(this, "👤 Профиль", error);
        return;
    }
    m_user = updated;
    m_profilePasswordEdit->clear();
    m_userLabel->setText("Здравствуйте, <b>" + m_user.name.toHtmlEscaped() + "</b><br><span style='color:#64748b; font-weight:400;'>" + (m_user.isAdmin ? QString("Администратор системы") : QString("Профиль потребностей активен")) + "</span>");
    QMessageBox::information(this, "👤 Профиль", "Профиль сохранён.");
    refreshPlaces();
}
