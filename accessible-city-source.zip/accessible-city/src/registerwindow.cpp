#include "registerwindow.h"

#include "database.h"

#include <QCheckBox>
#include <QColor>
#include <QCursor>
#include <QFont>
#include <QFormLayout>
#include <QFrame>
#include <QGraphicsDropShadowEffect>
#include <QGridLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPushButton>
#include <QScrollArea>
#include <QVBoxLayout>

namespace
{
void addSoftShadow(QWidget* widget)
{
    auto* shadow = new QGraphicsDropShadowEffect(widget);
    shadow->setBlurRadius(30);
    shadow->setOffset(0, 10);
    shadow->setColor(QColor(15, 23, 42, 32));
    widget->setGraphicsEffect(shadow);
}
}

RegisterWindow::RegisterWindow(QWidget* parent)
    : QDialog(parent)
{
    setWindowTitle("Регистрация пользователя");
    setObjectName("AuthDialog");
    setModal(true);
    resize(760, 760);
    setMinimumSize(680, 650);

    auto* pageLayout = new QVBoxLayout(this);
    pageLayout->setContentsMargins(26, 26, 26, 26);

    auto* scroll = new QScrollArea(this);
    scroll->setObjectName("TransparentScroll");
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    pageLayout->addWidget(scroll);

    auto* container = new QWidget(scroll);
    auto* containerLayout = new QVBoxLayout(container);
    containerLayout->setContentsMargins(12, 12, 12, 12);
    containerLayout->addStretch(1);

    auto* card = new QFrame(container);
    card->setObjectName("RegisterCard");
    addSoftShadow(card);
    containerLayout->addWidget(card);
    containerLayout->addStretch(1);
    scroll->setWidget(container);

    auto* mainLayout = new QVBoxLayout(card);
    mainLayout->setContentsMargins(38, 34, 38, 34);
    mainLayout->setSpacing(18);

    auto* title = new QLabel("✨ Создание учётной записи", card);
    title->setObjectName("WindowTitleLabel");
    title->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(title);

    auto* hint = new QLabel(
        "Заполните данные и отметьте условия, которые важны для комфортного посещения мест.",
        card
    );
    hint->setObjectName("SubtitleLabel");
    hint->setWordWrap(true);
    hint->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(hint);

    auto* accountBox = new QGroupBox("👤 Данные пользователя", card);
    auto* formLayout = new QFormLayout(accountBox);
    formLayout->setLabelAlignment(Qt::AlignLeft);
    formLayout->setHorizontalSpacing(16);
    formLayout->setVerticalSpacing(12);

    m_nameEdit = new QLineEdit(accountBox);
    m_loginEdit = new QLineEdit(accountBox);
    m_emailEdit = new QLineEdit(accountBox);
    m_passwordEdit = new QLineEdit(accountBox);
    m_repeatPasswordEdit = new QLineEdit(accountBox);
    m_passwordEdit->setEchoMode(QLineEdit::Password);
    m_repeatPasswordEdit->setEchoMode(QLineEdit::Password);

    m_nameEdit->setPlaceholderText("Например: Анна");
    m_loginEdit->setPlaceholderText("Придумайте логин");
    m_emailEdit->setPlaceholderText("Например: user@example.com");
    m_passwordEdit->setPlaceholderText("Придумайте пароль");
    m_repeatPasswordEdit->setPlaceholderText("Повторите пароль");

    m_nameEdit->setClearButtonEnabled(true);
    m_loginEdit->setClearButtonEnabled(true);
    m_emailEdit->setClearButtonEnabled(true);
    m_passwordEdit->setClearButtonEnabled(true);
    m_repeatPasswordEdit->setClearButtonEnabled(true);

    formLayout->addRow("Имя", m_nameEdit);
    formLayout->addRow("Логин", m_loginEdit);
    formLayout->addRow("Почта", m_emailEdit);
    formLayout->addRow("Пароль", m_passwordEdit);
    formLayout->addRow("Повтор пароля", m_repeatPasswordEdit);
    mainLayout->addWidget(accountBox);

    auto* needsBox = new QGroupBox("♿ Индивидуальные потребности", card);
    auto* needsLayout = new QGridLayout(needsBox);
    needsLayout->setHorizontalSpacing(20);
    needsLayout->setVerticalSpacing(8);

    m_rampCheck = new QCheckBox("Безбарьерный вход / пандус", needsBox);
    m_elevatorCheck = new QCheckBox("Лифт", needsBox);
    m_toiletCheck = new QCheckBox("Доступный туалет", needsBox);
    m_quietCheck = new QCheckBox("Тихая зона", needsBox);
    m_visualCheck = new QCheckBox("Визуальные подсказки", needsBox);
    m_staffCheck = new QCheckBox("Обученный персонал", needsBox);
    m_pictureMenuCheck = new QCheckBox("Меню с картинками", needsBox);
    m_assistantCheck = new QCheckBox("Возможность сопровождения", needsBox);

    needsLayout->addWidget(m_rampCheck, 0, 0);
    needsLayout->addWidget(m_elevatorCheck, 0, 1);
    needsLayout->addWidget(m_toiletCheck, 1, 0);
    needsLayout->addWidget(m_quietCheck, 1, 1);
    needsLayout->addWidget(m_visualCheck, 2, 0);
    needsLayout->addWidget(m_staffCheck, 2, 1);
    needsLayout->addWidget(m_pictureMenuCheck, 3, 0);
    needsLayout->addWidget(m_assistantCheck, 3, 1);
    mainLayout->addWidget(needsBox);

    auto* actionsLayout = new QHBoxLayout();
    actionsLayout->setContentsMargins(0, 8, 0, 0);

    auto* cancelButton = new QPushButton("↩️ Отмена", card);
    cancelButton->setProperty("class", "GhostButton");
    cancelButton->setCursor(Qt::PointingHandCursor);

    auto* registerButton = new QPushButton("✨ Зарегистрироваться", card);
    registerButton->setProperty("class", "PrimaryButton");
    registerButton->setCursor(Qt::PointingHandCursor);
    registerButton->setDefault(true);
    registerButton->setMinimumHeight(50);
    registerButton->setStyleSheet("font-size:16px;font-weight:bold;");

    actionsLayout->addWidget(cancelButton);
    actionsLayout->addStretch(1);
    actionsLayout->addWidget(registerButton);
    mainLayout->addLayout(actionsLayout);

    connect(registerButton, &QPushButton::clicked, this, &RegisterWindow::handleRegister);
    connect(cancelButton, &QPushButton::clicked, this, &RegisterWindow::reject);
}

UserProfile RegisterWindow::collectNeeds() const
{
    UserProfile profile;
    profile.needRamp = m_rampCheck->isChecked();
    profile.needElevator = m_elevatorCheck->isChecked();
    profile.needAccessibleToilet = m_toiletCheck->isChecked();
    profile.needQuietPlace = m_quietCheck->isChecked();
    profile.needVisualSupport = m_visualCheck->isChecked();
    profile.needTrainedStaff = m_staffCheck->isChecked();
    profile.needPictureMenu = m_pictureMenuCheck->isChecked();
    profile.needAssistance = m_assistantCheck->isChecked();
    return profile;
}

void RegisterWindow::handleRegister()
{
    if (m_passwordEdit->text() != m_repeatPasswordEdit->text()) {
        QMessageBox::warning(this, "Ошибка", "Пароли не совпадают.");
        return;
    }

    QString error;
    const bool ok = Database::instance().registerUser(
        m_nameEdit->text(),
        m_loginEdit->text(),
        m_emailEdit->text(),
        m_passwordEdit->text(),
        collectNeeds(),
        &error
    );

    if (!ok) {
        QMessageBox::warning(this, "Ошибка регистрации", error);
        return;
    }

    QMessageBox::information(this, "Готово", "Пользователь успешно зарегистрирован.");
    accept();
}
