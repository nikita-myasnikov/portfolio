#ifndef DATABASE_H
#define DATABASE_H

#include <QMap>
#include <QPair>
#include <QSqlDatabase>
#include <QString>
#include <QStringList>
#include <QVector>

#include "models.h"

class Database
{
public:
    static Database& instance();

    bool open(QString* errorMessage = nullptr);
    bool initialize(QString* errorMessage = nullptr);
    QString databasePath() const;

    bool registerUser(const QString& name,
                      const QString& login,
                      const QString& email,
                      const QString& password,
                      const UserProfile& needs,
                      QString* errorMessage = nullptr);

    bool authenticate(const QString& login,
                      const QString& password,
                      UserProfile* profile,
                      QString* errorMessage = nullptr);

    QVector<QPair<int, QString>> categories(QString* errorMessage = nullptr) const;

    QVector<Place> places(const AccessibilityFilters& filters,
                          int categoryId,
                          const QString& searchText,
                          QString* errorMessage = nullptr) const;

    bool placeById(int placeId, Place* place, QString* errorMessage = nullptr) const;
    QStringList placePhotos(int placeId, QString* errorMessage = nullptr) const;

    QVector<NewsItem> news(QString* errorMessage = nullptr) const;
    bool addNews(const QString& title, const QString& text, const QString& image1, const QString& image2, QString* errorMessage = nullptr);
    bool deleteNews(int newsId, QString* errorMessage = nullptr);

    QVector<UserAccount> users(QString* errorMessage = nullptr) const;
    bool deleteUser(int userId, QString* errorMessage = nullptr);
    bool makeUserAdmin(int userId, QString* errorMessage = nullptr);
    bool setUserAdminStatus(int userId, bool isAdmin, QString* errorMessage = nullptr);
    bool updateUserProfile(int userId, const QString& name, const UserProfile& needs, const QString& newPassword = QString(), QString* errorMessage = nullptr);

    bool addPlace(const Place& place,
                  const QStringList& photoPaths,
                  int* newPlaceId = nullptr,
                  QString* errorMessage = nullptr);

    bool updatePlace(const Place& place,
                     const QStringList& photoPaths,
                     QString* errorMessage = nullptr);

    bool deletePlace(int placeId, QString* errorMessage = nullptr);

    QString importPhotoToStorage(const QString& sourcePath,
                                 QString* errorMessage = nullptr) const;

private:
    Database();
    Database(const Database&) = delete;
    Database& operator=(const Database&) = delete;

    bool createTables(QString* errorMessage);
    bool ensureColumn(const QString& tableName,
                      const QString& columnName,
                      const QString& columnDefinition,
                      QString* errorMessage);
    bool seedInitialData(QString* errorMessage);
    bool seedDefaultAdmin(QString* errorMessage);
    bool seedInitialPhotos(QString* errorMessage);
    bool savePlacePhotos(int placeId,
                         const QStringList& photoPaths,
                         QString* errorMessage);
    QMap<QString, int> categoryIds(QString* errorMessage = nullptr) const;

    QString generateSalt() const;
    QString hashPassword(const QString& password, const QString& salt) const;
    static void setError(QString* target, const QString& message);

    QSqlDatabase m_db;
    QString m_connectionName;
    QString m_databasePath;
};

#endif // DATABASE_H
