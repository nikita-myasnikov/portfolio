#include "loginwindow.h"

#include "database.h"
#include "registerwindow.h"

#include <QColor>
#include <QCursor>
#include <QFont>
#include <QFormLayout>
#include <QFrame>
#include <QGraphicsDropShadowEffect>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPushButton>
#include <QVBoxLayout>

namespace
{
void addSoftShadow(QWidget* widget)
{
    auto* shadow = new QGraphicsDropShadowEffect(widget);
    shadow->setBlurRadius(32);
    shadow->setOffset(0, 12);
    shadow->setColor(QColor(15, 23, 42, 35));
    widget->setGraphicsEffect(shadow);
}
}

LoginWindow::LoginWindow(QWidget* parent)
    : QDialog(parent)
{
    setWindowTitle("Мы разам! — вход");
    setObjectName("AuthDialog");
    setMinimumSize(540, 560);

    auto* pageLayout = new QVBoxLayout(this);
    pageLayout->setContentsMargins(34, 34, 34, 34);
    pageLayout->setSpacing(0);

    auto* card = new QFrame(this);
    card->setObjectName("AuthCard");
    addSoftShadow(card);
    pageLayout->addStretch(1);
    pageLayout->addWidget(card);
    pageLayout->addStretch(1);

    auto* cardLayout = new QVBoxLayout(card);
    cardLayout->setContentsMargins(42, 38, 42, 38);
    cardLayout->setSpacing(18);

    auto* logo = new QLabel("♿", card);
    logo->setObjectName("LogoBadge");
    logo->setFixedSize(64, 64);
    logo->setAlignment(Qt::AlignCenter);
    cardLayout->addWidget(logo, 0, Qt::AlignHCenter);

    auto* title = new QLabel("Мы разам!", card);
    title->setObjectName("TitleLabel");
    title->setAlignment(Qt::AlignCenter);
    cardLayout->addWidget(title);

    auto* subtitle = new QLabel(
        "Справочная система доступных мест для людей с особенностями психофизического развития",
        card
    );
    subtitle->setObjectName("SubtitleLabel");
    subtitle->setWordWrap(true);
    subtitle->setAlignment(Qt::AlignCenter);
    cardLayout->addWidget(subtitle);

    auto* formLayout = new QFormLayout();
    formLayout->setLabelAlignment(Qt::AlignLeft);
    formLayout->setFormAlignment(Qt::AlignHCenter | Qt::AlignTop);
    formLayout->setHorizontalSpacing(16);
    formLayout->setVerticalSpacing(13);

    m_loginEdit = new QLineEdit(card);
    m_passwordEdit = new QLineEdit(card);
    m_passwordEdit->setEchoMode(QLineEdit::Password);
    m_loginEdit->setPlaceholderText("Введите логин или почту");
    m_passwordEdit->setPlaceholderText("Введите пароль");
    m_loginEdit->setClearButtonEnabled(true);
    m_passwordEdit->setClearButtonEnabled(true);

    formLayout->addRow("Логин / почта", m_loginEdit);
    formLayout->addRow("Пароль", m_passwordEdit);
    cardLayout->addLayout(formLayout);

    auto* loginButton = new QPushButton("🔐 Войти в систему", card);
    loginButton->setProperty("class", "PrimaryButton");
    loginButton->setCursor(Qt::PointingHandCursor);
    loginButton->setDefault(true);
    cardLayout->addWidget(loginButton);

    auto* buttonsLayout = new QHBoxLayout();
    buttonsLayout->setContentsMargins(0, 0, 0, 0);
    auto* registerButton = new QPushButton("✨ Зарегистрироваться", card);
    registerButton->setMinimumHeight(44);
    registerButton->setProperty("class", "SecondaryButton");
    registerButton->setCursor(Qt::PointingHandCursor);
    buttonsLayout->addWidget(registerButton, 1);
    cardLayout->addLayout(buttonsLayout);

    
    connect(loginButton, &QPushButton::clicked, this, &LoginWindow::handleLogin);
    connect(registerButton, &QPushButton::clicked, this, &LoginWindow::openRegistration);
    connect(m_passwordEdit, &QLineEdit::returnPressed, this, &LoginWindow::handleLogin);
}

UserProfile LoginWindow::loggedUser() const
{
    return m_loggedUser;
}

void LoginWindow::handleLogin()
{
    QString error;
    UserProfile profile;
    const bool ok = Database::instance().authenticate(
        m_loginEdit->text(),
        m_passwordEdit->text(),
        &profile,
        &error
    );

    if (!ok) {
        QMessageBox::warning(this, "Ошибка входа", error);
        return;
    }

    m_loggedUser = profile;
    accept();
}

void LoginWindow::openRegistration()
{
    RegisterWindow dialog(this);
    dialog.exec();
}
