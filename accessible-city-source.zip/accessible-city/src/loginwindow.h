#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H

#include <QDialog>

#include "models.h"

class QLineEdit;

class LoginWindow : public QDialog
{
    Q_OBJECT

public:
    explicit LoginWindow(QWidget* parent = nullptr);
    UserProfile loggedUser() const;

private:
    void handleLogin();
    void openRegistration();

    QLineEdit* m_loginEdit = nullptr;
    QLineEdit* m_passwordEdit = nullptr;
    UserProfile m_loggedUser;
};

#endif // LOGINWINDOW_H
