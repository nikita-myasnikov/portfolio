#include "database.h"

#include <QCoreApplication>
#include <QCryptographicHash>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QRandomGenerator>
#include <QRegularExpression>
#include <QSqlError>
#include <QSqlQuery>
#include <QStandardPaths>
#include <QStringList>
#include <QUuid>
#include <QVariant>

namespace
{
Place readPlace(const QSqlQuery& query)
{
    Place place;
    place.id = query.value(0).toInt();
    place.categoryId = query.value(1).toInt();
    place.name = query.value(2).toString();
    place.categoryName = query.value(3).toString();
    place.address = query.value(4).toString();
    place.phone = query.value(5).toString();
    place.description = query.value(6).toString();
    place.hasRamp = query.value(7).toInt() == 1;
    place.hasElevator = query.value(8).toInt() == 1;
    place.hasAccessibleToilet = query.value(9).toInt() == 1;
    place.hasQuietPlace = query.value(10).toInt() == 1;
    place.hasVisualSupport = query.value(11).toInt() == 1;
    place.hasTrainedStaff = query.value(12).toInt() == 1;
    place.hasPictureMenu = query.value(13).toInt() == 1;
    place.allowsAssistant = query.value(14).toInt() == 1;
    return place;
}

QStringList normalizedPhotoList(const QStringList& source)
{
    QStringList result;
    for (const QString& path : source) {
        const QString trimmed = path.trimmed();
        if (trimmed.isEmpty() || result.contains(trimmed)) {
            continue;
        }
        result << trimmed;
        if (result.size() == 10) {
            break;
        }
    }
    return result;
}
}

Database::Database()
    : m_connectionName("accessible_city_connection")
{
}

Database& Database::instance()
{
    static Database database;
    return database;
}

void Database::setError(QString* target, const QString& message)
{
    if (target != nullptr) {
        *target = message;
    }
}

bool Database::open(QString* errorMessage)
{
    if (QSqlDatabase::contains(m_connectionName)) {
        m_db = QSqlDatabase::database(m_connectionName);
    } else {
        m_db = QSqlDatabase::addDatabase("QSQLITE", m_connectionName);
    }

    QString dirPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    if (dirPath.isEmpty()) {
        dirPath = QDir::currentPath();
    }

    QDir dir(dirPath);
    if (!dir.exists() && !dir.mkpath(".")) {
        setError(errorMessage, "Не удалось создать папку для базы данных: " + dirPath);
        return false;
    }

    m_databasePath = dir.filePath("accessible_city.sqlite");
    m_db.setDatabaseName(m_databasePath);

    if (!m_db.open()) {
        setError(errorMessage, "Ошибка подключения к SQLite: " + m_db.lastError().text());
        return false;
    }

    QSqlQuery pragma(m_db);
    pragma.exec("PRAGMA foreign_keys = ON");
    return true;
}

QString Database::databasePath() const
{
    return m_databasePath;
}

bool Database::initialize(QString* errorMessage)
{
    if (!m_db.isOpen()) {
        setError(errorMessage, "База данных не открыта.");
        return false;
    }

    if (!createTables(errorMessage)) {
        return false;
    }

    return seedInitialData(errorMessage);
}

bool Database::createTables(QString* errorMessage)
{
    auto execSql = [this, errorMessage](const QString& sql, const QString& objectName) -> bool {
        QSqlQuery query(m_db);
        if (!query.exec(sql)) {
            setError(errorMessage, "Ошибка создания " + objectName + ": " + query.lastError().text());
            return false;
        }
        return true;
    };

    const QString usersSql =
        "CREATE TABLE IF NOT EXISTS users ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "name TEXT NOT NULL,"
        "login TEXT NOT NULL UNIQUE,"
        "email TEXT DEFAULT '',"
        "password_hash TEXT NOT NULL,"
        "salt TEXT NOT NULL,"
        "is_admin INTEGER DEFAULT 0,"
        "need_ramp INTEGER DEFAULT 0,"
        "need_elevator INTEGER DEFAULT 0,"
        "need_accessible_toilet INTEGER DEFAULT 0,"
        "need_quiet_place INTEGER DEFAULT 0,"
        "need_visual_support INTEGER DEFAULT 0,"
        "need_trained_staff INTEGER DEFAULT 0,"
        "need_picture_menu INTEGER DEFAULT 0,"
        "need_assistance INTEGER DEFAULT 0"
        ")";

    const QString categoriesSql =
        "CREATE TABLE IF NOT EXISTS categories ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "name TEXT NOT NULL UNIQUE"
        ")";

    const QString placesSql =
        "CREATE TABLE IF NOT EXISTS places ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "name TEXT NOT NULL,"
        "category_id INTEGER NOT NULL,"
        "address TEXT,"
        "phone TEXT,"
        "description TEXT,"
        "has_ramp INTEGER DEFAULT 0,"
        "has_elevator INTEGER DEFAULT 0,"
        "has_accessible_toilet INTEGER DEFAULT 0,"
        "has_quiet_place INTEGER DEFAULT 0,"
        "has_visual_support INTEGER DEFAULT 0,"
        "has_trained_staff INTEGER DEFAULT 0,"
        "has_picture_menu INTEGER DEFAULT 0,"
        "allows_assistant INTEGER DEFAULT 0,"
        "FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE CASCADE"
        ")";

    const QString photosSql =
        "CREATE TABLE IF NOT EXISTS place_photos ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "place_id INTEGER NOT NULL,"
        "photo_path TEXT NOT NULL,"
        "caption TEXT,"
        "sort_order INTEGER DEFAULT 0,"
        "FOREIGN KEY(place_id) REFERENCES places(id) ON DELETE CASCADE"
        ")";

    const QString newsSql =
        "CREATE TABLE IF NOT EXISTS news ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "title TEXT NOT NULL,"
        "text TEXT NOT NULL,"
        "image1 TEXT DEFAULT '',"
        "image2 TEXT DEFAULT '',"
        "created_at TEXT DEFAULT CURRENT_TIMESTAMP"
        ")";

    return execSql(usersSql, "таблицы users")
        && execSql(categoriesSql, "таблицы categories")
        && execSql(placesSql, "таблицы places")
        && execSql(photosSql, "таблицы place_photos")
        && execSql(newsSql, "таблицы news")
        && ensureColumn("users", "email", "TEXT DEFAULT ''", errorMessage)
        && ensureColumn("users", "is_admin", "INTEGER DEFAULT 0", errorMessage);
}

bool Database::ensureColumn(const QString& tableName,
                            const QString& columnName,
                            const QString& columnDefinition,
                            QString* errorMessage)
{
    QSqlQuery info(m_db);
    if (!info.exec("PRAGMA table_info(" + tableName + ")")) {
        setError(errorMessage, "Ошибка проверки структуры таблицы " + tableName + ": " + info.lastError().text());
        return false;
    }

    while (info.next()) {
        if (info.value(1).toString().compare(columnName, Qt::CaseInsensitive) == 0) {
            return true;
        }
    }

    QSqlQuery alter(m_db);
    const QString sql = "ALTER TABLE " + tableName + " ADD COLUMN " + columnName + " " + columnDefinition;
    if (!alter.exec(sql)) {
        setError(errorMessage, "Ошибка обновления структуры таблицы " + tableName + ": " + alter.lastError().text());
        return false;
    }

    return true;
}

bool Database::seedInitialData(QString* errorMessage)
{
    const QStringList categoryNames = {
        "Образовательные",
        "Культурно-массовые",
        "Общепит"
    };

    for (const QString& name : categoryNames) {
        QSqlQuery query(m_db);
        query.prepare("INSERT OR IGNORE INTO categories (name) VALUES (?)");
        query.addBindValue(name);
        if (!query.exec()) {
            setError(errorMessage, "Ошибка добавления категории: " + query.lastError().text());
            return false;
        }
    }

    if (!seedDefaultAdmin(errorMessage)) {
        return false;
    }

    QSqlQuery countQuery(m_db);
    if (!countQuery.exec("SELECT COUNT(*) FROM places") || !countQuery.next()) {
        setError(errorMessage, "Ошибка проверки начальных данных: " + countQuery.lastError().text());
        return false;
    }

    if (countQuery.value(0).toInt() == 0) {
        const QMap<QString, int> ids = categoryIds(errorMessage);
        if (ids.size() < categoryNames.size()) {
            setError(errorMessage, "Не удалось получить идентификаторы категорий.");
            return false;
        }

        struct SeedPlace
        {
            QString name;
            QString category;
            QString address;
            QString phone;
            QString description;
            bool ramp;
            bool elevator;
            bool toilet;
            bool quiet;
            bool visual;
            bool staff;
            bool pictureMenu;
            bool assistant;
        };

        const QVector<SeedPlace> seedPlaces = {
            {
                "Центр развития \"Лучик\"",
                "Образовательные",
                "ул. Молодежная, 7",
                "+375 29 555-66-77",
                "Образовательный центр с адаптированными занятиями, спокойной зоной ожидания и возможностью сопровождения.",
                true, true, true, true, true, true, false, true
            },
            {
                "Инклюзивная школа №12",
                "Образовательные",
                "пр. Независимости, 45",
                "+375 17 210-10-12",
                "Школа с доступным входом, лифтом, широкими проходами и визуальными указателями по этажам.",
                true, true, true, false, true, true, false, true
            },
            {
                "Учебный центр \"Старт\"",
                "Образовательные",
                "ул. Садовая, 18",
                "+375 33 700-80-90",
                "Небольшой учебный центр с индивидуальными занятиями и возможностью заранее предупредить персонал о потребностях посетителя.",
                true, false, false, true, true, true, false, true
            },
            {
                "Городская библиотека",
                "Культурно-массовые",
                "ул. Советская, 5",
                "+375 29 222-33-44",
                "Библиотека с тихими читальными зонами, понятной навигацией и доступным входом.",
                true, true, true, true, true, true, false, true
            },
            {
                "Музей истории города",
                "Культурно-массовые",
                "пл. Свободы, 2",
                "+375 17 300-20-30",
                "Музей с пандусом, лифтом, адаптированными маршрутами и сотрудниками, которые помогают посетителям.",
                true, true, true, false, true, true, false, true
            },
            {
                "Парк \"Солнечный\"",
                "Культурно-массовые",
                "ул. Парковая, 1",
                "+375 29 600-60-60",
                "Парк с широкими дорожками, спокойными зонами отдыха и понятными указателями.",
                true, false, true, true, true, false, false, true
            },
            {
                "Кафе \"Уют\"",
                "Общепит",
                "ул. Центральная, 10",
                "+375 29 123-45-67",
                "Спокойное кафе с удобным входом, адаптированным меню и возможностью посадки в тихой зоне.",
                true, false, true, true, true, true, true, true
            },
            {
                "Семейное кафе \"Радуга\"",
                "Общепит",
                "ул. Зеленая, 14",
                "+375 44 111-22-33",
                "Кафе с простым меню, картинками блюд, обученным персоналом и местами для сопровождающих.",
                true, false, true, true, true, true, true, true
            },
            {
                "Столовая \"Доброта\"",
                "Общепит",
                "ул. Школьная, 3",
                "+375 25 444-55-66",
                "Доступная столовая с широким входом, понятной навигацией и недорогими комплексными обедами.",
                true, false, false, false, true, true, true, true
            }
        };

        for (const SeedPlace& place : seedPlaces) {
            QSqlQuery insert(m_db);
            insert.prepare(
                "INSERT INTO places ("
                "name, category_id, address, phone, description, "
                "has_ramp, has_elevator, has_accessible_toilet, has_quiet_place, "
                "has_visual_support, has_trained_staff, has_picture_menu, allows_assistant"
                ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );
            insert.addBindValue(place.name);
            insert.addBindValue(ids.value(place.category));
            insert.addBindValue(place.address);
            insert.addBindValue(place.phone);
            insert.addBindValue(place.description);
            insert.addBindValue(place.ramp ? 1 : 0);
            insert.addBindValue(place.elevator ? 1 : 0);
            insert.addBindValue(place.toilet ? 1 : 0);
            insert.addBindValue(place.quiet ? 1 : 0);
            insert.addBindValue(place.visual ? 1 : 0);
            insert.addBindValue(place.staff ? 1 : 0);
            insert.addBindValue(place.pictureMenu ? 1 : 0);
            insert.addBindValue(place.assistant ? 1 : 0);

            if (!insert.exec()) {
                setError(errorMessage, "Ошибка добавления места: " + insert.lastError().text());
                return false;
            }
        }
    }

    return seedInitialPhotos(errorMessage);
}

bool Database::seedDefaultAdmin(QString* errorMessage)
{
    QSqlQuery find(m_db);
    find.prepare("SELECT id FROM users WHERE login = ?");
    find.addBindValue("admin");
    if (!find.exec()) {
        setError(errorMessage, "Ошибка проверки администратора: " + find.lastError().text());
        return false;
    }

    if (find.next()) {
        QSqlQuery update(m_db);
        update.prepare("UPDATE users SET is_admin = 1 WHERE login = ?");
        update.addBindValue("admin");
        if (!update.exec()) {
            setError(errorMessage, "Ошибка обновления прав администратора: " + update.lastError().text());
            return false;
        }
        return true;
    }

    const QString salt = generateSalt();
    const QString passwordHash = hashPassword("admin123", salt);

    QSqlQuery insert(m_db);
    insert.prepare(
        "INSERT INTO users ("
        "name, login, email, password_hash, salt, is_admin, "
        "need_ramp, need_elevator, need_accessible_toilet, need_quiet_place, "
        "need_visual_support, need_trained_staff, need_picture_menu, need_assistance"
        ") VALUES (?, ?, ?, ?, ?, ?, 0, 0, 0, 0, 0, 0, 0, 0)"
    );
    insert.addBindValue("Администратор");
    insert.addBindValue("admin");
    insert.addBindValue("admin@local.test");
    insert.addBindValue(passwordHash);
    insert.addBindValue(salt);
    insert.addBindValue(1);

    if (!insert.exec()) {
        setError(errorMessage, "Ошибка создания администратора: " + insert.lastError().text());
        return false;
    }

    return true;
}

bool Database::seedInitialPhotos(QString* errorMessage)
{
    QSqlQuery countQuery(m_db);
    if (!countQuery.exec("SELECT COUNT(*) FROM place_photos") || !countQuery.next()) {
        setError(errorMessage, "Ошибка проверки фотографий: " + countQuery.lastError().text());
        return false;
    }

    if (countQuery.value(0).toInt() > 0) {
        return true;
    }

    const QStringList educationPhotos = {
        ":/images/education_1.png",
        ":/images/education_2.png",
        ":/images/education_3.png"
    };
    const QStringList culturePhotos = {
        ":/images/culture_1.png",
        ":/images/culture_2.png",
        ":/images/culture_3.png"
    };
    const QStringList foodPhotos = {
        ":/images/food_1.png",
        ":/images/food_2.png",
        ":/images/food_3.png"
    };

    const QMap<QString, QStringList> photosByPlace = {
        {"Центр развития \"Лучик\"", educationPhotos},
        {"Инклюзивная школа №12", educationPhotos},
        {"Учебный центр \"Старт\"", educationPhotos},
        {"Городская библиотека", culturePhotos},
        {"Музей истории города", culturePhotos},
        {"Парк \"Солнечный\"", culturePhotos},
        {"Кафе \"Уют\"", foodPhotos},
        {"Семейное кафе \"Радуга\"", foodPhotos},
        {"Столовая \"Доброта\"", foodPhotos}
    };

    for (auto it = photosByPlace.constBegin(); it != photosByPlace.constEnd(); ++it) {
        QSqlQuery findPlace(m_db);
        findPlace.prepare("SELECT id FROM places WHERE name = ? LIMIT 1");
        findPlace.addBindValue(it.key());
        if (!findPlace.exec()) {
            setError(errorMessage, "Ошибка поиска места для фотографий: " + findPlace.lastError().text());
            return false;
        }
        if (!findPlace.next()) {
            continue;
        }

        const int placeId = findPlace.value(0).toInt();
        if (!savePlacePhotos(placeId, it.value(), errorMessage)) {
            return false;
        }
    }

    return true;
}

QMap<QString, int> Database::categoryIds(QString* errorMessage) const
{
    QMap<QString, int> ids;
    QSqlQuery query(m_db);
    if (!query.exec("SELECT id, name FROM categories")) {
        setError(errorMessage, "Ошибка чтения категорий: " + query.lastError().text());
        return ids;
    }

    while (query.next()) {
        ids.insert(query.value(1).toString(), query.value(0).toInt());
    }
    return ids;
}

bool Database::registerUser(const QString& name,
                            const QString& login,
                            const QString& email,
                            const QString& password,
                            const UserProfile& needs,
                            QString* errorMessage)
{
    const QString trimmedName = name.trimmed();
    const QString trimmedLogin = login.trimmed();
    const QString trimmedEmail = email.trimmed();

    if (trimmedName.isEmpty() || trimmedLogin.isEmpty() || trimmedEmail.isEmpty() || password.isEmpty()) {
        setError(errorMessage, "Заполните имя, логин, почту и пароль.");
        return false;
    }

    const QRegularExpression emailPattern("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    if (!emailPattern.match(trimmedEmail).hasMatch()) {
        setError(errorMessage, "Введите корректный адрес электронной почты.");
        return false;
    }

    if (password.size() < 4) {
        setError(errorMessage, "Пароль должен содержать минимум 4 символа.");
        return false;
    }

    QSqlQuery exists(m_db);
    exists.prepare("SELECT COUNT(*) FROM users WHERE login = ? OR lower(email) = lower(?)");
    exists.addBindValue(trimmedLogin);
    exists.addBindValue(trimmedEmail);
    if (!exists.exec() || !exists.next()) {
        setError(errorMessage, "Ошибка проверки пользователя: " + exists.lastError().text());
        return false;
    }

    if (exists.value(0).toInt() > 0) {
        setError(errorMessage, "Пользователь с таким логином или почтой уже существует.");
        return false;
    }

    const QString salt = generateSalt();
    const QString passwordHash = hashPassword(password, salt);

    QSqlQuery query(m_db);
    query.prepare(
        "INSERT INTO users ("
        "name, login, email, password_hash, salt, is_admin, need_ramp, need_elevator, "
        "need_accessible_toilet, need_quiet_place, need_visual_support, "
        "need_trained_staff, need_picture_menu, need_assistance"
        ") VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    query.addBindValue(trimmedName);
    query.addBindValue(trimmedLogin);
    query.addBindValue(trimmedEmail);
    query.addBindValue(passwordHash);
    query.addBindValue(salt);
    query.addBindValue(needs.needRamp ? 1 : 0);
    query.addBindValue(needs.needElevator ? 1 : 0);
    query.addBindValue(needs.needAccessibleToilet ? 1 : 0);
    query.addBindValue(needs.needQuietPlace ? 1 : 0);
    query.addBindValue(needs.needVisualSupport ? 1 : 0);
    query.addBindValue(needs.needTrainedStaff ? 1 : 0);
    query.addBindValue(needs.needPictureMenu ? 1 : 0);
    query.addBindValue(needs.needAssistance ? 1 : 0);

    if (!query.exec()) {
        const QString dbError = query.lastError().text();
        if (dbError.contains("UNIQUE", Qt::CaseInsensitive)) {
            setError(errorMessage, "Пользователь с таким логином или почтой уже существует.");
        } else {
            setError(errorMessage, "Ошибка регистрации: " + dbError);
        }
        return false;
    }

    return true;
}

bool Database::authenticate(const QString& login,
                            const QString& password,
                            UserProfile* profile,
                            QString* errorMessage)
{
    const QString trimmedLogin = login.trimmed();
    if (trimmedLogin.isEmpty() || password.isEmpty()) {
        setError(errorMessage, "Введите логин или почту и пароль.");
        return false;
    }

    QSqlQuery query(m_db);
    query.prepare(
        "SELECT id, name, login, email, is_admin, password_hash, salt, "
        "need_ramp, need_elevator, need_accessible_toilet, need_quiet_place, "
        "need_visual_support, need_trained_staff, need_picture_menu, need_assistance "
        "FROM users WHERE login = ? OR lower(email) = lower(?) LIMIT 1"
    );
    query.addBindValue(trimmedLogin);
    query.addBindValue(trimmedLogin);

    if (!query.exec()) {
        setError(errorMessage, "Ошибка авторизации: " + query.lastError().text());
        return false;
    }

    if (!query.next()) {
        setError(errorMessage, "Пользователь не найден.");
        return false;
    }

    const QString storedHash = query.value(5).toString();
    const QString salt = query.value(6).toString();
    if (hashPassword(password, salt) != storedHash) {
        setError(errorMessage, "Неверный пароль.");
        return false;
    }

    if (profile != nullptr) {
        profile->id = query.value(0).toInt();
        profile->name = query.value(1).toString();
        profile->login = query.value(2).toString();
        profile->email = query.value(3).toString();
        profile->isAdmin = query.value(4).toInt() == 1;
        profile->needRamp = query.value(7).toInt() == 1;
        profile->needElevator = query.value(8).toInt() == 1;
        profile->needAccessibleToilet = query.value(9).toInt() == 1;
        profile->needQuietPlace = query.value(10).toInt() == 1;
        profile->needVisualSupport = query.value(11).toInt() == 1;
        profile->needTrainedStaff = query.value(12).toInt() == 1;
        profile->needPictureMenu = query.value(13).toInt() == 1;
        profile->needAssistance = query.value(14).toInt() == 1;
    }

    return true;
}


QVector<NewsItem> Database::news(QString* errorMessage) const
{
    QVector<NewsItem> result;
    QSqlQuery query(m_db);
    if (!query.exec("SELECT id, title, text, image1, image2, created_at FROM news ORDER BY id DESC")) {
        setError(errorMessage, "Ошибка чтения новостей: " + query.lastError().text());
        return result;
    }
    while (query.next()) {
        NewsItem item;
        item.id = query.value(0).toInt();
        item.title = query.value(1).toString();
        item.text = query.value(2).toString();
        item.image1 = query.value(3).toString();
        item.image2 = query.value(4).toString();
        item.createdAt = query.value(5).toString();
        result.push_back(item);
    }
    return result;
}

bool Database::addNews(const QString& title, const QString& text, const QString& image1, const QString& image2, QString* errorMessage)
{
    if (title.trimmed().isEmpty() || text.trimmed().isEmpty()) {
        setError(errorMessage, "Введите заголовок и текст новости.");
        return false;
    }
    QSqlQuery query(m_db);
    query.prepare("INSERT INTO news (title, text, image1, image2) VALUES (?, ?, ?, ?)");
    query.addBindValue(title.trimmed());
    query.addBindValue(text.trimmed());
    query.addBindValue(image1.trimmed());
    query.addBindValue(image2.trimmed());
    if (!query.exec()) {
        setError(errorMessage, "Ошибка добавления новости: " + query.lastError().text());
        return false;
    }
    return true;
}

bool Database::deleteNews(int newsId, QString* errorMessage)
{
    QSqlQuery query(m_db);
    query.prepare("DELETE FROM news WHERE id = ?");
    query.addBindValue(newsId);
    if (!query.exec()) {
        setError(errorMessage, "Ошибка удаления новости: " + query.lastError().text());
        return false;
    }
    if (query.numRowsAffected() == 0) {
        setError(errorMessage, "Новость не найдена.");
        return false;
    }
    return true;
}

QVector<UserAccount> Database::users(QString* errorMessage) const
{
    QVector<UserAccount> result;
    QSqlQuery query(m_db);
    if (!query.exec("SELECT id, name, login, email, is_admin FROM users ORDER BY id")) {
        setError(errorMessage, "Ошибка чтения пользователей: " + query.lastError().text());
        return result;
    }
    while (query.next()) {
        UserAccount user;
        user.id = query.value(0).toInt();
        user.name = query.value(1).toString();
        user.login = query.value(2).toString();
        user.email = query.value(3).toString();
        user.isAdmin = query.value(4).toInt() == 1;
        result.push_back(user);
    }
    return result;
}

bool Database::deleteUser(int userId, QString* errorMessage)
{
    QSqlQuery query(m_db);
    query.prepare("DELETE FROM users WHERE id = ? AND is_admin = 0");
    query.addBindValue(userId);
    if (!query.exec()) {
        setError(errorMessage, "Ошибка удаления пользователя: " + query.lastError().text());
        return false;
    }
    if (query.numRowsAffected() == 0) {
        setError(errorMessage, "Администратора удалить нельзя или пользователь не найден.");
        return false;
    }
    return true;
}

bool Database::makeUserAdmin(int userId, QString* errorMessage)
{
    QSqlQuery query(m_db);
    query.prepare("UPDATE users SET is_admin = 1 WHERE id = ?");
    query.addBindValue(userId);
    if (!query.exec()) {
        setError(errorMessage, "Ошибка изменения роли: " + query.lastError().text());
        return false;
    }
    return true;
}

bool Database::setUserAdminStatus(int userId, bool isAdmin, QString* errorMessage)
{
    QSqlQuery check(m_db);
    check.prepare("SELECT login FROM users WHERE id = ?");
    check.addBindValue(userId);
    if (!check.exec() || !check.next()) {
        setError(errorMessage, "Пользователь не найден.");
        return false;
    }
    if (check.value(0).toString() == "admin" && !isAdmin) {
        setError(errorMessage, "Владельца системы нельзя лишить прав администратора.");
        return false;
    }

    QSqlQuery query(m_db);
    query.prepare("UPDATE users SET is_admin = ? WHERE id = ?");
    query.addBindValue(isAdmin ? 1 : 0);
    query.addBindValue(userId);
    if (!query.exec()) {
        setError(errorMessage, "Ошибка изменения роли: " + query.lastError().text());
        return false;
    }
    return true;
}

bool Database::updateUserProfile(int userId, const QString& name, const UserProfile& needs, const QString& newPassword, QString* errorMessage)
{
    if (name.trimmed().isEmpty()) {
        setError(errorMessage, "Имя не может быть пустым.");
        return false;
    }
    if (!newPassword.isEmpty() && newPassword.size() < 4) {
        setError(errorMessage, "Пароль должен содержать минимум 4 символа.");
        return false;
    }
    QSqlQuery query(m_db);
    if (newPassword.isEmpty()) {
        query.prepare("UPDATE users SET name=?, need_ramp=?, need_elevator=?, need_accessible_toilet=?, need_quiet_place=?, need_visual_support=?, need_trained_staff=?, need_picture_menu=?, need_assistance=? WHERE id=?");
        query.addBindValue(name.trimmed());
    } else {
        const QString salt = generateSalt();
        const QString passwordHash = hashPassword(newPassword, salt);
        query.prepare("UPDATE users SET name=?, password_hash=?, salt=?, need_ramp=?, need_elevator=?, need_accessible_toilet=?, need_quiet_place=?, need_visual_support=?, need_trained_staff=?, need_picture_menu=?, need_assistance=? WHERE id=?");
        query.addBindValue(name.trimmed());
        query.addBindValue(passwordHash);
        query.addBindValue(salt);
    }
    query.addBindValue(needs.needRamp ? 1 : 0);
    query.addBindValue(needs.needElevator ? 1 : 0);
    query.addBindValue(needs.needAccessibleToilet ? 1 : 0);
    query.addBindValue(needs.needQuietPlace ? 1 : 0);
    query.addBindValue(needs.needVisualSupport ? 1 : 0);
    query.addBindValue(needs.needTrainedStaff ? 1 : 0);
    query.addBindValue(needs.needPictureMenu ? 1 : 0);
    query.addBindValue(needs.needAssistance ? 1 : 0);
    query.addBindValue(userId);
    if (!query.exec()) {
        setError(errorMessage, "Ошибка сохранения профиля: " + query.lastError().text());
        return false;
    }
    return true;
}

QVector<QPair<int, QString>> Database::categories(QString* errorMessage) const
{
    QVector<QPair<int, QString>> result;
    QSqlQuery query(m_db);
    if (!query.exec("SELECT id, name FROM categories ORDER BY id")) {
        setError(errorMessage, "Ошибка чтения категорий: " + query.lastError().text());
        return result;
    }

    while (query.next()) {
        result.push_back(qMakePair(query.value(0).toInt(), query.value(1).toString()));
    }

    return result;
}

QVector<Place> Database::places(const AccessibilityFilters& filters,
                                int categoryId,
                                const QString& searchText,
                                QString* errorMessage) const
{
    QVector<Place> result;

    QString sql =
        "SELECT places.id, places.category_id, places.name, categories.name, "
        "places.address, places.phone, places.description, "
        "places.has_ramp, places.has_elevator, places.has_accessible_toilet, "
        "places.has_quiet_place, places.has_visual_support, places.has_trained_staff, "
        "places.has_picture_menu, places.allows_assistant "
        "FROM places "
        "INNER JOIN categories ON categories.id = places.category_id "
        "WHERE 1 = 1 ";

    if (categoryId > 0) {
        sql += "AND places.category_id = :category_id ";
    }

    const QString trimmedSearch = searchText.trimmed();
    if (!trimmedSearch.isEmpty()) {
        sql += "AND (places.name LIKE :search OR places.address LIKE :search OR places.description LIKE :search) ";
    }

    sql += "ORDER BY categories.id, places.name";

    QSqlQuery query(m_db);
    if (!query.prepare(sql)) {
        setError(errorMessage, "Ошибка подготовки запроса: " + query.lastError().text());
        return result;
    }

    if (categoryId > 0) {
        query.bindValue(":category_id", categoryId);
    }
    if (!trimmedSearch.isEmpty()) {
        query.bindValue(":search", "%" + trimmedSearch + "%");
    }

    if (!query.exec()) {
        setError(errorMessage, "Ошибка получения списка мест: " + query.lastError().text());
        return result;
    }

    while (query.next()) {
        result.push_back(readPlace(query));
    }

    return result;
}

bool Database::placeById(int placeId, Place* place, QString* errorMessage) const
{
    QSqlQuery query(m_db);
    query.prepare(
        "SELECT places.id, places.category_id, places.name, categories.name, "
        "places.address, places.phone, places.description, "
        "places.has_ramp, places.has_elevator, places.has_accessible_toilet, "
        "places.has_quiet_place, places.has_visual_support, places.has_trained_staff, "
        "places.has_picture_menu, places.allows_assistant "
        "FROM places "
        "INNER JOIN categories ON categories.id = places.category_id "
        "WHERE places.id = ?"
    );
    query.addBindValue(placeId);

    if (!query.exec()) {
        setError(errorMessage, "Ошибка чтения карточки места: " + query.lastError().text());
        return false;
    }

    if (!query.next()) {
        setError(errorMessage, "Место не найдено.");
        return false;
    }

    if (place != nullptr) {
        *place = readPlace(query);
        place->photoPaths = placePhotos(placeId, nullptr);
    }
    return true;
}

QStringList Database::placePhotos(int placeId, QString* errorMessage) const
{
    QStringList result;
    QSqlQuery query(m_db);
    query.prepare(
        "SELECT photo_path FROM place_photos "
        "WHERE place_id = ? "
        "ORDER BY sort_order, id "
        "LIMIT 10"
    );
    query.addBindValue(placeId);

    if (!query.exec()) {
        setError(errorMessage, "Ошибка чтения фотографий: " + query.lastError().text());
        return result;
    }

    while (query.next()) {
        result << query.value(0).toString();
    }

    return result;
}

bool Database::addPlace(const Place& place,
                        const QStringList& photoPaths,
                        int* newPlaceId,
                        QString* errorMessage)
{
    if (place.name.trimmed().isEmpty()) {
        setError(errorMessage, "Введите название заведения.");
        return false;
    }
    if (place.categoryId <= 0) {
        setError(errorMessage, "Выберите категорию.");
        return false;
    }

    if (!m_db.transaction()) {
        setError(errorMessage, "Не удалось начать транзакцию: " + m_db.lastError().text());
        return false;
    }

    QSqlQuery query(m_db);
    query.prepare(
        "INSERT INTO places ("
        "name, category_id, address, phone, description, "
        "has_ramp, has_elevator, has_accessible_toilet, has_quiet_place, "
        "has_visual_support, has_trained_staff, has_picture_menu, allows_assistant"
        ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    query.addBindValue(place.name.trimmed());
    query.addBindValue(place.categoryId);
    query.addBindValue(place.address.trimmed());
    query.addBindValue(place.phone.trimmed());
    query.addBindValue(place.description.trimmed());
    query.addBindValue(place.hasRamp ? 1 : 0);
    query.addBindValue(place.hasElevator ? 1 : 0);
    query.addBindValue(place.hasAccessibleToilet ? 1 : 0);
    query.addBindValue(place.hasQuietPlace ? 1 : 0);
    query.addBindValue(place.hasVisualSupport ? 1 : 0);
    query.addBindValue(place.hasTrainedStaff ? 1 : 0);
    query.addBindValue(place.hasPictureMenu ? 1 : 0);
    query.addBindValue(place.allowsAssistant ? 1 : 0);

    if (!query.exec()) {
        setError(errorMessage, "Ошибка добавления заведения: " + query.lastError().text());
        m_db.rollback();
        return false;
    }

    const int placeId = query.lastInsertId().toInt();
    if (!savePlacePhotos(placeId, photoPaths, errorMessage)) {
        m_db.rollback();
        return false;
    }

    if (!m_db.commit()) {
        setError(errorMessage, "Ошибка сохранения изменений: " + m_db.lastError().text());
        m_db.rollback();
        return false;
    }

    if (newPlaceId != nullptr) {
        *newPlaceId = placeId;
    }
    return true;
}

bool Database::updatePlace(const Place& place,
                           const QStringList& photoPaths,
                           QString* errorMessage)
{
    if (place.id <= 0) {
        setError(errorMessage, "Не выбрано заведение для редактирования.");
        return false;
    }
    if (place.name.trimmed().isEmpty()) {
        setError(errorMessage, "Введите название заведения.");
        return false;
    }
    if (place.categoryId <= 0) {
        setError(errorMessage, "Выберите категорию.");
        return false;
    }

    if (!m_db.transaction()) {
        setError(errorMessage, "Не удалось начать транзакцию: " + m_db.lastError().text());
        return false;
    }

    QSqlQuery query(m_db);
    query.prepare(
        "UPDATE places SET "
        "name = ?, category_id = ?, address = ?, phone = ?, description = ?, "
        "has_ramp = ?, has_elevator = ?, has_accessible_toilet = ?, has_quiet_place = ?, "
        "has_visual_support = ?, has_trained_staff = ?, has_picture_menu = ?, allows_assistant = ? "
        "WHERE id = ?"
    );
    query.addBindValue(place.name.trimmed());
    query.addBindValue(place.categoryId);
    query.addBindValue(place.address.trimmed());
    query.addBindValue(place.phone.trimmed());
    query.addBindValue(place.description.trimmed());
    query.addBindValue(place.hasRamp ? 1 : 0);
    query.addBindValue(place.hasElevator ? 1 : 0);
    query.addBindValue(place.hasAccessibleToilet ? 1 : 0);
    query.addBindValue(place.hasQuietPlace ? 1 : 0);
    query.addBindValue(place.hasVisualSupport ? 1 : 0);
    query.addBindValue(place.hasTrainedStaff ? 1 : 0);
    query.addBindValue(place.hasPictureMenu ? 1 : 0);
    query.addBindValue(place.allowsAssistant ? 1 : 0);
    query.addBindValue(place.id);

    if (!query.exec()) {
        setError(errorMessage, "Ошибка обновления заведения: " + query.lastError().text());
        m_db.rollback();
        return false;
    }

    if (!savePlacePhotos(place.id, photoPaths, errorMessage)) {
        m_db.rollback();
        return false;
    }

    if (!m_db.commit()) {
        setError(errorMessage, "Ошибка сохранения изменений: " + m_db.lastError().text());
        m_db.rollback();
        return false;
    }

    return true;
}

bool Database::deletePlace(int placeId, QString* errorMessage)
{
    if (placeId <= 0) {
        setError(errorMessage, "Не выбрано заведение для удаления.");
        return false;
    }

    QSqlQuery query(m_db);
    query.prepare("DELETE FROM places WHERE id = ?");
    query.addBindValue(placeId);
    if (!query.exec()) {
        setError(errorMessage, "Ошибка удаления заведения: " + query.lastError().text());
        return false;
    }

    return true;
}

bool Database::savePlacePhotos(int placeId,
                               const QStringList& photoPaths,
                               QString* errorMessage)
{
    QSqlQuery remove(m_db);
    remove.prepare("DELETE FROM place_photos WHERE place_id = ?");
    remove.addBindValue(placeId);
    if (!remove.exec()) {
        setError(errorMessage, "Ошибка очистки фотографий: " + remove.lastError().text());
        return false;
    }

    const QStringList photos = normalizedPhotoList(photoPaths);
    for (int i = 0; i < photos.size(); ++i) {
        QSqlQuery insert(m_db);
        insert.prepare(
            "INSERT INTO place_photos (place_id, photo_path, caption, sort_order) "
            "VALUES (?, ?, ?, ?)"
        );
        insert.addBindValue(placeId);
        insert.addBindValue(photos.at(i));
        insert.addBindValue(QString());
        insert.addBindValue(i);
        if (!insert.exec()) {
            setError(errorMessage, "Ошибка сохранения фотографии: " + insert.lastError().text());
            return false;
        }
    }

    return true;
}

QString Database::importPhotoToStorage(const QString& sourcePath, QString* errorMessage) const
{
    const QFileInfo sourceInfo(sourcePath);
    if (!sourceInfo.exists() || !sourceInfo.isFile()) {
        setError(errorMessage, "Файл изображения не найден.");
        return QString();
    }

    const QString suffix = sourceInfo.suffix().toLower();
    const QStringList allowed = {"png", "jpg", "jpeg", "bmp", "gif", "webp"};
    if (!allowed.contains(suffix)) {
        setError(errorMessage, "Поддерживаются изображения PNG, JPG, JPEG, BMP, GIF и WEBP.");
        return QString();
    }

    QString basePath = QFileInfo(m_databasePath).absolutePath();
    if (basePath.isEmpty()) {
        basePath = QDir::currentPath();
    }

    QDir baseDir(basePath);
    if (!baseDir.exists("photos") && !baseDir.mkdir("photos")) {
        setError(errorMessage, "Не удалось создать папку для фотографий.");
        return QString();
    }

    const QString uniqueName = QUuid::createUuid().toString(QUuid::Id128) + "." + suffix;
    const QString targetPath = baseDir.filePath("photos/" + uniqueName);

    if (!QFile::copy(sourceInfo.absoluteFilePath(), targetPath)) {
        setError(errorMessage, "Не удалось скопировать изображение в папку программы.");
        return QString();
    }

    return targetPath;
}

QString Database::generateSalt() const
{
    QString salt;
    for (int i = 0; i < 2; ++i) {
        const quint64 value = QRandomGenerator::global()->generate64();
        salt += QString::number(value, 16).rightJustified(16, QLatin1Char('0'));
    }
    return salt;
}

QString Database::hashPassword(const QString& password, const QString& salt) const
{
    QCryptographicHash hash(QCryptographicHash::Sha256);
    hash.addData((salt + ":" + password).toUtf8());
    return QString::fromLatin1(hash.result().toHex());
}
