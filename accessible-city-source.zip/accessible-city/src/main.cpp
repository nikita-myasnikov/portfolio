#include "database.h"
#include "loginwindow.h"
#include "mainwindow.h"

#include <QApplication>
#include <QDialog>
#include <QFile>
#include <QFont>
#include <QMessageBox>
#include <QString>

namespace
{
void applyApplicationDesign(QApplication& app)
{
    app.setFont(QFont("Segoe UI", 10));

    QFile styleFile(":/styles/app.qss");
    if (styleFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        app.setStyleSheet(QString::fromUtf8(styleFile.readAll()));
    }
}
}

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    QApplication::setApplicationName("AccessibleCity");
    QApplication::setOrganizationName("CourseProject");
    applyApplicationDesign(app);

    QString error;
    if (!Database::instance().open(&error) || !Database::instance().initialize(&error)) {
        QMessageBox::critical(nullptr, "Ошибка запуска", error);
        return 1;
    }

    LoginWindow loginWindow;
    if (loginWindow.exec() != QDialog::Accepted) {
        return 0;
    }

    MainWindow mainWindow(loginWindow.loggedUser());
    mainWindow.show();

    return app.exec();
}
