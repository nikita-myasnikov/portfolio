QT += core gui widgets sql
CONFIG += c++17

TARGET = AccessibleCity
TEMPLATE = app

SOURCES += \
    src/main.cpp \
    src/database.cpp \
    src/loginwindow.cpp \
    src/registerwindow.cpp \
    src/mainwindow.cpp \
    src/admindialog.cpp \
    src/placedetailsdialog.cpp

HEADERS += \
    src/models.h \
    src/database.h \
    src/loginwindow.h \
    src/registerwindow.h \
    src/mainwindow.h \
    src/admindialog.h \
    src/placedetailsdialog.h

RESOURCES += resources.qrc
