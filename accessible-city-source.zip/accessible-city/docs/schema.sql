-- Структура базы данных проекта "Доступный город"
-- SQLite создаётся автоматически при первом запуске программы.

CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    login TEXT NOT NULL UNIQUE,
    email TEXT DEFAULT '',
    password_hash TEXT NOT NULL,
    salt TEXT NOT NULL,
    is_admin INTEGER DEFAULT 0,
    need_ramp INTEGER DEFAULT 0,
    need_elevator INTEGER DEFAULT 0,
    need_accessible_toilet INTEGER DEFAULT 0,
    need_quiet_place INTEGER DEFAULT 0,
    need_visual_support INTEGER DEFAULT 0,
    need_trained_staff INTEGER DEFAULT 0,
    need_picture_menu INTEGER DEFAULT 0,
    need_assistance INTEGER DEFAULT 0
);

CREATE TABLE categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);

CREATE TABLE places (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category_id INTEGER NOT NULL,
    address TEXT,
    phone TEXT,
    description TEXT,
    has_ramp INTEGER DEFAULT 0,
    has_elevator INTEGER DEFAULT 0,
    has_accessible_toilet INTEGER DEFAULT 0,
    has_quiet_place INTEGER DEFAULT 0,
    has_visual_support INTEGER DEFAULT 0,
    has_trained_staff INTEGER DEFAULT 0,
    has_picture_menu INTEGER DEFAULT 0,
    allows_assistant INTEGER DEFAULT 0,
    FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE CASCADE
);

CREATE TABLE place_photos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    place_id INTEGER NOT NULL,
    photo_path TEXT NOT NULL,
    caption TEXT,
    sort_order INTEGER DEFAULT 0,
    FOREIGN KEY(place_id) REFERENCES places(id) ON DELETE CASCADE
);
