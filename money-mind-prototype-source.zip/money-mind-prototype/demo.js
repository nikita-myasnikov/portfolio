// Presentation-only interactions. No account, network writes or saved progress.
const answers = [...document.querySelectorAll('[data-answer]')];
const feedback = document.querySelector('.feedback');
const title = document.querySelector('[data-feedback-title]');
const body = document.querySelector('[data-feedback-body]');
answers.forEach(button => button.addEventListener('click', () => {
  answers.forEach(answer => { answer.setAttribute('aria-pressed', String(answer === button)); answer.querySelector('.answer-correct')?.remove(); });
  const correct = button.dataset.answer === '200';
  feedback.classList.toggle('wrong', !correct);
  title.textContent = correct ? 'Exactly. You found the savings share.' : 'Not quite. Let’s work through it.';
  body.textContent = correct ? '20% means 20 out of every 100. Multiply 1,000 by 0.20 to get 200 units. The remaining 800 units cover the other two groups.' : `${button.dataset.answer} units is ${Number(button.dataset.answer) / 10}% of 1,000. For 20%, multiply 1,000 by 0.20: the answer is 200 units.`;
}));
document.querySelector('[data-reset]')?.addEventListener('click', () => {
  answers.forEach(answer => { answer.setAttribute('aria-pressed', 'false'); answer.querySelector('.answer-correct')?.remove(); });
  feedback.classList.remove('wrong');
  title.textContent = 'Your turn.';
  body.textContent = 'Choose an answer above. You will see a short explanation right away.';
  answers[0]?.focus();
});
const lessons = {
 budget: ['Lesson 01 · Budgeting basics', 'Give every part a purpose.', 'A budget describes how money could be used. This example groups 1,000 fictional units into needs, wants and savings.', 'Start by understanding each group', 'Needs are essential costs, such as housing and basic food. Wants are optional spending. Savings set money aside for a future purpose.', 'The split is a learning example, not a fixed rule. Real budgets depend on essential costs, income and personal circumstances.'],
 saving: ['Lesson 02 · Saving habits', 'Small amounts can add up.', 'In this fictional example, a learner sets aside 25 units each week for four weeks.', 'Follow the contributions', '25 + 25 + 25 + 25 = 100 units. This example counts contributions only; it does not include interest or fees.', 'Consistency can make a total easier to understand. The right amount depends on someone’s own needs and circumstances.'],
 interest: ['Lesson 03 · Interest explained', 'Principal, rate and time.', 'Principal is the starting amount. An interest rate describes a percentage applied over a stated period.', 'Read the period as well as the rate', 'For a simple teaching example, 100 units at 5% simple interest for one year earns 5 units: 100 × 0.05 × 1.', 'This example excludes fees, tax and changing rates. It illustrates a calculation, not the return of a real product.']
};
function showLesson(key) {
 const values = lessons[key]; if (!values || !document.querySelector('[data-lesson-title]')) return;
 ['eyebrow','title','body','subtitle','explanation','takeaway'].forEach((field,i) => { document.querySelector(`[data-lesson-${field}]`).textContent = values[i]; });
 document.querySelector('[data-budget-visual]').hidden = key !== 'budget';
 document.querySelectorAll('[data-topic]').forEach(link => { const active = link.dataset.topic === key; link.classList.toggle('current', active); link.classList.toggle('selected', active && link.classList.contains('lesson-card')); active ? link.setAttribute('aria-current','true') : link.removeAttribute('aria-current'); });
 document.getElementById('lesson').scrollIntoView({ block:'nearest' });
}
document.querySelectorAll('[data-topic]').forEach(link => link.addEventListener('click', event => { event.preventDefault(); const key=link.dataset.topic; history.replaceState(null, '', key==='budget' ? '#lesson' : `#lesson-${key}`); showLesson(key); }));
if (location.hash === '#lesson-saving') showLesson('saving');
if (location.hash === '#lesson-interest') showLesson('interest');
